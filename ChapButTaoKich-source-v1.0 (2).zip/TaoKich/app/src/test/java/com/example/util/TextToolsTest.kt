package com.example.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử phần xử lý chữ của bản 1.5 (tìm không dấu, thay nguyên từ, tách câu, nhập tệp). */
class TextToolsTest {
    @Test fun foldAndMatch() {
        assertEquals("duong tang tran", TextTools.fold("Đường Tăng TRẦN"))
        assertTrue(TextTools.matches("Kiếm Lai Phong Vân", "phong van"))
        assertFalse(TextTools.matches("abc", "x"))
    }

    @Test fun wholeWordReplace() {
        val t = "Minh nhìn Minh Đạo. Minhh không phải Minh! Ông Minh-Đạo"
        assertEquals(4, TextTools.countWholeWord(t, "Minh"))
        val (r, n) = TextTools.replaceWholeWord(t, "Minh", "Lam")
        assertEquals("Lam nhìn Lam Đạo. Minhh không phải Lam! Ông Lam-Đạo", r)
        assertEquals(4, n)
        assertEquals(2, TextTools.countNames("Lý Thanh Vân gặp Thanh Vân và Vân", listOf("Lý Thanh Vân", "Thanh Vân")))
    }

    @Test fun sentences() {
        val s = "Đêm ấy trăng sáng. Hắn hỏi: “Mười năm rồi sao?” Giá 3.5 lượng…\nDòng mới\n\n  Hết"
        val list = TextTools.sentenceRanges(s).map { s.substring(it.first, it.last + 1) }
        assertEquals(listOf("Đêm ấy trăng sáng.", "Hắn hỏi: “Mười năm rồi sao?”", "Giá 3.5 lượng…", "Dòng mới", "Hết"), list)
    }

    @Test fun worldCategories() {
        assertEquals("OTHER", WorldCategories.normalize("HISTORY"))
        assertEquals("Lịch sử", WorldCategories.legacyTag("HISTORY"))
        assertEquals("TALENT", WorldCategories.normalize("TALENT"))
    }

    @Test fun headings() {
        listOf("Quyển 1", "Quyển 2: Gió Bắc", "QUYỂN III - Kết", "Tập 4", "第一卷 天下").forEach { assertTrue(it, BookImporter.isVolumeHeading(it)) }
        listOf("Tập trung nhìn", "Phần lớn người", "Quyển sách cũ trên bàn").forEach { assertFalse(it, BookImporter.isVolumeHeading(it)) }
        listOf("Chương 1", "Chương 12: Gặp gỡ", "Chương 3 Tên chương", "Chapter 7 - Night", "第十二章 风起", "Hồi 5", "Mở đầu").forEach { assertTrue(it, BookImporter.isChapterHeading(it)) }
        listOf("Chương trình học", "Chương này hay", "Mở đầu câu chuyện là").forEach { assertFalse(it, BookImporter.isChapterHeading(it)) }
    }

    @Test fun importTxt() {
        val b = BookImporter.parseTxt("Lời tựa.\r\n\r\nQuyển 1: Khởi đầu\nChương 1: A\nDòng 1\n\n\n\nDòng 2\nChương 2\nNội dung 2\nQuyển 2\nChương 3\nC3\n", "Tên")
        assertEquals(2, b.volumes.size)
        assertEquals(listOf("Mở đầu", "Chương 1: A", "Chương 2"), b.volumes[0].chapters.map { it.title })
        assertEquals("Dòng 1\n\nDòng 2", b.volumes[0].chapters[1].content)
        assertEquals(4, b.chapterCount)
    }

    @Test fun importDocxXml() {
        val xml = """<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>Quyển Một</w:t></w:r></w:p><w:p><w:pPr><w:pStyle w:val="Heading2"/></w:pPr><w:r><w:t>Chương Đầu</w:t></w:r></w:p><w:p><w:r><w:t>A &amp; B</w:t></w:r></w:p>"""
        val d = BookImporter.parseDocumentXml(xml, "Word")
        assertEquals("Quyển Một", d.volumes[0].title)
        assertEquals("Chương Đầu", d.volumes[0].chapters[0].title)
        assertEquals("A & B", d.volumes[0].chapters[0].content)
    }
}
