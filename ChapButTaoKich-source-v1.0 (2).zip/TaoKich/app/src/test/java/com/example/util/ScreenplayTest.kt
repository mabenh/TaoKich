package com.example.util

import org.junit.Assert.assertTrue
import org.junit.Test

/** Kiểm thử bộ xử lý kịch bản: nhận kiểu dòng, cảnh, thống kê, chuẩn hóa, gợi ý, Fountain, chia trang PDF. */
class ScreenplayTest {
    private fun check(name: String, cond: Boolean) = assertTrue(name, cond)

    private val sample = """NGOẠI. TRẠM XE BUÝT BẾN THÀNH – ĐÊM

Mưa lất phất. LAN (20) chạy tới.

NỘI. XE BUÝT SỐ 18 – ĐÊM

BÁC TƯ (60) gật đầu.

LAN
(lí nhí)
Bác ơi... con để quên ví rồi.

BÁC TƯ (V.O.)
Lên đi con. Chuyến cuối mà.

MỘT TIẾNG CÒI XE VANG LÊN.

CẮT SANG:

INT./EXT. NHÀ LAN - SÁNG

@mẹ
Về rồi hả con?"""

    @Test fun screenplay() {
    val lines = Screenplay.classify(sample)
    val types = lines.filter { it.type != LineType.BLANK }.map { it.type }
    if (false) println(types)
    check("types", types == listOf(LineType.SCENE, LineType.ACTION, LineType.SCENE, LineType.ACTION, LineType.CHARACTER, LineType.PARENTHETICAL, LineType.DIALOGUE,
        LineType.CHARACTER, LineType.DIALOGUE, LineType.ACTION, LineType.TRANSITION, LineType.SCENE, LineType.CHARACTER, LineType.DIALOGUE))
    val sc = Screenplay.scenes(sample)
    check("scenes", sc.size == 3 && sc[0].interior == "NGOẠI" && sc[0].location == "TRẠM XE BUÝT BẾN THÀNH" && sc[0].time == "ĐÊM" && sc[2].interior == "NỘI/NGOẠI" && sc[2].time == "SÁNG" && sc[2].location == "NHÀ LAN")
    val st = Screenplay.stats(sample)
    if (false) println(st)
    check("stats chars", st.characters.map { it.name }.toSet() == setOf("LAN", "BÁC TƯ", "MẸ") && st.characters.first { it.name == "LAN" }.blocks == 1)
    check("stats ie", st.interiorCounts["NỘI"] == 1 && st.interiorCounts["NGOẠI"] == 1 && st.timeCounts["ĐÊM"] == 2)
    check("pages", st.pages > 0.3 && st.pages < 1.0)
    check("names", Screenplay.characterNames(sample) == listOf("LAN", "BÁC TƯ", "mẹ"))
    check("not cue", !Screenplay.isSceneHeading("Nội dung câu chuyện") && !Screenplay.isSceneHeading("Ngoại hình đẹp") && Screenplay.isSceneHeading("NGOẠI SÂN") && Screenplay.isSceneHeading("nội. bếp – ngày") && Screenplay.isSceneHeading(".PHÒNG KÍN"))
    check("transition", Screenplay.isTransition("CẮT SANG:") && Screenplay.isTransition("CUT TO:") && Screenplay.isTransition("cắt sang:") && !Screenplay.isTransition("Anh cắt sang nhà:"))
    val messy = "nội. bếp – ngày\nLan nấu cơm.\nlan\nĐói quá.\n\n\n\ncắt sang:   "
    val norm = Screenplay.normalize(messy)
    if (false) println(norm)
    check("normalize", norm == "NỘI. BẾP – NGÀY\nLan nấu cơm.\nlan\nĐói quá.\n\nCẮT SANG:")
    val (c1, cur1) = Screenplay.convertLine("Lan nấu cơm.\nbác tư", 15, LineType.CHARACTER)
    check("convert char", c1 == "Lan nấu cơm.\n\nBÁC TƯ" && cur1 == c1.length)
    val (c2, _) = Screenplay.convertLine("NỘI. BẾP\n\nlí nhí", 12, LineType.PARENTHETICAL)
    check("convert paren", c2 == "NỘI. BẾP\n\n(lí nhí)")
    val (c3, _) = Screenplay.convertLine("bếp – ngày", 2, LineType.SCENE)
    check("convert scene", c3 == "NỘI. BẾP – NGÀY")
    val sug = Screenplay.suggestions("A\n\nNGOẠI. TR", 11, listOf("Lan"), listOf("TRẠM XE BUÝT BẾN THÀNH", "NHÀ LAN"))
    if (false) println(sug)
    check("suggest loc", sug.any { it.second == "NGOẠI. TRẠM XE BUÝT BẾN THÀNH" })
    val sug2 = Screenplay.suggestions("A\n\nNGOẠI. NHÀ LAN – Đ", 18, emptyList(), emptyList())
    check("suggest time", sug2.any { it.second == "NGOẠI. NHÀ LAN – ĐÊM" })
    val sug3 = Screenplay.suggestions("Hành động.\n\nB", 13, listOf("Bác Tư", "Lan"), emptyList())
    if (false) println(sug3)
    check("suggest char", sug3.any { it.second == "BÁC TƯ" } && sug3.none { it.second == "LAN" })
    val f = Screenplay.toFountain("Chuyến Xe", "Văn Mọn", listOf(Screenplay.ExportPart("Hồi 1", "Phân đoạn 1", sample)))
    if (false) println(f.take(200))
    check("fountain forced", f.contains("\n.NGOẠI. TRẠM XE BUÝT") && f.contains("\n> CẮT SANG:") && f.contains("\nINT./EXT. NHÀ LAN") && f.startsWith("Title: Chuyến Xe"))
    val back = Screenplay.parseFountain(f, "X")
    check("roundtrip", back.title == "Chuyến Xe" && back.author == "Văn Mọn" && back.volumes[0].title == "Hồi 1" && back.volumes[0].chapters[0].title == "Phân đoạn 1")
    val re = back.volumes[0].chapters[0].content
    check("roundtrip types", Screenplay.classify(re).filter { it.type != LineType.BLANK }.map { it.type } == types)
    val plain = Screenplay.parseFountain("NỘI. A – NGÀY\n\nHi.", "Tên", "Mùa", "Tập")
    check("no sections", plain.volumes[0].title == "Mùa 1" && plain.volumes[0].chapters[0].title == "Tập 1" && plain.title == "Tên")
    val syn = Screenplay.parseFountain("Title:\n    _**BIG**_\nAuthor: A\n\n# Mùa 1\n## Tập 1\n= Tóm tắt tập\nNỘI. A – NGÀY\n/* bỏ */\nHi.", "x")
    check("title multiline+synopsis", syn.title == "BIG" && syn.volumes[0].chapters[0].outline == "Tóm tắt tập" && !syn.volumes[0].chapters[0].content.contains("bỏ"))
    // paginate
    val long = (1..40).joinToString("\n\n") { "NỘI. PHÒNG $it – NGÀY\n\nHành động dài ".repeat(1) + "x ".repeat(80) + "\n\nLAN\n" + "Lời thoại rất dài ".repeat(20) }
    val pages = Screenplay.paginate(listOf(Screenplay.ExportPart(null, "Tập 1", long)))
    if (false) println("pages=" + pages.size + " sizes=" + pages.map { it.size })
    check("page limit", pages.all { it.size <= Screenplay.LINES_PER_PAGE })
    check("no scene at bottom", pages.all { p -> p.takeLast(2).none { it.type == LineType.SCENE } })
    check("wrap", Screenplay.wrap("một hai ba bốn năm", 7) == listOf("một hai", "ba bốn", "năm"))
    val bigDia = "LAN\n" + "chữ ".repeat(800)
    val p2 = Screenplay.paginate(listOf(Screenplay.ExportPart(null, "T", bigDia)), false)
    check("dialogue split", p2.size >= 2 && p2.all { it.size <= 55 } && p2[1].first().text.endsWith("(TIẾP)"))
        }
}
