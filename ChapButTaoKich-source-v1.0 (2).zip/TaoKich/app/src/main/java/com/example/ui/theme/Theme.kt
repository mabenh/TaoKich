package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ImperialGold,
    onPrimary = Color(0xFF2C1E0A),
    primaryContainer = Color(0xFF4A1212),
    onPrimaryContainer = Color(0xFFFFDDB8),
    secondary = ImperialGoldLight,
    onSecondary = Color(0xFF332000),
    background = Color(0xFF140F0D),
    onBackground = Color(0xFFF5EBE1),
    surface = Color(0xFF1E1714),
    onSurface = Color(0xFFF5EBE1),
    surfaceVariant = Color(0xFF2E231F),
    onSurfaceVariant = Color(0xFFD6C3B4)
)

private val LightColorScheme = lightColorScheme(
    primary = ImperialRed,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD6),
    onPrimaryContainer = Color(0xFF410002),
    secondary = ImperialGoldDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF0D4),
    onSecondaryContainer = Color(0xFF2E1900),
    background = AntiqueParchment,
    onBackground = TextPrimaryDark,
    surface = Color(0xFFFFFDF8),
    onSurface = TextPrimaryDark,
    surfaceVariant = AntiqueParchmentDark,
    onSurfaceVariant = TextSecondaryDark
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
