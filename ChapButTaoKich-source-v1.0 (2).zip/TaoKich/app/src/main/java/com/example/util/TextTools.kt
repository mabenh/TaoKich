package com.example.util

import java.text.Normalizer

/**
 * Các hàm xử lý chữ dùng chung (thuần Kotlin, không phụ thuộc Android để kiểm thử được trên JVM).
 */
object TextTools {

    private val COMBINING_MARKS = Regex("\\p{Mn}+")

    /** Chữ thường, bỏ dấu tiếng Việt (đ → d). Dùng cho tìm kiếm gõ không dấu. */
    fun fold(s: String): String {
        val lower = s.lowercase()
        val decomposed = Normalizer.normalize(lower, Normalizer.Form.NFD)
        return COMBINING_MARKS.replace(decomposed, "").replace('đ', 'd')
    }

    /** [query] (có dấu hoặc không dấu) có nằm trong [text] không. */
    fun matches(text: String, query: String): Boolean {
        val q = fold(query.trim())
        if (q.isEmpty()) return true
        return fold(text).contains(q)
    }

    private fun isWordChar(c: Char): Boolean = c.isLetterOrDigit() || c == '_'

    /** Các vị trí [word] xuất hiện như một từ trọn vẹn (không nằm trong từ khác). Phân biệt hoa thường. */
    fun wholeWordRanges(text: String, word: String): List<IntRange> {
        if (word.isEmpty() || text.length < word.length) return emptyList()
        val out = ArrayList<IntRange>()
        var from = 0
        while (true) {
            val i = text.indexOf(word, from)
            if (i < 0) break
            val end = i + word.length
            val okBefore = i == 0 || !isWordChar(text[i - 1])
            val okAfter = end >= text.length || !isWordChar(text[end])
            if (okBefore && okAfter) {
                out.add(i until end)
                from = end
            } else {
                from = i + 1
            }
        }
        return out
    }

    fun countWholeWord(text: String, word: String): Int = wholeWordRanges(text, word).size

    /** Thay [old] bằng [new] ở các chỗ là từ trọn vẹn. Trả về văn bản mới và số chỗ đã thay. */
    fun replaceWholeWord(text: String, old: String, new: String): Pair<String, Int> {
        val ranges = wholeWordRanges(text, old)
        if (ranges.isEmpty()) return text to 0
        val sb = StringBuilder(text.length + ranges.size * (new.length - old.length).coerceAtLeast(0))
        var last = 0
        for (r in ranges) {
            sb.append(text, last, r.first).append(new)
            last = r.last + 1
        }
        sb.append(text, last, text.length)
        return sb.toString() to ranges.size
    }

    /** Tách tên nhân vật + biệt danh thành danh sách tên cần tìm (bỏ trùng, bỏ rỗng). */
    fun namesOf(name: String, aliases: String): List<String> =
        (listOf(name) + aliases.split(',', ';'))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()

    /** Tổng số lần xuất hiện của bất kỳ tên nào trong [names]. */
    fun countNames(text: String, names: List<String>): Int {
        if (names.isEmpty() || text.isEmpty()) return 0
        // Tên dài trước để "Lý Thanh Vân" không bị đếm thêm lần nữa ở "Thanh Vân"
        val taken = BooleanArray(text.length)
        var count = 0
        for (n in names.sortedByDescending { it.length }) {
            for (r in wholeWordRanges(text, n)) {
                if (r.any { taken[it] }) continue
                r.forEach { taken[it] = true }
                count++
            }
        }
        return count
    }

    /**
     * Tách văn bản thành các câu để đọc bằng giọng nói. Mỗi phần tử là khoảng [start, end) trong văn bản gốc,
     * đã bỏ khoảng trắng hai đầu. Câu kết thúc ở . ! ? … (kèm ngoặc/nháy đóng ngay sau) hoặc ở xuống dòng.
     */
    fun sentenceRanges(text: String, from: Int = 0): List<IntRange> {
        val out = ArrayList<IntRange>()
        val n = text.length
        var start = from.coerceIn(0, n)
        var i = start
        fun emit(endExclusive: Int) {
            var a = start
            var b = endExclusive
            while (a < b && text[a].isWhitespace()) a++
            while (b > a && text[b - 1].isWhitespace()) b--
            if (b > a && text.substring(a, b).any { it.isLetterOrDigit() }) out.add(a until b)
            start = endExclusive
        }
        while (i < n) {
            val c = text[i]
            when {
                c == '\n' -> { emit(i); i++ ; start = i }
                c == '.' || c == '!' || c == '?' || c == '…' -> {
                    var j = i + 1
                    while (j < n && (text[j] == '.' || text[j] == '!' || text[j] == '?' || text[j] == '…')) j++
                    while (j < n && text[j] in CLOSERS) j++
                    // Không tách ở số thập phân "3.5" hay chữ viết tắt dính liền chữ cái kế tiếp
                    if (j < n && !text[j].isWhitespace() && c == '.') { i = j; continue }
                    emit(j)
                    i = j
                }
                else -> i++
            }
        }
        if (start < n) emit(n)
        return out
    }

    private const val CLOSERS = "\"'”’»)]」』"

    fun wordCount(text: String): Int {
        if (text.isBlank()) return 0
        return text.trim().split(Regex("""\s+""")).count { it.isNotBlank() }
    }
}

/** Phân loại thiết lập bối cảnh (bản 1.5, giống Chấp Bút 1.7). */
object WorldCategories {
    val ALL: List<Pair<String, String>> = listOf(
        "LOCATION" to "Địa danh/Thế giới",
        "FACTION" to "Thế lực/Hệ phái",
        "CLASS" to "Giai cấp/Địa vị",
        "MAGIC_POWER" to "Thể chất/Sức mạnh",
        "TALENT" to "Thiên phú/Kĩ năng",
        "ITEM" to "Vật phẩm/Công cụ",
        "OTHER" to "Khác"
    )

    private val KEYS = ALL.map { it.first }.toSet()

    /** Mã phân loại hợp lệ (mã cũ không còn dùng → OTHER). */
    fun normalize(key: String): String = if (key in KEYS) key else "OTHER"

    /** Nhãn cần thêm khi chuyển mã cũ (ví dụ HISTORY → nhãn "Lịch sử"). */
    fun legacyTag(key: String): String = when (key) {
        "HISTORY" -> "Lịch sử"
        else -> ""
    }

    fun label(key: String): String = ALL.firstOrNull { it.first == key }?.second ?: "Khác"

    fun mergeTags(tags: String, extra: String): String {
        if (extra.isBlank()) return tags
        val list = tags.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        return if (list.any { it.equals(extra, ignoreCase = true) }) list.joinToString(", ")
        else (list + extra).joinToString(", ")
    }
}
