package com.example.viewmodel

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.BackupRecord
import com.example.data.local.entities.Chapter
import com.example.data.local.entities.Novel
import com.example.data.remote.GoogleAccountInfo
import com.example.data.remote.GoogleDriveBackupFile
import com.example.data.remote.GoogleDriveManager
import com.example.data.repository.BackupRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class BackupViewModel(
    private val repository: BackupRepository,
    private val googleDriveManager: GoogleDriveManager
) : ViewModel() {

    val backups: StateFlow<List<BackupRecord>> = repository.allBackups
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isBackingUp = MutableStateFlow(false)
    val isBackingUp: StateFlow<Boolean> = _isBackingUp.asStateFlow()

    private val _isDriveLoading = MutableStateFlow(false)
    val isDriveLoading: StateFlow<Boolean> = _isDriveLoading.asStateFlow()

    private val _googleAccount = MutableStateFlow<GoogleAccountInfo?>(null)
    val googleAccount: StateFlow<GoogleAccountInfo?> = _googleAccount.asStateFlow()

    private val _driveBackups = MutableStateFlow<List<GoogleDriveBackupFile>>(emptyList())
    val driveBackups: StateFlow<List<GoogleDriveBackupFile>> = _driveBackups.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        try {
            checkCurrentGoogleAccount()
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    fun clearMessage() {
        _message.value = null
    }

    fun checkCurrentGoogleAccount() {
        try {
            val account = googleDriveManager.getCurrentAccount()
            _googleAccount.value = account
            if (account != null) {
                refreshDriveBackups()
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    fun getGoogleSignInIntent(): Intent? {
        return try {
            googleDriveManager.getSignInIntent()
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    fun handleSignInResult(data: Intent?) {
        val result = googleDriveManager.handleSignInResult(data)
        result.onSuccess { account ->
            _googleAccount.value = account
            _message.value = "Đăng nhập thành công: ${account.displayName} (${account.email})"
            refreshDriveBackups()
        }.onFailure { e ->
            // If running on emulator or Google Play Services has issue, provide clear friendly message
            _message.value = "Đăng nhập Google thất bại: ${e.localizedMessage ?: "Vui lòng thử lại"}"
        }
    }

    fun signOutGoogle() {
        viewModelScope.launch {
            _isDriveLoading.value = true
            googleDriveManager.signOut()
            _googleAccount.value = null
            _driveBackups.value = emptyList()
            _isDriveLoading.value = false
            _message.value = "Đã đăng xuất khỏi tài khoản Google."
        }
    }

    fun refreshDriveBackups() {
        viewModelScope.launch {
            _isDriveLoading.value = true
            val result = googleDriveManager.listBackups()
            result.onSuccess { list ->
                _driveBackups.value = list
            }.onFailure { e ->
                // Provide context
                _message.value = "Không thể tải danh sách Google Drive: ${e.localizedMessage}"
            }
            _isDriveLoading.value = false
        }
    }

    fun createBackup(name: String? = null) {
        viewModelScope.launch {
            _isBackingUp.value = true
            try {
                val record = repository.createFullJsonBackup(name)
                _message.value = "Đã sao lưu cục bộ thành công (${record.novelCount} kịch bản, ${record.chapterCount} phân đoạn/tập)!"
            } catch (e: Exception) {
                _message.value = "Lỗi khi sao lưu: ${e.localizedMessage}"
            } finally {
                _isBackingUp.value = false
            }
        }
    }

    /**
     * Creates a local backup and immediately uploads it to Google Drive.
     */
    fun backupAndUploadToDrive(name: String? = null) {
        viewModelScope.launch {
            _isBackingUp.value = true
            _isDriveLoading.value = true
            try {
                val record = repository.createFullJsonBackup(name)
                val file = File(record.filePath)
                val uploadResult = googleDriveManager.uploadBackupFile(file, record.backupName)
                uploadResult.onSuccess { driveFile ->
                    _message.value = "Đã sao lưu lên Google Drive thành công (${driveFile.name})!"
                    refreshDriveBackups()
                }.onFailure { e ->
                    _message.value = "Đã sao lưu cục bộ, nhưng tải lên Google Drive thất bại: ${e.localizedMessage}"
                }
            } catch (e: Exception) {
                _message.value = "Lỗi sao lưu Google Drive: ${e.localizedMessage}"
            } finally {
                _isBackingUp.value = false
                _isDriveLoading.value = false
            }
        }
    }

    /**
     * Upload an existing local backup record to Google Drive.
     */
    fun uploadLocalBackupToDrive(record: BackupRecord) {
        viewModelScope.launch {
            _isDriveLoading.value = true
            val file = File(record.filePath)
            if (!file.exists()) {
                _message.value = "Không tìm thấy tệp cục bộ để tải lên."
                _isDriveLoading.value = false
                return@launch
            }
            val result = googleDriveManager.uploadBackupFile(file, record.backupName)
            result.onSuccess { driveFile ->
                _message.value = "Đã tải bản lưu '${record.backupName}' lên Google Drive!"
                refreshDriveBackups()
            }.onFailure { e ->
                _message.value = "Lỗi tải lên Drive: ${e.localizedMessage}"
            }
            _isDriveLoading.value = false
        }
    }

    /**
     * Download a backup from Google Drive and restore into local Room database.
     */
    fun restoreFromDrive(driveFile: GoogleDriveBackupFile, context: Context) {
        viewModelScope.launch {
            _isDriveLoading.value = true
            try {
                val tempDir = File(context.cacheDir, "drive_downloads").apply { if (!exists()) mkdirs() }
                // Làm sạch tên tệp từ Drive (có thể chứa "/" hoặc ".." -> ghi ra ngoài thư mục tạm)
                val safeName = driveFile.name.replace(Regex("[^A-Za-z0-9._-]"), "_").trimStart('.').ifBlank { "drive_backup.json" }
                val targetFile = File(tempDir, safeName)
                val downloadResult = googleDriveManager.downloadBackup(driveFile.id, targetFile)
                downloadResult.onSuccess { downloadedFile ->
                    val success = repository.restoreFromJsonFile(downloadedFile.absolutePath)
                    downloadedFile.delete()
                    if (success) {
                        _message.value = "Khôi phục thành công từ Google Drive (${driveFile.name})!"
                    } else {
                        _message.value = "Khôi phục thất bại: Tệp Google Drive không đúng định dạng."
                    }
                }.onFailure { e ->
                    _message.value = "Không thể tải tệp từ Google Drive: ${e.localizedMessage}"
                }
            } catch (e: Exception) {
                _message.value = "Lỗi khôi phục Drive: ${e.localizedMessage}"
            } finally {
                _isDriveLoading.value = false
            }
        }
    }

    /**
     * Delete a backup file from Google Drive.
     */
    fun deleteDriveBackup(driveFile: GoogleDriveBackupFile) {
        viewModelScope.launch {
            _isDriveLoading.value = true
            val result = googleDriveManager.deleteDriveBackup(driveFile.id)
            result.onSuccess {
                _message.value = "Đã xóa bản lưu trên Google Drive."
                refreshDriveBackups()
            }.onFailure { e ->
                _message.value = "Lỗi khi xóa trên Google Drive: ${e.localizedMessage}"
            }
            _isDriveLoading.value = false
        }
    }

    fun restoreBackup(record: BackupRecord) {
        viewModelScope.launch {
            _isBackingUp.value = true
            try {
                val success = repository.restoreFromJsonFile(record.filePath)
                if (success) {
                    _message.value = "Đã khôi phục dữ liệu thành công từ bản ${record.backupName}!"
                } else {
                    _message.value = "Khôi phục thất bại: Tệp sao lưu không hợp lệ."
                }
            } catch (e: Exception) {
                _message.value = "Lỗi khi khôi phục: ${e.localizedMessage}"
            } finally {
                _isBackingUp.value = false
            }
        }
    }

    fun deleteBackup(record: BackupRecord) {
        viewModelScope.launch {
            repository.deleteBackup(record.id, record.filePath)
            _message.value = "Đã xóa bản sao lưu."
        }
    }

    fun exportToTxt(novel: Novel, chapters: List<Chapter>): File {
        return repository.exportNovelToTxt(novel, chapters)
    }
}
