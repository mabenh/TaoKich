package com.example.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.dao.BackupDao
import com.example.data.local.entities.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupRepository(
    private val context: Context,
    private val novelRepository: NovelRepository,
    private val backupDao: BackupDao,
    private val database: AppDatabase? = null
) {
    companion object {
        const val AUTO_BACKUP_PREFIX = "Tự động sao lưu lúc thoát"
    }

    val allBackups: Flow<List<BackupRecord>> = backupDao.getAllBackups()

    suspend fun createFullJsonBackup(backupCustomName: String? = null): BackupRecord = withContext(Dispatchers.IO) {
        val novels = novelRepository.getAllNovelsDirect()
        val novelsJsonArray = JSONArray()
        var totalChapters = 0

        for (novel in novels) {
            val novelObj = JSONObject().apply {
                put("id", novel.id)
                put("title", novel.title)
                put("author", novel.author)
                put("synopsis", novel.synopsis)
                put("genre", novel.genre)
                put("wordCount", novel.wordCount)
                put("targetWordCount", novel.targetWordCount)
                put("coverColorHex", novel.coverColorHex)
                put("createdAt", novel.createdAt)
                put("updatedAt", novel.updatedAt)
                // Trước đây không lưu cờ này -> truyện trong thùng rác bị khôi phục thành truyện bình thường
                put("isDeleted", novel.isDeleted)
                put("isArchived", novel.isArchived)
                // Bản 1.5
                put("status", novel.status)
                put("isPinned", novel.isPinned)
                put("pinnedAt", novel.pinnedAt)
                put("outline", novel.outline)
                put("coverStyle", novel.coverStyle)
                put("coverBorder", novel.coverBorder)
                put("coverPaper", novel.coverPaper)
                put("coverInk", novel.coverInk)
                put("projectKind", novel.projectKind)
                // Ảnh viền / giấy tự tải lên nằm trong bộ nhớ máy, không đi kèm tệp sao lưu
            }

            val volumes = novelRepository.getVolumesDirect(novel.id)
            val volumesArray = JSONArray()
            for (vol in volumes) {
                volumesArray.put(JSONObject().apply {
                    put("id", vol.id)
                    put("novelId", vol.novelId)
                    put("title", vol.title)
                    put("orderIndex", vol.orderIndex)
                    put("description", vol.description)
                })
            }
            novelObj.put("volumes", volumesArray)

            val chapters = novelRepository.getChaptersDirect(novel.id)
            totalChapters += chapters.size
            val chaptersArray = JSONArray()
            for (ch in chapters) {
                chaptersArray.put(JSONObject().apply {
                    put("id", ch.id)
                    put("novelId", ch.novelId)
                    put("volumeId", ch.volumeId ?: -1L)
                    put("title", ch.title)
                    put("content", ch.content)
                    put("orderIndex", ch.orderIndex)
                    put("wordCount", ch.wordCount)
                    put("status", ch.status)
                    put("createdAt", ch.createdAt)
                    put("updatedAt", ch.updatedAt)
                    put("outline", ch.outline)
                    put("notes", ch.notes)
                })
            }
            novelObj.put("chapters", chaptersArray)

            val characters = novelRepository.getCharactersDirect(novel.id)
            val charsArray = JSONArray()
            for (char in characters) {
                charsArray.put(JSONObject().apply {
                    put("name", char.name)
                    put("role", char.role)
                    put("appearance", char.appearance)
                    put("personality", char.personality)
                    put("background", char.background)
                    put("notes", char.notes)
                    put("avatarEmoji", char.avatarEmoji)
                    put("avatarId", char.avatarId)
                    put("gender", char.gender)
                    put("aliases", char.aliases)
                })
            }
            novelObj.put("characters", charsArray)

            val worldNotes = novelRepository.getWorldNotesDirect(novel.id)
            val notesArray = JSONArray()
            for (note in worldNotes) {
                notesArray.put(JSONObject().apply {
                    put("title", note.title)
                    put("category", note.category)
                    put("content", note.content)
                    put("tags", note.tags)
                })
            }
            novelObj.put("worldNotes", notesArray)

            novelsJsonArray.put(novelObj)
        }

        val root = JSONObject().apply {
            put("app", "ChapBut_TaoKich")
            put("version", 1)
            put("exportedAt", System.currentTimeMillis())
            put("novels", novelsJsonArray)
        }

        val timeStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = backupCustomName ?: "SaoLuu_$timeStr"
        val backupDir = File(context.filesDir, "backups").apply { if (!exists()) mkdirs() }
        // Tên tệp trước đây chỉ chính xác tới giây -> 2 bản sao lưu trong cùng 1 giây ghi đè lên nhau,
        // và xóa 1 bản sẽ xóa luôn tệp của bản kia.
        var file = File(backupDir, "TaoKich_Backup_$timeStr.json")
        var n = 1
        while (file.exists()) {
            file = File(backupDir, "TaoKich_Backup_${timeStr}_$n.json")
            n++
        }
        // Ghi ra tệp tạm rồi đổi tên, tránh để lại tệp hỏng nếu app bị tắt giữa chừng
        val tmp = File(backupDir, file.name + ".tmp")
        tmp.writeText(root.toString(2), Charsets.UTF_8)
        if (!tmp.renameTo(file)) {
            tmp.copyTo(file, overwrite = true)
            tmp.delete()
        }

        val record = BackupRecord(
            backupName = name,
            timestamp = System.currentTimeMillis(),
            novelCount = novels.size,
            chapterCount = totalChapters,
            filePath = file.absolutePath,
            fileSizeKb = (file.length() / 1024).coerceAtLeast(1)
        )
        val id = backupDao.insertBackup(record)
        record.copy(id = id)
    }

    suspend fun restoreFromJsonFile(filePath: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            if (!file.exists()) return@withContext false
            val text = file.readText(Charsets.UTF_8)
            val root = JSONObject(text)
            val novelsArray = root.optJSONArray("novels") ?: return@withContext false

            // Chạy trong 1 transaction: nếu tệp hỏng giữa chừng thì không để lại dữ liệu khôi phục dở dang.
            if (database != null) {
                database.withTransaction { importNovels(novelsArray) }
            } else {
                importNovels(novelsArray)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private suspend fun importNovels(novelsArray: org.json.JSONArray) {
            for (i in 0 until novelsArray.length()) {
                val novelObj = novelsArray.getJSONObject(i)
                val novel = Novel(
                    title = novelObj.getString("title"),
                    author = novelObj.optString("author", "Tác giả"),
                    synopsis = novelObj.optString("synopsis", ""),
                    genre = novelObj.optString("genre", "Chính kịch"),
                    wordCount = novelObj.optInt("wordCount", 0),
                    targetWordCount = novelObj.optInt("targetWordCount", 100000),
                    coverColorHex = novelObj.optString("coverColorHex", "#8B1E1E"),
                    createdAt = novelObj.optLong("createdAt", System.currentTimeMillis()),
                    updatedAt = novelObj.optLong("updatedAt", System.currentTimeMillis()),
                    isDeleted = novelObj.optBoolean("isDeleted", false),
                    isArchived = novelObj.optBoolean("isArchived", false),
                    status = novelObj.optString("status", "WRITING"),
                    isPinned = novelObj.optBoolean("isPinned", false),
                    pinnedAt = novelObj.optLong("pinnedAt", 0L),
                    outline = novelObj.optString("outline", ""),
                    // Bản sao lưu cũ (trước 1.5) không có trường này → giữ bìa màu trơn như trước
                    coverStyle = novelObj.optString("coverStyle", "COLOR"),
                    coverBorder = novelObj.optString("coverBorder", "co-dien"),
                    coverPaper = novelObj.optString("coverPaper", "nga"),
                    coverInk = novelObj.optString("coverInk", ""),
                    projectKind = novelObj.optString("projectKind", "FILM")
                )
                val newNovelId = novelRepository.insertNovel(novel)

                val volumesArray = novelObj.optJSONArray("volumes")
                val volumeIdMap = mutableMapOf<Long, Long>()
                if (volumesArray != null) {
                    for (v in 0 until volumesArray.length()) {
                        val vObj = volumesArray.getJSONObject(v)
                        val oldVolId = vObj.optLong("id", -1L)
                        val vol = Volume(
                            novelId = newNovelId,
                            title = vObj.getString("title"),
                            orderIndex = vObj.optInt("orderIndex", v + 1),
                            description = vObj.optString("description", "")
                        )
                        val newVolId = novelRepository.insertVolume(vol)
                        if (oldVolId > 0) volumeIdMap[oldVolId] = newVolId
                    }
                }

                val chaptersArray = novelObj.optJSONArray("chapters")
                if (chaptersArray != null) {
                    for (c in 0 until chaptersArray.length()) {
                        val cObj = chaptersArray.getJSONObject(c)
                        val oldVolId = cObj.optLong("volumeId", -1L)
                        val mappedVolId = if (oldVolId > 0) volumeIdMap[oldVolId] else null
                        val chapter = Chapter(
                            novelId = newNovelId,
                            volumeId = mappedVolId,
                            title = cObj.getString("title"),
                            content = cObj.optString("content", ""),
                            orderIndex = cObj.optInt("orderIndex", c + 1),
                            wordCount = cObj.optInt("wordCount", 0),
                            status = cObj.optString("status", "DRAFT"),
                            createdAt = cObj.optLong("createdAt", System.currentTimeMillis()),
                            updatedAt = cObj.optLong("updatedAt", System.currentTimeMillis()),
                            outline = cObj.optString("outline", ""),
                            notes = cObj.optString("notes", "")
                        )
                        novelRepository.insertChapter(chapter)
                    }
                }

                val charsArray = novelObj.optJSONArray("characters")
                if (charsArray != null) {
                    for (ch in 0 until charsArray.length()) {
                        val chObj = charsArray.getJSONObject(ch)
                        novelRepository.insertCharacter(
                            CharacterProfile(
                                novelId = newNovelId,
                                name = chObj.getString("name"),
                                role = chObj.optString("role", "PROTAGONIST"),
                                appearance = chObj.optString("appearance", ""),
                                personality = chObj.optString("personality", ""),
                                background = chObj.optString("background", ""),
                                notes = chObj.optString("notes", ""),
                                avatarEmoji = chObj.optString("avatarEmoji", "👤"),
                                avatarId = chObj.optString("avatarId", ""),
                                gender = chObj.optString("gender", ""),
                                aliases = chObj.optString("aliases", "")
                            )
                        )
                    }
                }

                val notesArray = novelObj.optJSONArray("worldNotes")
                if (notesArray != null) {
                    for (wn in 0 until notesArray.length()) {
                        val wnObj = notesArray.getJSONObject(wn)
                        // Phân loại cũ (ví dụ HISTORY) được chuyển sang "Khác" và giữ tên cũ làm nhãn
                        val rawCat = wnObj.optString("category", "LOCATION")
                        novelRepository.insertWorldNote(
                            WorldNote(
                                novelId = newNovelId,
                                title = wnObj.getString("title"),
                                category = com.example.util.WorldCategories.normalize(rawCat),
                                content = wnObj.optString("content", ""),
                                tags = com.example.util.WorldCategories.mergeTags(
                                    wnObj.optString("tags", ""),
                                    com.example.util.WorldCategories.legacyTag(rawCat)
                                )
                            )
                        )
                    }
                }
            }
    }

    /** Chỉ giữ lại [keep] bản sao lưu tự động mới nhất để bộ nhớ máy không đầy dần. */
    suspend fun pruneAutoBackups(keep: Int = 10) = withContext(Dispatchers.IO) {
        val autos = backupDao.getBackupsByNamePrefix(AUTO_BACKUP_PREFIX)
        autos.drop(keep).forEach { old ->
            try { File(old.filePath).delete() } catch (_: Exception) {}
            backupDao.deleteBackupById(old.id)
        }
    }

    suspend fun deleteBackup(id: Long, filePath: String) = withContext(Dispatchers.IO) {
        try {
            File(filePath).delete()
        } catch (_: Exception) {}
        backupDao.deleteBackupById(id)
    }

    fun exportNovelToTxt(novel: Novel, chapters: List<Chapter>): File {
        val chapters = chapters.sortedBy { it.orderIndex }
        val dir = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }
        val safeTitle = novel.title.replace(Regex("[^a-zA-Z0-9\\p{L}]"), "_").take(80).ifBlank { "TacPham" }
        val file = File(dir, "${safeTitle}.txt")
        val sb = StringBuilder()
        sb.append(novel.title).append("\n")
        sb.append("Tác giả: ").append(novel.author).append("\n")
        sb.append("Thể loại: ").append(novel.genre).append("\n")
        sb.append("Tổng số từ: ").append(novel.wordCount).append("\n\n")
        sb.append("TÓM TẮT:\n").append(novel.synopsis).append("\n\n")
        sb.append("=".repeat(40)).append("\n\n")

        for (ch in chapters) {
            sb.append("### ").append(ch.title).append("\n\n")
            sb.append(ch.content).append("\n\n")
            sb.append("-".repeat(30)).append("\n\n")
        }
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }
}
