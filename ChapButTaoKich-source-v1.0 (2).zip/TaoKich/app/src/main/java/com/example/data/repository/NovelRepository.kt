package com.example.data.repository

import com.example.data.local.dao.*
import com.example.data.local.entities.*
import kotlinx.coroutines.flow.Flow

class NovelRepository(
    private val novelDao: NovelDao,
    private val volumeDao: VolumeDao,
    private val chapterDao: ChapterDao,
    private val snapshotDao: SnapshotDao,
    private val characterWorldDao: CharacterWorldDao,
    private val backupDao: BackupDao
) {
    // Novels
    val allNovels: Flow<List<Novel>> = novelDao.getAllNovels()
    val deletedNovels: Flow<List<Novel>> = novelDao.getDeletedNovels()
    val deletedChapters: Flow<List<Chapter>> = chapterDao.getDeletedChapters()

    fun getNovelFlow(id: Long): Flow<Novel?> = novelDao.getNovelFlow(id)
    suspend fun getNovelById(id: Long): Novel? = novelDao.getNovelById(id)
    suspend fun insertNovel(novel: Novel): Long = novelDao.insertNovel(novel)
    suspend fun updateNovel(novel: Novel) = novelDao.updateNovel(novel)
    suspend fun softDeleteNovel(id: Long) = novelDao.softDeleteNovel(id)
    suspend fun restoreNovel(id: Long) = novelDao.restoreNovel(id)
    suspend fun hardDeleteNovel(id: Long) = novelDao.hardDeleteNovel(id)
    suspend fun emptyTrash() {
        // Trước đây chỉ xóa tiểu thuyết => các chương đã xóa vẫn nằm mãi trong thùng rác.
        novelDao.emptyTrash()
        chapterDao.emptyChapterTrash()
    }

    // Volumes
    fun getVolumes(novelId: Long): Flow<List<Volume>> = volumeDao.getVolumesByNovel(novelId)
    suspend fun insertVolume(volume: Volume): Long = volumeDao.insertVolume(volume)
    suspend fun updateVolume(volume: Volume) = volumeDao.updateVolume(volume)
    suspend fun deleteVolume(volume: Volume) = volumeDao.deleteVolume(volume)
    suspend fun deleteVolumeById(id: Long) = volumeDao.deleteVolumeById(id)

    /**
     * Xóa quyển. [deleteChapters] = true: các chương trong quyển vào thùng rác;
     * false: giữ chương, chuyển sang "Chưa phân quyển".
     */
    suspend fun deleteVolumeSafely(volume: Volume, deleteChapters: Boolean) {
        if (deleteChapters) {
            chapterDao.softDeleteChaptersInVolume(volume.id, System.currentTimeMillis())
        }
        // Luôn gỡ liên kết để chương (kể cả khi khôi phục từ thùng rác) không trỏ tới quyển đã mất
        chapterDao.detachChaptersFromVolume(volume.id)
        volumeDao.deleteVolumeById(volume.id)
        recalculateNovelWordCount(volume.novelId)
    }

    // Chapters
    fun getChapters(novelId: Long): Flow<List<Chapter>> = chapterDao.getChaptersByNovel(novelId)
    fun getChaptersByVolume(volumeId: Long): Flow<List<Chapter>> = chapterDao.getChaptersByVolume(volumeId)
    fun getChapterFlow(id: Long): Flow<Chapter?> = chapterDao.getChapterFlow(id)
    suspend fun getChapterById(id: Long): Chapter? = chapterDao.getChapterById(id)
    suspend fun insertChapter(chapter: Chapter): Long {
        val id = chapterDao.insertChapter(chapter)
        recalculateNovelWordCount(chapter.novelId)
        return id
    }
    suspend fun updateChapter(chapter: Chapter) {
        chapterDao.updateChapter(chapter)
        recalculateNovelWordCount(chapter.novelId)
    }
    suspend fun softDeleteChapter(id: Long, novelId: Long) {
        chapterDao.softDeleteChapter(id)
        recalculateNovelWordCount(novelId)
    }
    suspend fun restoreChapter(id: Long, novelId: Long) {
        chapterDao.restoreChapter(id)
        recalculateNovelWordCount(novelId)
    }
    suspend fun hardDeleteChapter(id: Long) = chapterDao.hardDeleteChapter(id)
    suspend fun updateChapterVolume(chapterId: Long, volumeId: Long?) =
        chapterDao.updateChapterVolume(chapterId, volumeId)

    private suspend fun recalculateNovelWordCount(novelId: Long) {
        val novel = novelDao.getNovelById(novelId) ?: return
        val totalWords = chapterDao.getTotalWordCount(novelId) ?: 0
        novelDao.updateNovel(novel.copy(wordCount = totalWords, updatedAt = System.currentTimeMillis()))
    }

    // Snapshots
    fun getSnapshots(chapterId: Long): Flow<List<ChapterSnapshot>> = snapshotDao.getSnapshotsByChapter(chapterId)
    suspend fun insertSnapshot(snapshot: ChapterSnapshot): Long = snapshotDao.insertSnapshot(snapshot)
    suspend fun deleteSnapshot(id: Long) = snapshotDao.deleteSnapshotById(id)

    // Characters
    fun getCharacters(novelId: Long): Flow<List<CharacterProfile>> =
        characterWorldDao.getCharactersByNovel(novelId)
    suspend fun insertCharacter(character: CharacterProfile): Long =
        characterWorldDao.insertCharacter(character)
    suspend fun updateCharacter(character: CharacterProfile) =
        characterWorldDao.updateCharacter(character)
    suspend fun deleteCharacter(character: CharacterProfile) =
        characterWorldDao.deleteCharacter(character)
    suspend fun deleteCharacterById(id: Long) =
        characterWorldDao.deleteCharacterById(id)

    // World Notes
    fun getWorldNotes(novelId: Long): Flow<List<WorldNote>> =
        characterWorldDao.getWorldNotesByNovel(novelId)
    suspend fun insertWorldNote(note: WorldNote): Long =
        characterWorldDao.insertWorldNote(note)
    suspend fun updateWorldNote(note: WorldNote) =
        characterWorldDao.updateWorldNote(note)
    suspend fun deleteWorldNote(note: WorldNote) =
        characterWorldDao.deleteWorldNote(note)
    suspend fun deleteWorldNoteById(id: Long) =
        characterWorldDao.deleteWorldNoteById(id)

    // ---- Bản 1.5 ----
    suspend fun getVolumesList(novelId: Long): List<Volume> = volumeDao.getVolumesByNovelDirect(novelId)

    /** Cập nhật nội dung chương mà không đổi số chữ của truyện nhiều lần (dùng khi thay hàng loạt). */
    suspend fun updateChapterRaw(chapter: Chapter) = chapterDao.updateChapter(chapter)

    suspend fun recalcWordCount(novelId: Long) = recalculateNovelWordCount(novelId)

    // Raw exports
    suspend fun getAllNovelsDirect() = novelDao.getAllNovelsDirect()
    suspend fun getVolumesDirect(novelId: Long) = volumeDao.getVolumesByNovelDirect(novelId)
    suspend fun getChaptersDirect(novelId: Long) = chapterDao.getChaptersByNovelDirect(novelId)
    suspend fun getCharactersDirect(novelId: Long) = characterWorldDao.getCharactersByNovelDirect(novelId)
    suspend fun getWorldNotesDirect(novelId: Long) = characterWorldDao.getWorldNotesByNovelDirect(novelId)
}
