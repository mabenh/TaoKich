package com.example.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.BackupRecord
import com.example.data.remote.GoogleDriveBackupFile
import com.example.viewmodel.BackupViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    backupViewModel: BackupViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val backups by backupViewModel.backups.collectAsState()
    val isBackingUp by backupViewModel.isBackingUp.collectAsState()
    val isDriveLoading by backupViewModel.isDriveLoading.collectAsState()
    val googleAccount by backupViewModel.googleAccount.collectAsState()
    val driveBackups by backupViewModel.driveBackups.collectAsState()
    val message by backupViewModel.message.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var restoringLocalBackup by remember { mutableStateOf<BackupRecord?>(null) }
    var deletingLocalBackup by remember { mutableStateOf<BackupRecord?>(null) }
    var restoringDriveBackup by remember { mutableStateOf<GoogleDriveBackupFile?>(null) }
    var deletingDriveBackup by remember { mutableStateOf<GoogleDriveBackupFile?>(null) }
    var showSignOutConfirm by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("HH:mm - dd/MM/yyyy", Locale.getDefault()) }

    val signInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // Google Sign-In thường trả RESULT_CANCELED kèm mã lỗi thật (vd 10 = DEVELOPER_ERROR khi SHA-1
        // chưa đăng ký). Trước đây mọi lỗi đều hiện "Đã hủy" nên không biết nguyên nhân.
        if (result.resultCode == Activity.RESULT_OK || result.data != null) {
            backupViewModel.handleSignInResult(result.data)
        } else {
            Toast.makeText(context, "Đã hủy đăng nhập Google", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(message) {
        message?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            backupViewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Sao Lưu & Đồng Bộ",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("btn_back_backup")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                    }
                },
                actions = {
                    if (googleAccount != null) {
                        IconButton(
                            onClick = { backupViewModel.refreshDriveBackups() },
                            modifier = Modifier.testTag("btn_refresh_drive")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Làm mới đám mây")
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = {
                    Icon(
                        imageVector = if (selectedTabIndex == 0 && googleAccount != null) Icons.Default.CloudUpload else Icons.Default.Save,
                        contentDescription = null
                    )
                },
                text = {
                    Text(
                        text = if (selectedTabIndex == 0 && googleAccount != null) "Sao Lưu Lên Drive" else "Tạo Bản Sao Lưu",
                        fontWeight = FontWeight.Bold
                    )
                },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("fab_create_backup")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Google Account Status Card
            GoogleAccountSection(
                account = googleAccount,
                isLoading = isDriveLoading,
                onSignInClick = {
                    try {
                        val intent = backupViewModel.getGoogleSignInIntent()
                        if (intent != null) {
                            signInLauncher.launch(intent)
                        } else {
                            Toast.makeText(context, "Dịch vụ Google Play chưa sẵn sàng trên thiết bị này.", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "Không thể khởi động đăng nhập Google: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                },
                onSignOutClick = { showSignOutConfirm = true },
                onBackupToDriveClick = { backupViewModel.backupAndUploadToDrive() }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Tab Switcher: Google Drive vs Local Storage
            TabRow(
                selectedTabIndex = selectedTabIndex,
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CloudDone,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Google Drive (${driveBackups.size})", fontSize = 13.sp)
                        }
                    },
                    modifier = Modifier.testTag("tab_google_drive")
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Trên Máy (${backups.size})", fontSize = 13.sp)
                        }
                    },
                    modifier = Modifier.testTag("tab_local_backup")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isBackingUp || isDriveLoading) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )
            }

            // Tab Content
            if (selectedTabIndex == 0) {
                // Google Drive Backups Tab
                GoogleDriveTabContent(
                    account = googleAccount,
                    driveBackups = driveBackups,
                    isLoading = isDriveLoading,
                    onSignInClick = {
                        try {
                            val intent = backupViewModel.getGoogleSignInIntent()
                            if (intent != null) {
                                signInLauncher.launch(intent)
                            } else {
                                Toast.makeText(context, "Dịch vụ Google Play chưa sẵn sàng.", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "Lỗi đăng nhập: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    onRestore = { driveFile -> restoringDriveBackup = driveFile },
                    onDelete = { driveFile -> deletingDriveBackup = driveFile }
                )
            } else {
                // Local Storage Backups Tab
                LocalBackupsTabContent(
                    backups = backups,
                    dateFormat = dateFormat,
                    googleAccount = googleAccount,
                    onRestore = { localRecord -> restoringLocalBackup = localRecord },
                    onUploadToDrive = { localRecord -> backupViewModel.uploadLocalBackupToDrive(localRecord) },
                    onDelete = { localRecord -> deletingLocalBackup = localRecord }
                )
            }
        }
    }

    // Dialog: Create Backup
    if (showCreateDialog) {
        var name by remember { mutableStateOf("") }
        var uploadToDriveChecked by remember { mutableStateOf(googleAccount != null) }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Tạo Bản Sao Lưu Mới", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Tên ghi nhớ (Để trống lấy ngày giờ)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_backup_name")
                    )

                    if (googleAccount != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { uploadToDriveChecked = !uploadToDriveChecked }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = uploadToDriveChecked,
                                onCheckedChange = { uploadToDriveChecked = it }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Đồng bộ lên Google Drive",
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Tải lên tài khoản ${googleAccount?.email}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val customName = name.ifBlank { null }
                        if (uploadToDriveChecked && googleAccount != null) {
                            backupViewModel.backupAndUploadToDrive(customName)
                        } else {
                            backupViewModel.createBackup(customName)
                        }
                        showCreateDialog = false
                    },
                    modifier = Modifier.testTag("btn_confirm_create_backup")
                ) {
                    Text(if (uploadToDriveChecked && googleAccount != null) "Sao Lưu & Tải Lên Drive" else "Bắt Đầu Sao Lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Hủy") }
            }
        )
    }

    // Dialog: Restore Local
    if (restoringLocalBackup != null) {
        val record = restoringLocalBackup!!
        AlertDialog(
            onDismissRequest = { restoringLocalBackup = null },
            title = { Text("Xác Nhận Khôi Phục Dữ Liệu", fontWeight = FontWeight.Bold) },
            text = {
                Text("Dữ liệu từ bản '${record.backupName}' trên máy (${record.novelCount} kịch bản, ${record.chapterCount} phân đoạn/tập) sẽ được THÊM vào ứng dụng dưới dạng bản sao (kịch bản hiện có không bị ghi đè). Bạn có chắc chắn?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        restoringLocalBackup = null
                        backupViewModel.restoreBackup(record)
                    }
                ) {
                    Text("Đồng ý khôi phục")
                }
            },
            dismissButton = {
                TextButton(onClick = { restoringLocalBackup = null }) { Text("Hủy") }
            }
        )
    }

    // Dialog: Restore Drive
    if (restoringDriveBackup != null) {
        val driveFile = restoringDriveBackup!!
        AlertDialog(
            onDismissRequest = { restoringDriveBackup = null },
            title = { Text("Khôi Phục Từ Google Drive", fontWeight = FontWeight.Bold) },
            text = {
                Text("Ứng dụng sẽ tải bản sao lưu '${driveFile.name}' từ Google Drive và THÊM các kịch bản trong đó vào máy dưới dạng bản sao (kịch bản hiện có không bị ghi đè). Bạn có muốn tiếp tục?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        restoringDriveBackup = null
                        backupViewModel.restoreFromDrive(driveFile, context)
                    }
                ) {
                    Text("Tải & Khôi Phục")
                }
            },
            dismissButton = {
                TextButton(onClick = { restoringDriveBackup = null }) { Text("Hủy") }
            }
        )
    }

    // Dialog: Delete Local
    if (deletingLocalBackup != null) {
        val record = deletingLocalBackup!!
        AlertDialog(
            onDismissRequest = { deletingLocalBackup = null },
            title = { Text("Xóa Bản Sao Lưu Cục Bộ", fontWeight = FontWeight.Bold) },
            text = {
                Text("Bạn có chắc chắn muốn xóa tệp '${record.backupName}' khỏi bộ nhớ máy?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        deletingLocalBackup = null
                        backupViewModel.deleteBackup(record)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xóa")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingLocalBackup = null }) { Text("Hủy") }
            }
        )
    }

    // Dialog: Delete Drive
    if (deletingDriveBackup != null) {
        val driveFile = deletingDriveBackup!!
        AlertDialog(
            onDismissRequest = { deletingDriveBackup = null },
            title = { Text("Xóa Bản Sao Lưu Trên Drive", fontWeight = FontWeight.Bold) },
            text = {
                Text("Bạn có chắc chắn muốn xóa vĩnh viễn '${driveFile.name}' khỏi tài khoản Google Drive?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        deletingDriveBackup = null
                        backupViewModel.deleteDriveBackup(driveFile)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xóa khỏi Drive")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingDriveBackup = null }) { Text("Hủy") }
            }
        )
    }

    // Dialog: Sign Out Confirm
    if (showSignOutConfirm) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirm = false },
            title = { Text("Đăng Xuất Google Drive", fontWeight = FontWeight.Bold) },
            text = {
                Text("Bạn có muốn đăng xuất khỏi tài khoản Google (${googleAccount?.email})? Các bản sao lưu đã tải lên Drive vẫn được bảo toàn nguyên vẹn trên đám mây.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutConfirm = false
                        backupViewModel.signOutGoogle()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Đăng xuất")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirm = false }) { Text("Hủy") }
            }
        )
    }
}

@Composable
fun GoogleAccountSection(
    account: com.example.data.remote.GoogleAccountInfo?,
    isLoading: Boolean,
    onSignInClick: () -> Unit,
    onSignOutClick: () -> Unit,
    onBackupToDriveClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (account != null)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            else
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("card_google_account")
    ) {
        if (account == null) {
            // Not Signed In
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudSync,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Liên Kết Google Drive",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Đăng nhập Google để lưu trữ đám mây tự động, chống mất dữ liệu khi đổi điện thoại.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onSignInClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_google_signin"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Đăng Nhập Tài Khoản Google", fontWeight = FontWeight.SemiBold)
                }
            }
        } else {
            // Signed In
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Avatar / Initials
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF4285F4)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = account.displayName.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = account.displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFF2E7D32).copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Đã kết nối",
                                    color = Color(0xFF2E7D32),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = account.email,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    IconButton(
                        onClick = onSignOutClick,
                        modifier = Modifier.size(34.dp).testTag("btn_google_signout")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "Đăng xuất",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = onBackupToDriveClick,
                        modifier = Modifier.weight(1f).testTag("btn_quick_backup_drive"),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudUpload,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Lưu Lên Drive Ngay", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun GoogleDriveTabContent(
    account: com.example.data.remote.GoogleAccountInfo?,
    driveBackups: List<GoogleDriveBackupFile>,
    isLoading: Boolean,
    onSignInClick: () -> Unit,
    onRestore: (GoogleDriveBackupFile) -> Unit,
    onDelete: (GoogleDriveBackupFile) -> Unit
) {
    if (account == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.CloudOff,
                    contentDescription = null,
                    modifier = Modifier.size(52.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Chưa kết nối Google Drive",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = "Hãy đăng nhập tài khoản Google ở phía trên để xem và khôi phục các bản sao lưu từ đám mây.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                Button(onClick = onSignInClick, shape = RoundedCornerShape(8.dp)) {
                    Text("Đăng nhập Google")
                }
            }
        }
    } else if (driveBackups.isEmpty() && !isLoading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.CloudQueue,
                    contentDescription = null,
                    modifier = Modifier.size(52.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Chưa có bản sao lưu nào trên Google Drive",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Bấm nút 'Tạo Bản Sao Lưu' để tải bản thảo đầu tiên lên Google Drive của bạn.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(driveBackups, key = { it.id }) { file ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("drive_backup_card_${file.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF4285F4).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = Color(0xFF4285F4)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = file.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val sizeKb = (file.sizeBytes / 1024).coerceAtLeast(1)
                            Text(
                                text = "Dung lượng: $sizeKb KB • Google Drive",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (file.modifiedTime.isNotBlank()) {
                                Text(
                                    text = "Đồng bộ: ${file.modifiedTime.take(19).replace("T", " ")}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }

                        TextButton(onClick = { onRestore(file) }) {
                            Text("Khôi phục", fontSize = 12.sp)
                        }

                        IconButton(
                            onClick = { onDelete(file) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Xóa khỏi Drive",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LocalBackupsTabContent(
    backups: List<BackupRecord>,
    dateFormat: SimpleDateFormat,
    googleAccount: com.example.data.remote.GoogleAccountInfo?,
    onRestore: (BackupRecord) -> Unit,
    onUploadToDrive: (BackupRecord) -> Unit,
    onDelete: (BackupRecord) -> Unit
) {
    if (backups.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Backup,
                    contentDescription = null,
                    modifier = Modifier.size(52.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Chưa có bản sao lưu trên máy",
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Hãy tạo bản sao lưu để lưu trữ vào bộ nhớ thiết bị.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(backups, key = { it.id }) { record ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("backup_card_${record.id}")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.secondaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderZip,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = record.backupName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "${record.novelCount} kịch bản • ${record.chapterCount} phân đoạn/tập • ${record.fileSizeKb} KB",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = dateFormat.format(Date(record.timestamp)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (googleAccount != null) {
                                TextButton(
                                    onClick = { onUploadToDrive(record) }
                                ) {
                                    Icon(
                                        Icons.Default.CloudUpload,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Lên Drive", fontSize = 12.sp)
                                }
                            }

                            TextButton(onClick = { onRestore(record) }) {
                                Text("Khôi phục", fontSize = 12.sp)
                            }

                            IconButton(
                                onClick = { onDelete(record) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Xóa bản lưu",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
