package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entities.Novel
import com.example.ui.components.BookCover
import com.example.ui.components.CoverPicker
import com.example.ui.state.CoverDesign
import com.example.ui.state.LibrarySort
import com.example.ui.state.NovelStatus
import com.example.ui.state.ProjectKind
import com.example.ui.state.termsOf
import com.example.util.BookImporter
import com.example.util.Screenplay
import com.example.viewmodel.NovelViewModel
import com.example.viewmodel.coverDesign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovelListScreen(
    novelViewModel: NovelViewModel,
    onSelectNovel: (Long) -> Unit,
    onOpenBackup: () -> Unit,
    onOpenTrash: () -> Unit
) {
    val allNovels by novelViewModel.novels.collectAsState()
    val novels by novelViewModel.libraryNovels.collectAsState()
    val query by novelViewModel.libraryQuery.collectAsState()
    val statusFilter by novelViewModel.libraryStatus.collectAsState()
    val genreFilter by novelViewModel.libraryGenre.collectAsState()
    val sort by novelViewModel.librarySort.collectAsState()
    val genres by novelViewModel.libraryGenres.collectAsState()
    val kindFilter by novelViewModel.libraryKind.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var showGenreMenu by remember { mutableStateOf(false) }

    // ---- Nhập kịch bản: Fountain / TXT / Word ----
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingImport by remember { mutableStateOf<((String) -> Screenplay.ImportedScript)?>(null) }
    var importing by remember { mutableStateOf(false) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            importing = true
            scope.launch {
                val result: ((String) -> Screenplay.ImportedScript)? = withContext(Dispatchers.IO) {
                    try {
                        val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "Kịch bản nhập"
                        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalStateException("Không mở được tệp")
                        val title = name.substringBeforeLast('.').ifBlank { "Kịch bản nhập" }
                        val lower = name.lowercase()
                        when {
                            lower.endsWith(".doc") -> throw IllegalArgumentException("Chỉ đọc được tệp .docx (Word 2007 trở lên)")
                            lower.endsWith(".docx") -> {
                                // Word: Heading 1 = Hồi / Mùa, Heading 2 = Phân đoạn / Tập
                                val book = BookImporter.parseDocx(bytes, title)
                                val fn: (String) -> Screenplay.ImportedScript = { kind ->
                                    val t = termsOf(kind)
                                    Screenplay.ImportedScript(
                                        title, "",
                                        book.volumes.mapIndexed { vi, v ->
                                            Screenplay.ImportedVolume(
                                                if (v.title.startsWith("Quyển ")) "${t.volName} ${vi + 1}" else v.title,
                                                v.chapters.mapIndexed { ci, c ->
                                                    Screenplay.ImportedChapter(
                                                        if (c.title.startsWith("Chương ")) "${t.chapName} ${ci + 1}" else c.title,
                                                        c.content, ""
                                                    )
                                                }
                                            )
                                        }
                                    )
                                }
                                fn
                            }
                            else -> {
                                val text = BookImporter.decodeText(bytes)
                                val fn: (String) -> Screenplay.ImportedScript = { kind ->
                                    val t = termsOf(kind)
                                    Screenplay.parseFountain(text, title, t.volName, t.chapName)
                                }
                                fn
                            }
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("NovelList", "Import failed", e)
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Không đọc được tệp: ${e.message ?: "lỗi không rõ"}", Toast.LENGTH_LONG).show()
                        }
                        null
                    }
                }
                importing = false
                pendingImport = result
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.logo_v),
                            contentDescription = null,
                            modifier = Modifier.size(38.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Chấp Bút Tạo Kịch",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Góc Sáng Tác Kịch Bản Phim",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            importLauncher.launch(
                                arrayOf(
                                    "text/*",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "application/octet-stream"
                                )
                            )
                        },
                        modifier = Modifier.testTag("btn_import_file")
                    ) {
                        Icon(imageVector = Icons.Default.FileUpload, contentDescription = "Nhập kịch bản (Fountain / TXT / Word)")
                    }
                    IconButton(
                        onClick = onOpenBackup,
                        modifier = Modifier.testTag("btn_open_backup")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudSync,
                            contentDescription = "Sao lưu & Khôi phục"
                        )
                    }
                    IconButton(
                        onClick = onOpenTrash,
                        modifier = Modifier.testTag("btn_open_trash")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Thùng rác"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Tạo Kịch Bản", fontWeight = FontWeight.Bold) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_create_novel")
            )
        }
    ) { padding ->
        if (allNovels.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Image(
                        painter = painterResource(R.drawable.logo_v),
                        contentDescription = null,
                        modifier = Modifier.size(96.dp)
                    )
                    Text(
                        text = "Chưa có kịch bản nào",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Hãy bắt đầu bằng cách tạo kịch bản đầu tiên, hoặc nhập kịch bản từ tệp Fountain / TXT / Word!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Button(
                        onClick = { showCreateDialog = true },
                        modifier = Modifier.testTag("btn_empty_create_novel")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tạo Kịch Bản Ngay")
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                // Tìm kiếm + lọc + sắp xếp
                OutlinedTextField(
                    value = query,
                    onValueChange = { novelViewModel.setLibraryQuery(it) },
                    placeholder = { Text("Tìm tên kịch bản, tác giả, thể loại (gõ không dấu được)", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { novelViewModel.setLibraryQuery("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Xóa tìm kiếm")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .testTag("input_library_search")
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        AssistChip(
                            onClick = { showSortMenu = true },
                            label = { Text(sort.title, fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Sort, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                        DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                            LibrarySort.values().forEach { opt ->
                                DropdownMenuItem(
                                    text = { Text(opt.title, fontWeight = if (opt == sort) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = { novelViewModel.setLibrarySort(opt); showSortMenu = false }
                                )
                            }
                        }
                    }
                    listOf("ALL" to "Mọi loại", ProjectKind.FILM to "Điện ảnh", ProjectKind.TV to "Truyền hình").forEach { (k, label) ->
                        FilterChip(
                            selected = kindFilter == k,
                            onClick = { novelViewModel.setLibraryKind(k) },
                            label = { Text(label, fontSize = 12.sp) }
                        )
                    }
                    FilterChip(
                        selected = statusFilter == "ALL",
                        onClick = { novelViewModel.setLibraryStatus("ALL") },
                        label = { Text("Mọi trạng thái", fontSize = 12.sp) }
                    )
                    NovelStatus.ALL.forEach { (key, label) ->
                        FilterChip(
                            selected = statusFilter == key,
                            onClick = { novelViewModel.setLibraryStatus(if (statusFilter == key) "ALL" else key) },
                            label = { Text(label, fontSize = 12.sp) }
                        )
                    }
                    if (genres.isNotEmpty()) {
                        Box {
                            AssistChip(
                                onClick = { showGenreMenu = true },
                                label = { Text(if (genreFilter == "ALL") "Mọi thể loại" else genreFilter, fontSize = 12.sp) },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            )
                            DropdownMenu(expanded = showGenreMenu, onDismissRequest = { showGenreMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Mọi thể loại") },
                                    onClick = { novelViewModel.setLibraryGenre("ALL"); showGenreMenu = false }
                                )
                                genres.forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text(g) },
                                        onClick = { novelViewModel.setLibraryGenre(g); showGenreMenu = false }
                                    )
                                }
                            }
                        }
                    }
                }

                if (novels.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Không có kịch bản nào khớp với tìm kiếm / bộ lọc.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
                    ) {
                        items(novels, key = { it.id }) { novel ->
                            NovelCard(
                                novel = novel,
                                onClick = { onSelectNovel(novel.id) },
                                onTogglePin = { novelViewModel.togglePin(novel) },
                                onBringToTop = { novelViewModel.bringToTop(novel) },
                                onSetStatus = { novelViewModel.setNovelStatus(novel, it) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (importing) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text("Đang đọc tệp…") },
            text = { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
        )
    }

    pendingImport?.let { parse ->
        var importKind by remember(parse) { mutableStateOf(ProjectKind.FILM) }
        val script = remember(parse, importKind) { parse(importKind) }
        var importTitle by remember(parse) { mutableStateOf(script.title) }
        val t = termsOf(importKind)
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text("Nhập kịch bản từ tệp", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = importTitle,
                        onValueChange = { importTitle = it },
                        label = { Text("Tên kịch bản") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Loại dự án:", style = MaterialTheme.typography.labelMedium)
                    ProjectKind.ALL.forEach { (k, label) ->
                        FilterChip(selected = importKind == k, onClick = { importKind = k }, label = { Text(label, fontSize = 12.sp) })
                    }
                    Text("Tìm thấy ${script.volumes.size} ${t.vol}, ${script.chapterCount} ${t.chap}.", fontSize = 13.sp)
                    Text(
                        "Tệp Fountain / TXT: dòng “# …” là ${t.vol}, “## …” là ${t.chap}; không có thì cả kịch bản vào một ${t.chap}. " +
                            "Tệp Word: Heading 1 = ${t.vol}, Heading 2 = ${t.chap}.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    script.volumes.take(3).forEach { v ->
                        Text("• ${v.title}: ${v.chapters.size} ${t.chap}", fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingImport = null
                        novelViewModel.importScript(
                            script.copy(title = importTitle.ifBlank { script.title }), importKind
                        ) { id -> onSelectNovel(id) }
                    },
                    enabled = script.chapterCount > 0
                ) { Text("Nhập") }
            },
            dismissButton = { TextButton(onClick = { pendingImport = null }) { Text("Hủy") } }
        )
    }

    if (showCreateDialog) {
        CreateNovelDialog(
            onDismiss = { showCreateDialog = false },
            onConfirm = { title, author, synopsis, genre, targetWords, status, cover, kind ->
                // Đóng ngay để không tạo trùng khi bấm nút 2 lần
                showCreateDialog = false
                novelViewModel.createNovel(
                    title = title,
                    author = author,
                    synopsis = synopsis,
                    genre = genre,
                    targetWordCount = targetWords,
                    status = status,
                    cover = cover,
                    projectKind = kind
                ) { newId ->
                    onSelectNovel(newId)
                }
            }
        )
    }
}

@Composable
fun NovelStatusBadge(status: String) {
    val color = when (status) {
        NovelStatus.COMPLETED -> Color(0xFF2E7D32)
        NovelStatus.PAUSED -> Color(0xFF757575)
        else -> Color(0xFF1565C0)
    }
    Surface(shape = RoundedCornerShape(4.dp), color = color.copy(alpha = 0.12f)) {
        Text(
            text = NovelStatus.label(status),
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = color,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
        )
    }
}

@Composable
fun NovelCard(
    novel: Novel,
    onClick: () -> Unit,
    onTogglePin: () -> Unit = {},
    onBringToTop: () -> Unit = {},
    onSetStatus: (String) -> Unit = {}
) {
    val design = remember(novel) { novel.coverDesign() }
    val accent = remember(novel.coverColorHex) {
        try {
            Color(android.graphics.Color.parseColor(novel.coverColorHex))
        } catch (_: Exception) {
            Color(0xFF8B1E1E)
        }
    }
    val progress = if (novel.targetWordCount > 0) {
        (novel.wordCount.toFloat() / novel.targetWordCount).coerceIn(0f, 1f)
    } else 0f
    var showMenu by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("novel_card_${novel.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            BookCover(
                title = novel.title,
                author = novel.author,
                design = design,
                modifier = Modifier.width(72.dp)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (novel.isPinned) {
                        Icon(
                            Icons.Default.PushPin,
                            contentDescription = "Đã ghim",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(
                        text = ProjectKind.label(novel.projectKind) + " · " + novel.genre,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    NovelStatusBadge(novel.status)
                    Box {
                        IconButton(onClick = { showMenu = true }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Thao tác", modifier = Modifier.size(18.dp))
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(if (novel.isPinned) "Bỏ ghim" else "Ghim lên đầu") },
                                leadingIcon = { Icon(Icons.Default.PushPin, contentDescription = null) },
                                onClick = { showMenu = false; onTogglePin() }
                            )
                            DropdownMenuItem(
                                text = { Text("Đưa lên đầu danh sách") },
                                leadingIcon = { Icon(Icons.Default.VerticalAlignTop, contentDescription = null) },
                                onClick = { showMenu = false; onBringToTop() }
                            )
                            HorizontalDivider()
                            NovelStatus.ALL.forEach { (key, label) ->
                                DropdownMenuItem(
                                    text = { Text(label, fontWeight = if (novel.status == key) FontWeight.Bold else FontWeight.Normal) },
                                    leadingIcon = {
                                        if (novel.status == key) Icon(Icons.Default.Check, contentDescription = null)
                                    },
                                    onClick = { showMenu = false; onSetStatus(key) }
                                )
                            }
                        }
                    }
                }

                Text(
                    text = novel.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = "Tác giả: ${novel.author}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (novel.synopsis.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = novel.synopsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "${novel.wordCount} / ${novel.targetWordCount} từ",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = if (design.style == "COLOR") accent else MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
    }
}

@Composable
fun CreateNovelDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, author: String, synopsis: String, genre: String, targetWords: Int, status: String, cover: CoverDesign, kind: String) -> Unit
) {
    var kind by remember { mutableStateOf(ProjectKind.FILM) }
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("Chính kịch") }
    var synopsis by remember { mutableStateOf("") }
    var targetWordsStr by remember { mutableStateOf("20000") }
    var status by remember { mutableStateOf(NovelStatus.WRITING) }
    var cover by remember { mutableStateOf(CoverDesign()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Tạo Kịch Bản Mới", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tên kịch bản *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_novel_title")
                )

                Text("Loại dự án (không đổi được sau khi tạo):", style = MaterialTheme.typography.labelMedium)
                ProjectKind.ALL.forEach { (k, label) ->
                    FilterChip(
                        selected = kind == k,
                        onClick = { kind = k },
                        label = { Text(label + if (k == ProjectKind.TV) " — Mùa → Tập" else " — Hồi → Phân đoạn", fontSize = 12.sp) },
                        modifier = Modifier.testTag("chip_kind_$k")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = author,
                        onValueChange = { author = it },
                        label = { Text("Bút danh") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = genre,
                        onValueChange = { genre = it },
                        label = { Text("Thể loại") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = synopsis,
                    onValueChange = { synopsis = it },
                    label = { Text("Tóm tắt sơ lược") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = targetWordsStr,
                    onValueChange = { targetWordsStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Mục tiêu số chữ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Trạng thái:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    NovelStatus.ALL.forEach { (key, label) ->
                        FilterChip(selected = status == key, onClick = { status = key }, label = { Text(label, fontSize = 12.sp) })
                    }
                }

                CoverPicker(
                    title = title,
                    author = author,
                    design = cover,
                    onChange = { cover = it }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val targetWords = targetWordsStr.toIntOrNull() ?: 100000
                        onConfirm(title, author, synopsis, genre, targetWords, status, cover, kind)
                    }
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.testTag("btn_confirm_create_novel")
            ) {
                Text("Tạo Ngay")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
