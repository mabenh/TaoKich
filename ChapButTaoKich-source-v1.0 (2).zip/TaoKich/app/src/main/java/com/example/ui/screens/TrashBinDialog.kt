package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.NovelViewModel

@Composable
fun TrashBinDialog(
    novelViewModel: NovelViewModel,
    onDismiss: () -> Unit
) {
    val deletedNovels by novelViewModel.deletedNovels.collectAsState()
    val deletedChapters by novelViewModel.deletedChapters.collectAsState()
    var confirmEmpty by remember { mutableStateOf(false) }
    var pendingHardDelete by remember { mutableStateOf<(() -> Unit)?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Thùng Rác",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (deletedNovels.isNotEmpty() || deletedChapters.isNotEmpty()) {
                    TextButton(
                        onClick = { confirmEmpty = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Dọn sạch", fontSize = 13.sp)
                    }
                }
            }
        },
        text = {
            if (deletedNovels.isEmpty() && deletedChapters.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Thùng rác trống.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (deletedNovels.isNotEmpty()) {
                        item {
                            Text(
                                text = "Kịch bản đã xóa (${deletedNovels.size})",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        items(deletedNovels, key = { "novel_${it.id}" }) { novel ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = novel.title,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "${novel.wordCount} từ",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(
                                        onClick = { novelViewModel.restoreNovel(novel.id) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Restore,
                                            contentDescription = "Khôi phục",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(
                                        onClick = { pendingHardDelete = { novelViewModel.hardDeleteNovel(novel.id) } },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteForever,
                                            contentDescription = "Xóa vĩnh viễn",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (deletedChapters.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Phân đoạn/Tập đã xóa (${deletedChapters.size})",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        items(deletedChapters, key = { "chap_${it.id}" }) { ch ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = ch.title,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "${ch.wordCount} từ",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(
                                        onClick = { novelViewModel.restoreChapter(ch.id, ch.novelId) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Restore,
                                            contentDescription = "Khôi phục",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(
                                        onClick = { pendingHardDelete = { novelViewModel.hardDeleteChapter(ch.id) } },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteForever,
                                            contentDescription = "Xóa vĩnh viễn",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_close_trash")
            ) {
                Text("Đóng")
            }
        }
    )

    // Xóa vĩnh viễn không thể hoàn tác -> luôn hỏi lại (trước đây bấm nhầm là mất luôn)
    if (confirmEmpty || pendingHardDelete != null) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false; pendingHardDelete = null },
            title = { Text("Xóa vĩnh viễn?", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    if (confirmEmpty) "Toàn bộ kịch bản và phân đoạn/tập trong thùng rác sẽ bị xóa vĩnh viễn, không thể khôi phục."
                    else "Mục này sẽ bị xóa vĩnh viễn, không thể khôi phục."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (confirmEmpty) novelViewModel.emptyTrash() else pendingHardDelete?.invoke()
                        confirmEmpty = false
                        pendingHardDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Xóa vĩnh viễn") }
            },
            dismissButton = {
                TextButton(onClick = { confirmEmpty = false; pendingHardDelete = null }) { Text("Hủy") }
            }
        )
    }
}
