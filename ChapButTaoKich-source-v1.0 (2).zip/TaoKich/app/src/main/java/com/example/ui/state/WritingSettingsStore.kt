package com.example.ui.state

import android.content.Context

/**
 * Lưu cài đặt soạn thảo (chủ đề, phông, cỡ chữ...) để không bị reset mỗi lần mở chương mới.
 */
class WritingSettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("writing_settings", Context.MODE_PRIVATE)

    fun load(): WritingSettings {
        val d = WritingSettings()
        return try {
            WritingSettings(
                fontSizeSp = prefs.getFloat("fontSizeSp", d.fontSizeSp),
                lineHeightMultiplier = prefs.getFloat("lineHeightMultiplier", d.lineHeightMultiplier),
                paragraphSpacingDp = prefs.getFloat("paragraphSpacingDp_v2", d.paragraphSpacingDp),
                indentFirstLine = prefs.getBoolean("indentFirstLine", d.indentFirstLine),
                fontOption = enumOrDefault(prefs.getString("fontOption", null), d.fontOption),
                theme = enumOrDefault(prefs.getString("theme", null), d.theme),
                distractionFree = false
            )
        } catch (_: Exception) {
            d
        }
    }

    fun save(s: WritingSettings) {
        prefs.edit()
            .putFloat("fontSizeSp", s.fontSizeSp)
            .putFloat("lineHeightMultiplier", s.lineHeightMultiplier)
            .putFloat("paragraphSpacingDp_v2", s.paragraphSpacingDp)
            .putBoolean("indentFirstLine", s.indentFirstLine)
            .putString("fontOption", s.fontOption.name)
            .putString("theme", s.theme.name)
            .apply()
    }

    private inline fun <reified T : Enum<T>> enumOrDefault(name: String?, default: T): T =
        name?.let { n -> enumValues<T>().firstOrNull { it.name == n } } ?: default
}
