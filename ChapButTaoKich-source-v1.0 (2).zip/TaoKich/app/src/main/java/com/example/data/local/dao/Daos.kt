package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NovelDao {
    @Query("SELECT * FROM novels WHERE isDeleted = 0 ORDER BY updatedAt DESC")
    fun getAllNovels(): Flow<List<Novel>>

    @Query("SELECT * FROM novels WHERE isDeleted = 1 ORDER BY updatedAt DESC")
    fun getDeletedNovels(): Flow<List<Novel>>

    @Query("SELECT * FROM novels WHERE id = :id LIMIT 1")
    suspend fun getNovelById(id: Long): Novel?

    @Query("SELECT * FROM novels WHERE id = :id LIMIT 1")
    fun getNovelFlow(id: Long): Flow<Novel?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNovel(novel: Novel): Long

    @Update
    suspend fun updateNovel(novel: Novel)

    @Query("UPDATE novels SET isDeleted = 1 WHERE id = :id")
    suspend fun softDeleteNovel(id: Long)

    @Query("UPDATE novels SET isDeleted = 0 WHERE id = :id")
    suspend fun restoreNovel(id: Long)

    @Query("DELETE FROM novels WHERE id = :id")
    suspend fun hardDeleteNovel(id: Long)

    @Query("DELETE FROM novels WHERE isDeleted = 1")
    suspend fun emptyTrash()

    @Query("SELECT * FROM novels")
    suspend fun getAllNovelsDirect(): List<Novel>
}

@Dao
interface VolumeDao {
    @Query("SELECT * FROM volumes WHERE novelId = :novelId AND isDeleted = 0 ORDER BY orderIndex ASC")
    fun getVolumesByNovel(novelId: Long): Flow<List<Volume>>

    @Query("SELECT * FROM volumes WHERE novelId = :novelId AND isDeleted = 0 ORDER BY orderIndex ASC")
    suspend fun getVolumesByNovelDirect(novelId: Long): List<Volume>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVolume(volume: Volume): Long

    @Update
    suspend fun updateVolume(volume: Volume)

    @Delete
    suspend fun deleteVolume(volume: Volume)

    @Query("DELETE FROM volumes WHERE id = :id")
    suspend fun deleteVolumeById(id: Long)
}

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE novelId = :novelId AND isDeleted = 0 ORDER BY orderIndex ASC")
    fun getChaptersByNovel(novelId: Long): Flow<List<Chapter>>

    @Query("SELECT * FROM chapters WHERE novelId = :novelId AND isDeleted = 0 ORDER BY orderIndex ASC")
    suspend fun getChaptersByNovelDirect(novelId: Long): List<Chapter>

    @Query("SELECT * FROM chapters WHERE volumeId = :volumeId AND isDeleted = 0 ORDER BY orderIndex ASC")
    fun getChaptersByVolume(volumeId: Long): Flow<List<Chapter>>

    @Query("SELECT * FROM chapters WHERE volumeId = :volumeId AND isDeleted = 0 ORDER BY orderIndex ASC")
    suspend fun getChaptersByVolumeDirect(volumeId: Long): List<Chapter>

    @Query("SELECT * FROM chapters WHERE isDeleted = 1 ORDER BY updatedAt DESC")
    fun getDeletedChapters(): Flow<List<Chapter>>

    @Query("SELECT * FROM chapters WHERE id = :id LIMIT 1")
    suspend fun getChapterById(id: Long): Chapter?

    @Query("SELECT * FROM chapters WHERE id = :id LIMIT 1")
    fun getChapterFlow(id: Long): Flow<Chapter?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: Chapter): Long

    @Update
    suspend fun updateChapter(chapter: Chapter)

    @Query("UPDATE chapters SET isDeleted = 1 WHERE id = :id")
    suspend fun softDeleteChapter(id: Long)

    @Query("UPDATE chapters SET isDeleted = 0 WHERE id = :id")
    suspend fun restoreChapter(id: Long)

    @Query("DELETE FROM chapters WHERE id = :id")
    suspend fun hardDeleteChapter(id: Long)

    @Query("UPDATE chapters SET volumeId = :volumeId WHERE id = :chapterId")
    suspend fun updateChapterVolume(chapterId: Long, volumeId: Long?)

    @Query("SELECT COUNT(*) FROM chapters WHERE novelId = :novelId AND isDeleted = 0")
    suspend fun getChapterCount(novelId: Long): Int

    @Query("SELECT SUM(wordCount) FROM chapters WHERE novelId = :novelId AND isDeleted = 0")
    suspend fun getTotalWordCount(novelId: Long): Int?

    @Query("SELECT DISTINCT novelId FROM chapters WHERE isDeleted = 1")
    suspend fun getNovelIdsWithDeletedChapters(): List<Long>

    @Query("DELETE FROM chapters WHERE isDeleted = 1")
    suspend fun emptyChapterTrash()

    /** Đưa các chương (kể cả chương đang trong thùng rác) ra khỏi quyển -> "Chưa phân quyển". */
    @Query("UPDATE chapters SET volumeId = NULL WHERE volumeId = :volumeId")
    suspend fun detachChaptersFromVolume(volumeId: Long)

    /** Chuyển các chương đang hoạt động của quyển vào thùng rác. */
    @Query("UPDATE chapters SET isDeleted = 1, updatedAt = :now WHERE volumeId = :volumeId AND isDeleted = 0")
    suspend fun softDeleteChaptersInVolume(volumeId: Long, now: Long)
}

@Dao
interface SnapshotDao {
    @Query("SELECT * FROM chapter_snapshots WHERE chapterId = :chapterId ORDER BY createdAt DESC")
    fun getSnapshotsByChapter(chapterId: Long): Flow<List<ChapterSnapshot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: ChapterSnapshot): Long

    @Query("DELETE FROM chapter_snapshots WHERE id = :id")
    suspend fun deleteSnapshotById(id: Long)

    @Query("SELECT * FROM chapter_snapshots WHERE chapterId = :chapterId")
    suspend fun getSnapshotsDirect(chapterId: Long): List<ChapterSnapshot>
}

@Dao
interface CharacterWorldDao {
    // Characters
    @Query("SELECT * FROM character_profiles WHERE novelId = :novelId ORDER BY role ASC, name ASC")
    fun getCharactersByNovel(novelId: Long): Flow<List<CharacterProfile>>

    @Query("SELECT * FROM character_profiles WHERE novelId = :novelId ORDER BY role ASC, name ASC")
    suspend fun getCharactersByNovelDirect(novelId: Long): List<CharacterProfile>

    @Query("SELECT * FROM character_profiles WHERE id = :id LIMIT 1")
    suspend fun getCharacterById(id: Long): CharacterProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacter(character: CharacterProfile): Long

    @Update
    suspend fun updateCharacter(character: CharacterProfile)

    @Delete
    suspend fun deleteCharacter(character: CharacterProfile)

    @Query("DELETE FROM character_profiles WHERE id = :id")
    suspend fun deleteCharacterById(id: Long)

    // World Notes
    @Query("SELECT * FROM world_notes WHERE novelId = :novelId ORDER BY category ASC, title ASC")
    fun getWorldNotesByNovel(novelId: Long): Flow<List<WorldNote>>

    @Query("SELECT * FROM world_notes WHERE novelId = :novelId ORDER BY category ASC, title ASC")
    suspend fun getWorldNotesByNovelDirect(novelId: Long): List<WorldNote>

    @Query("SELECT * FROM world_notes WHERE id = :id LIMIT 1")
    suspend fun getWorldNoteById(id: Long): WorldNote?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorldNote(note: WorldNote): Long

    @Update
    suspend fun updateWorldNote(note: WorldNote)

    @Delete
    suspend fun deleteWorldNote(note: WorldNote)

    @Query("DELETE FROM world_notes WHERE id = :id")
    suspend fun deleteWorldNoteById(id: Long)
}

@Dao
interface BackupDao {
    @Query("SELECT * FROM backup_records ORDER BY timestamp DESC")
    fun getAllBackups(): Flow<List<BackupRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBackup(backup: BackupRecord): Long

    @Query("DELETE FROM backup_records WHERE id = :id")
    suspend fun deleteBackupById(id: Long)

    @Query("SELECT * FROM backup_records WHERE backupName LIKE :prefix || '%' ORDER BY timestamp DESC")
    suspend fun getBackupsByNamePrefix(prefix: String): List<BackupRecord>
}
