package com.example.ui.state

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.EditorFontOption

sealed class Screen {
    object NovelList : Screen()
    data class NovelDetail(val novelId: Long) : Screen()
    data class Editor(val novelId: Long, val chapterId: Long) : Screen()
    object BackupRestore : Screen()
}

enum class ChapterSortOption(val title: String) {
    ORDER_ASC("Thứ tự (1 → N)"),
    ORDER_DESC("Thứ tự (N → 1)"),
    UPDATED_DESC("Mới chỉnh sửa gần nhất"),
    WORDS_DESC("Số từ nhiều nhất"),
    WORDS_ASC("Số từ ít nhất"),
    TITLE_AZ("Theo tên tiêu đề (A - Z)")
}

enum class ChapterViewMode(val title: String) {
    LIST("Dạng liệt kê"),
    BY_VOLUME("Dạng cột theo hồi/mùa")
}

enum class EditorThemeType(
    val displayName: String,
    val backgroundColor: Color,
    val surfaceColor: Color,
    val textColor: Color,
    val secondaryTextColor: Color,
    val accentColor: Color
) {
    SEPIA(
        displayName = "Màu Giấy Cũ",
        backgroundColor = Color(0xFFFBF0D9),
        surfaceColor = Color(0xFFF4E3C1),
        textColor = Color(0xFF3E2723),
        secondaryTextColor = Color(0xFF6D4C41),
        accentColor = Color(0xFF8D6E63)
    ),
    LIGHT(
        displayName = "Sáng Trắng",
        backgroundColor = Color(0xFFFAF9F6),
        surfaceColor = Color(0xFFEDEBE6),
        textColor = Color(0xFF212121),
        secondaryTextColor = Color(0xFF616161),
        accentColor = Color(0xFF1976D2)
    ),
    SAGE(
        displayName = "Xanh Dịu Mắt",
        backgroundColor = Color(0xFFE8EFE9),
        surfaceColor = Color(0xFFD3E0D5),
        textColor = Color(0xFF1B382B),
        secondaryTextColor = Color(0xFF3F5E4D),
        accentColor = Color(0xFF2E7D32)
    ),
    NIGHT(
        displayName = "Tối Dịu Ban Đêm",
        backgroundColor = Color(0xFF1E2124),
        surfaceColor = Color(0xFF282B30),
        textColor = Color(0xFFDCDEE1),
        secondaryTextColor = Color(0xFF8E9297),
        accentColor = Color(0xFF7289DA)
    ),
    OLED(
        displayName = "Đen Tuyệt Đối",
        backgroundColor = Color(0xFF000000),
        surfaceColor = Color(0xFF121212),
        textColor = Color(0xFFE0E0E0),
        secondaryTextColor = Color(0xFF757575),
        accentColor = Color(0xFFFFB300)
    )
}

data class WritingSettings(
    val fontSizeSp: Float = 17f,
    val lineHeightMultiplier: Float = 1.6f,
    val paragraphSpacingDp: Float = 0f, // mặc định tắt
    val indentFirstLine: Boolean = true,
    val fontOption: EditorFontOption = EditorFontOption.SERIF,
    val theme: EditorThemeType = EditorThemeType.SEPIA,
    val distractionFree: Boolean = false
)
