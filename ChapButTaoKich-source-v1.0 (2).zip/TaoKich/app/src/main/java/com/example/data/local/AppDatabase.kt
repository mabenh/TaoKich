package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.*
import com.example.data.local.entities.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Novel::class,
        Volume::class,
        Chapter::class,
        ChapterSnapshot::class,
        CharacterProfile::class,
        WorldNote::class,
        BackupRecord::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun novelDao(): NovelDao
    abstract fun volumeDao(): VolumeDao
    abstract fun chapterDao(): ChapterDao
    abstract fun snapshotDao(): SnapshotDao
    abstract fun characterWorldDao(): CharacterWorldDao
    abstract fun backupDao(): BackupDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private const val DB_NAME = "chapbut_taokich.db"

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: try {
                    val db = buildDatabase(context)
                    // Mở DB ngay để phát hiện lỗi schema/migration sớm
                    db.openHelper.writableDatabase
                    db.also { INSTANCE = it }
                } catch (e: Throwable) {
                    android.util.Log.e("AppDatabase", "Database initialization error", e)
                    // KHÔNG xóa im lặng dữ liệu của người dùng: sao chép tệp DB lỗi ra một bản dự phòng
                    // trước khi tạo DB mới, để còn cứu được bản thảo.
                    preserveBrokenDatabase(context.applicationContext)
                    val freshDb = buildDatabase(context)
                    try {
                        freshDb.openHelper.writableDatabase
                    } catch (t: Throwable) {
                        android.util.Log.e("AppDatabase", "Fresh database open error", t)
                    }
                    freshDb.also { INSTANCE = it }
                }
            }
        }

        private fun preserveBrokenDatabase(appContext: Context) {
            try {
                val dbFile = appContext.getDatabasePath(DB_NAME)
                if (dbFile.exists()) {
                    val rescueDir = java.io.File(appContext.filesDir, "db_rescue").apply { mkdirs() }
                    val stamp = System.currentTimeMillis()
                    listOf("", "-wal", "-shm").forEach { suffix ->
                        val f = java.io.File(dbFile.path + suffix)
                        if (f.exists()) f.copyTo(java.io.File(rescueDir, "${DB_NAME}_$stamp$suffix"), overwrite = true)
                    }
                }
                appContext.deleteDatabase(DB_NAME)
            } catch (e: Exception) {
                android.util.Log.e("AppDatabase", "Could not preserve broken database", e)
            }
        }

        val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    // 1. Create 'volumes' table & index
                    db.execSQL("CREATE TABLE IF NOT EXISTS `volumes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `novelId` INTEGER NOT NULL, `title` TEXT NOT NULL, `orderIndex` INTEGER NOT NULL, `description` TEXT NOT NULL, `isDeleted` INTEGER NOT NULL, FOREIGN KEY(`novelId`) REFERENCES `novels`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_volumes_novelId` ON `volumes` (`novelId`)")
                } catch (e: Exception) {
                    android.util.Log.e("AppDatabase", "Migration volume error", e)
                }

                // 2. Add 'volumeId' column to 'chapters' and add indices
                try {
                    db.execSQL("ALTER TABLE `chapters` ADD COLUMN `volumeId` INTEGER")
                } catch (_: Exception) {}
                try {
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_chapters_volumeId` ON `chapters` (`volumeId`)")
                } catch (_: Exception) {}
                try {
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_chapters_novelId` ON `chapters` (`novelId`)")
                } catch (_: Exception) {}

                try {
                    // 3. Create 'character_profiles' table & index
                    db.execSQL("CREATE TABLE IF NOT EXISTS `character_profiles` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `novelId` INTEGER NOT NULL, `name` TEXT NOT NULL, `role` TEXT NOT NULL, `appearance` TEXT NOT NULL, `personality` TEXT NOT NULL, `background` TEXT NOT NULL, `notes` TEXT NOT NULL, `avatarEmoji` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`novelId`) REFERENCES `novels`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_character_profiles_novelId` ON `character_profiles` (`novelId`)")
                } catch (e: Exception) {
                    android.util.Log.e("AppDatabase", "Migration character error", e)
                }

                try {
                    // 4. Create 'world_notes' table & index
                    db.execSQL("CREATE TABLE IF NOT EXISTS `world_notes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `novelId` INTEGER NOT NULL, `title` TEXT NOT NULL, `category` TEXT NOT NULL, `content` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`novelId`) REFERENCES `novels`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_world_notes_novelId` ON `world_notes` (`novelId`)")
                } catch (e: Exception) {
                    android.util.Log.e("AppDatabase", "Migration world notes error", e)
                }

                try {
                    // 5. Create 'backup_records' table
                    db.execSQL("CREATE TABLE IF NOT EXISTS `backup_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `backupName` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, `novelCount` INTEGER NOT NULL, `chapterCount` INTEGER NOT NULL, `filePath` TEXT NOT NULL, `fileSizeKb` INTEGER NOT NULL)")
                } catch (e: Exception) {
                    android.util.Log.e("AppDatabase", "Migration backup records error", e)
                }
            }
        }

        /**
         * Bản 1.5: thêm cột mới, KHÔNG xóa hay đổi dữ liệu cũ.
         * Mỗi câu ALTER chạy riêng (bỏ qua nếu cột đã có) để migration không hỏng giữa chừng.
         */
        val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                fun add(table: String, columnDef: String) {
                    try {
                        db.execSQL("ALTER TABLE `$table` ADD COLUMN $columnDef")
                    } catch (e: Exception) {
                        android.util.Log.w("AppDatabase", "Migration 2->3: $table $columnDef", e)
                    }
                }
                add("novels", "`status` TEXT NOT NULL DEFAULT 'WRITING'")
                add("novels", "`isPinned` INTEGER NOT NULL DEFAULT 0")
                add("novels", "`pinnedAt` INTEGER NOT NULL DEFAULT 0")
                add("novels", "`outline` TEXT NOT NULL DEFAULT ''")
                // Truyện cũ giữ bìa màu trơn như trước; truyện mới mặc định dùng bìa tự tạo
                add("novels", "`coverStyle` TEXT NOT NULL DEFAULT 'COLOR'")
                add("novels", "`coverBorder` TEXT NOT NULL DEFAULT 'co-dien'")
                add("novels", "`coverPaper` TEXT NOT NULL DEFAULT 'nga'")
                add("novels", "`coverBorderImage` TEXT NOT NULL DEFAULT ''")
                add("novels", "`coverPaperImage` TEXT NOT NULL DEFAULT ''")
                add("novels", "`coverInk` TEXT NOT NULL DEFAULT ''")
                add("chapters", "`outline` TEXT NOT NULL DEFAULT ''")
                add("chapters", "`notes` TEXT NOT NULL DEFAULT ''")
                add("character_profiles", "`avatarId` TEXT NOT NULL DEFAULT ''")
                add("character_profiles", "`gender` TEXT NOT NULL DEFAULT ''")
                add("character_profiles", "`aliases` TEXT NOT NULL DEFAULT ''")
                add("world_notes", "`tags` TEXT NOT NULL DEFAULT ''")
                // Phân loại "Lịch sử" không còn: chuyển sang "Khác", giữ tên cũ làm nhãn
                try {
                    db.execSQL("UPDATE `world_notes` SET `category` = 'OTHER', `tags` = 'Lịch sử' WHERE `category` = 'HISTORY'")
                } catch (e: Exception) {
                    android.util.Log.w("AppDatabase", "Migration 2->3: world_notes HISTORY", e)
                }
            }
        }

        /** Chấp Bút Tạo Kịch: thêm loại dự án (phim điện ảnh / truyền hình). */
        val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE `novels` ADD COLUMN `projectKind` TEXT NOT NULL DEFAULT 'FILM'")
                } catch (e: Exception) {
                    android.util.Log.w("AppDatabase", "Migration 3->4", e)
                }
            }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            // Giữ tham chiếu tới DB vừa build để callback onCreate dùng được.
            // (Trước đây callback đọc INSTANCE, nhưng INSTANCE luôn null lúc onCreate chạy
            //  => dữ liệu mẫu không bao giờ được tạo.)
            var builtDb: AppDatabase? = null
            val db = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DB_NAME
            )
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                // Bỏ fallbackToDestructiveMigration(): nếu sau này tăng version mà quên migration,
                // Room sẽ XÓA SẠCH truyện của người dùng. Giờ lỗi sẽ đi vào nhánh cứu dữ liệu ở trên.
                .fallbackToDestructiveMigrationOnDowngrade(true)
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = builtDb ?: return@launch
                            try {
                                populateInitialSampleData(database)
                            } catch (e: Throwable) {
                                android.util.Log.e("AppDatabase", "Failed to populate initial sample data", e)
                            }
                        }
                    }
                })
                .build()
            builtDb = db
            return db
        }

        suspend fun populateInitialSampleData(database: AppDatabase) {
            val novelDao = database.novelDao()
            val volumeDao = database.volumeDao()
            val chapterDao = database.chapterDao()
            val characterWorldDao = database.characterWorldDao()

            val novelId = novelDao.insertNovel(
                Novel(
                    title = "Chuyến Xe Cuối Ngày",
                    author = "Văn Mọn",
                    genre = "Phim ngắn – Chính kịch",
                    synopsis = "Chuyến xe buýt cuối ngày, một tài xế sắp nghỉ hưu và cô sinh viên quên ví. Mười lăm phút đủ để hai người lạ thay đổi một quyết định.",
                    targetWordCount = 6000,
                    projectKind = "FILM",
                    coverBorder = "toi-gian",
                    coverPaper = "trang"
                )
            )

            val act1 = volumeDao.insertVolume(
                Volume(novelId = novelId, title = "Hồi 1: Lên xe", orderIndex = 1,
                    description = "Giới thiệu bác Tư và Lan. Lan phát hiện mất ví.")
            )
            volumeDao.insertVolume(
                Volume(novelId = novelId, title = "Hồi 2: Chặng cuối", orderIndex = 2,
                    description = "Cuộc trò chuyện trên xe, bí mật của bác Tư.")
            )

            val seq1 = """NGOẠI. TRẠM XE BUÝT BẾN THÀNH – ĐÊM

Mưa lất phất. Đèn đường vàng vọt. LAN (20, sinh viên, ba lô sờn quai) chạy tới, thở dốc, nhìn đồng hồ.

Chiếc xe buýt số 18 lăn bánh vào trạm. Cửa mở.

NỘI. XE BUÝT SỐ 18 – ĐÊM

BÁC TƯ (60, tài xế, tóc bạc, áo đồng phục bạc màu) gật đầu chào. Xe trống trơn.

Lan lục ba lô. Lục lần nữa. Mặt tái đi.

LAN
(lí nhí)
Bác ơi... con để quên ví rồi.

BÁC TƯ
Lên đi con. Chuyến cuối mà, xe cũng về bến.

Lan ngần ngừ rồi bước lên, ngồi ghế đầu.

CẮT SANG:"""
            chapterDao.insertChapter(
                Chapter(novelId = novelId, volumeId = act1, title = "Phân đoạn 1: Trạm cuối", orderIndex = 1,
                    content = seq1, wordCount = seq1.trim().split(Regex("\\s+")).size, status = "COMPLETED",
                    outline = "Lan lỡ quên ví, bác Tư vẫn cho lên xe.")
            )
            chapterDao.insertChapter(
                Chapter(novelId = novelId, volumeId = act1, title = "Phân đoạn 2: Câu chuyện của bác Tư", orderIndex = 2,
                    content = "", status = "DRAFT",
                    outline = "Bác Tư kể đây là chuyến xe cuối cùng trước khi nghỉ hưu.")
            )

            characterWorldDao.insertCharacter(
                CharacterProfile(novelId = novelId, name = "LAN", role = "PROTAGONIST", gender = "F",
                    appearance = "20 tuổi, sinh viên năm cuối, ba lô sờn quai.",
                    personality = "Tự trọng, ngại làm phiền người khác.")
            )
            characterWorldDao.insertCharacter(
                CharacterProfile(novelId = novelId, name = "BÁC TƯ", role = "PROTAGONIST", gender = "M",
                    appearance = "60 tuổi, tóc bạc, đồng phục tài xế bạc màu.",
                    personality = "Hiền, kiệm lời, giấu một nỗi buồn.", aliases = "Tư")
            )
            characterWorldDao.insertWorldNote(
                WorldNote(novelId = novelId, title = "Xe buýt số 18", category = "LOCATION",
                    content = "Tuyến Bến Thành – Chợ Lớn, chuyến cuối lúc 21:30.")
            )
        }
    }
}
