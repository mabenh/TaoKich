package com.example.util

import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

/**
 * Nhập truyện từ tệp TXT hoặc Word (.docx). Thuần Kotlin để kiểm thử được trên JVM.
 *
 * - TXT: tự nhận dòng tiêu đề quyển ("Quyển 1…", "Tập 2…", "Phần 3…", "Volume…", "第…卷")
 *   và chương ("Chương 1…", "Hồi 2…", "Chapter 3…", "第…章").
 * - DOCX: Heading 1 = quyển, Heading 2 = chương. Không có Heading thì nhận dạng như TXT.
 */
object BookImporter {

    data class ImportedChapter(val title: String, val content: String)
    data class ImportedVolume(val title: String, val chapters: List<ImportedChapter>)
    data class ImportedBook(val title: String, val volumes: List<ImportedVolume>) {
        val chapterCount: Int get() = volumes.sumOf { it.chapters.size }
    }

    // Số: 12 / XII (chỉ chữ hoa, đứng riêng) / 十二
    private const val NUM = """(?:\d+|(?-i:[IVXLC]+)(?![\p{L}\d])|[一二三四五六七八九十百千零]+)"""
    private const val SEP = """[:：.\-–—]"""
    private val VOLUME_RE = Regex(
        """^\s*(?:(?:quyển|tập|phần|volume|book)\s*$NUM(?:\s*$SEP\s*.{0,80}|\s+.{0,80})?""" +
            """|(?:quyển|tập|phần)\s*$SEP\s*.{0,80}|第$NUM[卷部].{0,80})$""",
        RegexOption.IGNORE_CASE
    )
    private val CHAPTER_RE = Regex(
        """^\s*(?:(?:chương|hồi|chapter|chap)\s*$NUM(?:\s*$SEP\s*.{0,120}|\s+.{0,120})?""" +
            """|(?:chương|hồi)\s*$SEP\s*.{0,120}|第$NUM[章回节].{0,120}|(?:mở đầu|lời mở đầu|tiết tử|vĩ thanh|phần kết|ngoại truyện)(?:\s*$SEP.{0,120})?)$""",
        RegexOption.IGNORE_CASE
    )

    fun isVolumeHeading(line: String): Boolean = line.length <= 100 && VOLUME_RE.matches(line)
    fun isChapterHeading(line: String): Boolean = line.length <= 140 && CHAPTER_RE.matches(line)

    /** Đọc byte của tệp văn bản: UTF-8 (có/không BOM), UTF-16 có BOM, nếu không phải UTF-8 thì thử windows-1258. */
    fun decodeText(bytes: ByteArray): String {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte())
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte())
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte())
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
        } catch (_: CharacterCodingException) {
            val cs = try { Charset.forName("windows-1258") } catch (_: Exception) { Charsets.ISO_8859_1 }
            String(bytes, cs)
        }
    }

    /** Một đoạn văn kèm mức tiêu đề: 0 = văn bản thường, 1 = quyển, 2 = chương. */
    data class Para(val level: Int, val text: String)

    fun parseTxt(text: String, fallbackTitle: String): ImportedBook {
        val paras = text.replace("\r\n", "\n").replace('\r', '\n').split('\n').map { line ->
            val t = line.trim()
            when {
                t.isEmpty() -> Para(0, "")
                isVolumeHeading(t) -> Para(1, t)
                isChapterHeading(t) -> Para(2, t)
                else -> Para(0, line.trimEnd())
            }
        }
        return build(paras, fallbackTitle)
    }

    /** Đọc tệp .docx (dạng byte). Ném IllegalArgumentException nếu không phải tệp Word hợp lệ. */
    fun parseDocx(bytes: ByteArray, fallbackTitle: String): ImportedBook {
        var xml: String? = null
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.name == "word/document.xml") {
                    xml = zip.readBytes().toString(Charsets.UTF_8)
                    break
                }
            }
        }
        val doc = xml ?: throw IllegalArgumentException("Không tìm thấy nội dung tệp Word")
        return parseDocumentXml(doc, fallbackTitle)
    }

    private val P_RE = Regex("""<w:p[ >].*?</w:p>|<w:p/>""", RegexOption.DOT_MATCHES_ALL)
    private val STYLE_RE = Regex("""<w:pStyle\s+w:val="([^"]+)"""")
    private val OUTLINE_RE = Regex("""<w:outlineLvl\s+w:val="(\d+)"""")
    private val TOKEN_RE = Regex("""<w:t(?:\s[^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br/>|<w:cr/>""", RegexOption.DOT_MATCHES_ALL)

    fun parseDocumentXml(xml: String, fallbackTitle: String): ImportedBook {
        val paras = ArrayList<Para>()
        var anyHeading = false
        for (m in P_RE.findAll(xml)) {
            val p = m.value
            val sb = StringBuilder()
            for (t in TOKEN_RE.findAll(p)) {
                when {
                    t.value == "<w:tab/>" -> sb.append('\t')
                    t.value == "<w:br/>" || t.value == "<w:cr/>" -> sb.append('\n')
                    else -> sb.append(unescapeXml(t.groupValues[1]))
                }
            }
            val text = sb.toString()
            val style = STYLE_RE.find(p)?.groupValues?.get(1)?.lowercase() ?: ""
            val outline = OUTLINE_RE.find(p)?.groupValues?.get(1)?.toIntOrNull()
            val level = when {
                style == "heading1" || style == "title" || style.endsWith("heading1") || outline == 0 -> 1
                style == "heading2" || style.endsWith("heading2") || outline == 1 -> 2
                else -> 0
            }
            if (level > 0 && text.isNotBlank()) {
                anyHeading = true
                paras.add(Para(level, text.trim()))
            } else {
                text.split('\n').forEach { paras.add(Para(0, it.trimEnd())) }
            }
        }
        if (!anyHeading) {
            // Không dùng Heading: nhận dạng tiêu đề quyển/chương theo chữ như tệp TXT
            return parseTxt(paras.joinToString("\n") { it.text }, fallbackTitle)
        }
        // Có Heading 1 nhưng không có Heading 2 → coi Heading 1 là chương
        val hasH2 = paras.any { it.level == 2 }
        val fixed = if (hasH2) paras else paras.map { if (it.level == 1) Para(2, it.text) else it }
        return build(fixed, fallbackTitle)
    }

    private fun unescapeXml(s: String): String =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
            .replace("&apos;", "'").replace("&amp;", "&")

    /** Gom các đoạn thành quyển → chương. Văn bản trước chương đầu tiên thành chương "Mở đầu". */
    private fun build(paras: List<Para>, fallbackTitle: String): ImportedBook {
        data class MChapter(val title: String, val lines: MutableList<String> = ArrayList())
        data class MVolume(val title: String, val chapters: MutableList<MChapter> = ArrayList())

        val volumes = ArrayList<MVolume>()
        var curVol: MVolume? = null
        var curCh: MChapter? = null
        val loose = ArrayList<String>()   // văn bản trước tiêu đề đầu tiên

        fun volume(): MVolume = curVol ?: MVolume("Quyển 1").also { volumes.add(it); curVol = it }

        for (p in paras) {
            when (p.level) {
                1 -> {
                    curVol = MVolume(p.text).also { volumes.add(it) }
                    curCh = null
                }
                2 -> {
                    curCh = MChapter(p.text).also { volume().chapters.add(it) }
                }
                else -> {
                    val ch = curCh
                    if (ch != null) ch.lines.add(p.text)
                    else if (curVol != null && curVol!!.chapters.isEmpty()) {
                        // Văn bản ngay dưới tiêu đề quyển, trước chương đầu → chương "Mở đầu" của quyển
                        if (p.text.isNotBlank() || curVol!!.chapters.isNotEmpty()) {
                            curCh = MChapter("Mở đầu").also { it.lines.add(p.text); curVol!!.chapters.add(it) }
                        }
                    } else loose.add(p.text)
                }
            }
        }

        val looseText = clean(loose)
        if (volumes.isEmpty()) {
            // Không nhận ra tiêu đề nào: cả tệp là một chương
            val content = looseText
            return ImportedBook(
                fallbackTitle,
                listOf(ImportedVolume("Quyển 1", listOf(ImportedChapter("Chương 1", content))))
            )
        }
        val result = volumes.map { v ->
            ImportedVolume(v.title, v.chapters.map { ImportedChapter(it.title, clean(it.lines)) })
        }.toMutableList()
        if (looseText.isNotBlank()) {
            val first = result[0]
            result[0] = first.copy(chapters = listOf(ImportedChapter("Mở đầu", looseText)) + first.chapters)
        }
        return ImportedBook(fallbackTitle, result.filter { it.chapters.isNotEmpty() || result.size == 1 })
    }

    /** Bỏ dòng trống thừa đầu/cuối, gộp nhiều dòng trống liên tiếp thành một. */
    private fun clean(lines: List<String>): String {
        val out = ArrayList<String>()
        var blank = false
        for (l in lines) {
            if (l.isBlank()) {
                if (out.isNotEmpty() && !blank) out.add("")
                blank = true
            } else {
                out.add(l)
                blank = false
            }
        }
        while (out.isNotEmpty() && out.last().isBlank()) out.removeAt(out.lastIndex)
        return out.joinToString("\n")
    }
}
