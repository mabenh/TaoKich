package com.example.util

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Ghi lại lỗi khi app bị văng để lần mở sau hiển thị cho người dùng sao chép gửi đi.
 * Đồng thời tắt "Giãn đoạn văn" (tính năng hiển thị mới nhất của trình soạn thảo) để
 * nếu lỗi do tính năng này thì lần sau mở chương không bị văng tiếp.
 */
object CrashLogger {
    private const val FILE_NAME = "last_crash.txt"

    fun install(context: Context) {
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                val versionName = try {
                    appContext.packageManager.getPackageInfo(appContext.packageName, 0).versionName
                } catch (_: Exception) { "?" }
                val header = buildString {
                    append("Thời điểm: ").append(SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US).format(Date())).append('\n')
                    append("Phiên bản app: ").append(versionName).append('\n')
                    append("Thiết bị: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                        .append(" (Android ").append(Build.VERSION.RELEASE).append(", API ").append(Build.VERSION.SDK_INT).append(")\n")
                    append("Luồng: ").append(thread.name).append("\n\n")
                }
                File(appContext.filesDir, FILE_NAME).writeText(header + sw.toString().take(20000))
                // Tắt giãn đoạn văn để lần sau mở chương an toàn
                appContext.getSharedPreferences("writing_settings", Context.MODE_PRIVATE)
                    .edit().putFloat("paragraphSpacingDp_v2", 0f).commit()
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Đọc nội dung lỗi lần trước (nếu có) và xóa tệp. */
    fun readAndClear(context: Context): String? {
        return try {
            val f = File(context.applicationContext.filesDir, FILE_NAME)
            if (!f.exists()) return null
            val text = f.readText()
            f.delete()
            text.ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }
}
