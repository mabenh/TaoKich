package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/** Trạng thái đọc: đang đọc / tạm dừng, câu hiện tại (vị trí trong văn bản), số thứ tự câu. */
data class ReadState(
    val active: Boolean = false,
    val speaking: Boolean = false,
    val range: IntRange? = null,
    val index: Int = 0,
    val total: Int = 0,
    val rate: Float = 1.0f,
    val message: String? = null,
    val missingVoice: Boolean = false
)

/**
 * Đọc văn bản bằng giọng nói của máy (Android TextToSpeech), ưu tiên giọng tiếng Việt.
 * Đọc từng câu, báo câu đang đọc để tô sáng trong ô soạn thảo.
 */
class ReadAloudController(context: Context) : TextToSpeech.OnInitListener {

    private val prefs = context.applicationContext.getSharedPreferences("writing_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(ReadState(rate = prefs.getFloat("ttsRate", 1.0f)))
    val state: StateFlow<ReadState> = _state.asStateFlow()

    private var ready = false
    private var initFailed = false
    private var pendingStart: (() -> Unit)? = null
    private var text: String = ""
    private var sentences: List<IntRange> = emptyList()
    @Volatile private var generation = 0

    private val tts: TextToSpeech = TextToSpeech(context.applicationContext, this)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            initFailed = true
            _state.value = _state.value.copy(active = false, speaking = false, message = "Máy chưa có bộ chuyển văn bản thành giọng nói.")
            return
        }
        val r = try { tts.setLanguage(Locale("vi", "VN")) } catch (_: Exception) { TextToSpeech.LANG_NOT_SUPPORTED }
        val missing = r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED
        _state.value = _state.value.copy(missingVoice = missing)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                val (gen, k) = parseId(utteranceId) ?: return
                if (gen != generation) return
                _state.value = _state.value.copy(range = sentences.getOrNull(k), index = k, speaking = true)
            }

            override fun onDone(utteranceId: String?) {
                val (gen, k) = parseId(utteranceId) ?: return
                if (gen != generation) return
                if (k >= sentences.lastIndex) {
                    _state.value = _state.value.copy(active = false, speaking = false, range = null, message = "Đã đọc xong")
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _state.value = _state.value.copy(speaking = false, message = "Lỗi khi đọc")
            }
        })
        ready = true
        pendingStart?.invoke()
        pendingStart = null
    }

    private fun parseId(id: String?): Pair<Int, Int>? {
        val parts = id?.split(':') ?: return null
        if (parts.size != 2) return null
        val g = parts[0].toIntOrNull() ?: return null
        val k = parts[1].toIntOrNull() ?: return null
        return g to k
    }

    /** Bắt đầu đọc [fullText] từ câu chứa vị trí [from]. */
    fun start(fullText: String, from: Int) {
        if (initFailed) {
            _state.value = _state.value.copy(message = "Máy chưa có bộ chuyển văn bản thành giọng nói.")
            return
        }
        if (!ready) {
            pendingStart = { start(fullText, from) }
            _state.value = _state.value.copy(active = true, message = "Đang khởi động giọng đọc…")
            return
        }
        text = fullText
        sentences = splitLong(TextTools.sentenceRanges(fullText))
        if (sentences.isEmpty()) {
            _state.value = _state.value.copy(active = false, speaking = false, range = null, message = "Không có chữ để đọc")
            return
        }
        val i = sentences.indexOfFirst { it.last >= from }.let { if (it < 0) 0 else it }
        speakFrom(i)
    }

    private fun speakFrom(i: Int) {
        generation++
        val gen = generation
        tts.stop()
        if (i !in sentences.indices) {
            _state.value = _state.value.copy(active = false, speaking = false, range = null)
            return
        }
        tts.setSpeechRate(_state.value.rate)
        for (k in i until sentences.size) {
            val r = sentences[k]
            tts.speak(text.substring(r.first, r.last + 1), TextToSpeech.QUEUE_ADD, null, "$gen:$k")
        }
        _state.value = _state.value.copy(
            active = true, speaking = true, range = sentences[i], index = i, total = sentences.size, message = null
        )
    }

    fun pause() {
        generation++
        tts.stop()
        _state.value = _state.value.copy(speaking = false)
    }

    fun resume() {
        if (sentences.isEmpty()) return
        speakFrom(_state.value.index)
    }

    fun next() = speakFrom((_state.value.index + 1).coerceAtMost(sentences.lastIndex))
    fun previous() = speakFrom((_state.value.index - 1).coerceAtLeast(0))

    fun stop() {
        generation++
        pendingStart = null
        try { tts.stop() } catch (_: Exception) {}
        _state.value = ReadState(rate = _state.value.rate, missingVoice = _state.value.missingVoice)
    }

    /** Tốc độ đọc 0.5 – 2.0. */
    fun setRate(rate: Float) {
        val r = rate.coerceIn(0.5f, 2.0f)
        prefs.edit().putFloat("ttsRate", r).apply()
        _state.value = _state.value.copy(rate = r)
        if (_state.value.speaking) speakFrom(_state.value.index)
    }

    fun clearMessage() {
        _state.value = _state.value.copy(message = null)
    }

    fun shutdown() {
        generation++
        try {
            tts.stop()
            tts.shutdown()
        } catch (_: Exception) {}
    }

    /** Bộ đọc chỉ nhận tối đa ~4000 ký tự mỗi lần: cắt câu quá dài ở khoảng trắng. */
    private fun splitLong(ranges: List<IntRange>): List<IntRange> {
        val max = 3000
        val out = ArrayList<IntRange>(ranges.size)
        for (r in ranges) {
            var a = r.first
            while (r.last + 1 - a > max) {
                var cut = a + max
                while (cut > a + max / 2 && !text[cut].isWhitespace()) cut--
                out.add(a until cut)
                a = cut
                while (a <= r.last && text[a].isWhitespace()) a++
            }
            if (a <= r.last) out.add(a..r.last)
        }
        return out
    }
}

/** Tô nền câu đang đọc, rồi chuyển cho phép biến đổi hiển thị bên trong (ví dụ giãn đoạn). */
class HighlightTransformation(
    private val range: IntRange,
    private val color: Color,
    private val inner: VisualTransformation
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val n = text.length
        val a = range.first.coerceIn(0, n)
        val b = (range.last + 1).coerceIn(0, n)
        val marked = if (b > a) {
            AnnotatedString.Builder(text).apply { addStyle(SpanStyle(background = color), a, b) }.toAnnotatedString()
        } else text
        return inner.filter(marked)
    }

    override fun equals(other: Any?): Boolean =
        other is HighlightTransformation && other.range == range && other.color == color && other.inner == inner

    override fun hashCode(): Int = (range.hashCode() * 31 + color.hashCode()) * 31 + inner.hashCode()
}
