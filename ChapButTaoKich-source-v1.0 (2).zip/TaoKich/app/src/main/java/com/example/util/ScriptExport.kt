package com.example.util

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.data.local.entities.Chapter
import com.example.data.local.entities.Novel
import com.example.data.local.entities.Volume
import java.io.File
import java.io.FileOutputStream

/**
 * Xuất kịch bản: PDF trình bày chuẩn (khổ A4, phông đơn cách 12pt, lề trái 1.5 inch, ~55 dòng / trang,
 * 1 trang ≈ 1 phút phim) và Fountain (mở được bằng các phần mềm viết kịch bản khác).
 */
object ScriptExport {

    private fun parts(volumes: List<Volume>, chapters: List<Chapter>): List<Screenplay.ExportPart> {
        val volMap = volumes.associateBy { it.id }
        val volOrder = volumes.associate { it.id to it.orderIndex }
        return chapters
            .filter { !it.isDeleted }
            .sortedWith(compareBy({ volOrder[it.volumeId] ?: Int.MAX_VALUE }, { it.orderIndex }))
            .map { Screenplay.ExportPart(it.volumeId?.let { id -> volMap[id]?.title }, it.title, it.content) }
    }

    private fun safeName(title: String): String =
        title.replace(Regex("[^a-zA-Z0-9\\p{L} _-]"), "").trim().replace(' ', '_').take(80).ifBlank { "KichBan" }

    private fun outDir(context: Context): File = File(context.cacheDir, "exports").apply { mkdirs() }

    fun exportFountain(context: Context, novel: Novel, volumes: List<Volume>, chapters: List<Chapter>): File {
        val text = Screenplay.toFountain(novel.title, novel.author, parts(volumes, chapters))
        val f = File(outDir(context), safeName(novel.title) + ".fountain")
        f.writeText(text, Charsets.UTF_8)
        return f
    }

    fun exportPdf(context: Context, novel: Novel, volumes: List<Volume>, chapters: List<Chapter>): File {
        val ps = parts(volumes, chapters)
        val isTv = novel.projectKind == "TV"
        // Truyền hình: mỗi tập bắt đầu trang mới, có tên tập; điện ảnh: chạy liền, không in tên phân đoạn
        val pages = if (isTv) ps.flatMap { Screenplay.paginate(listOf(it), true) } else Screenplay.paginate(ps, false)

        val pageW = 595 // A4 (pt)
        val pageH = 842
        val fontSize = 12f
        val lineH = 12f
        val left = 108f   // 1.5 inch
        val top = 72f     // 1 inch

        val regular = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.MONOSPACE
            textSize = fontSize
            color = android.graphics.Color.BLACK
        }
        val bold = Paint(regular).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
        val charW = regular.measureText("M")

        val doc = PdfDocument()
        var pageNo = 0

        // Trang bìa
        pageNo++
        doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create()).also { page ->
            val c = page.canvas
            val titlePaint = Paint(bold).apply { textSize = 18f }
            val lines = Screenplay.wrap(novel.title.uppercase(), 34)
            var y = pageH * 0.36f
            for (l in lines) {
                c.drawText(l, (pageW - titlePaint.measureText(l)) / 2f, y, titlePaint)
                y += 24f
            }
            y += 24f
            val by = "Kịch bản"
            c.drawText(by, (pageW - regular.measureText(by)) / 2f, y, regular)
            y += 18f
            val au = novel.author
            c.drawText(au, (pageW - regular.measureText(au)) / 2f, y, regular)
            val info = (if (isTv) "Phim truyền hình" else "Phim điện ảnh") + if (novel.genre.isNotBlank()) " · ${novel.genre}" else ""
            c.drawText(info, left, pageH - 90f, regular)
            doc.finishPage(page)
        }

        pages.forEachIndexed { idx, lines ->
            pageNo++
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            val c = page.canvas
            if (idx > 0) {
                val num = "${idx + 1}."
                c.drawText(num, left + 60 * charW - regular.measureText(num), top - 24f, regular)
            }
            var y = top + lineH
            for (pl in lines) {
                if (pl.text.isNotEmpty()) {
                    val paint = if (pl.bold) bold else regular
                    val x = if (pl.align == 2) left + (pl.indent + pl.width) * charW - paint.measureText(pl.text)
                    else left + pl.indent * charW
                    c.drawText(pl.text, x, y, paint)
                }
                y += lineH
            }
            doc.finishPage(page)
        }

        val f = File(outDir(context), safeName(novel.title) + ".pdf")
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        return f
    }

    /** Toàn bộ nội dung để thống kê cả kịch bản. */
    fun fullText(volumes: List<Volume>, chapters: List<Chapter>): String =
        parts(volumes, chapters).joinToString("\n\n") { it.content }
}
