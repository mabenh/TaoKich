package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Imperial Vietnamese Genealogy Palette (Sắc Đỏ - Vàng Đồng Hoàng Gia)
val ImperialRed = Color(0xFF8B1E1E)
val ImperialRedDark = Color(0xFF5A0E0E)
val ImperialRedLight = Color(0xFFA83232)

val ImperialGold = Color(0xFFD4AF37)
val ImperialGoldDark = Color(0xFFB8860B)
val ImperialGoldLight = Color(0xFFF6D365)

val BronzeDrumBrown = Color(0xFF5C381E)
val AntiqueParchment = Color(0xFFFDF8EE)
val AntiqueParchmentDark = Color(0xFFF5EACF)

// Gender lineage card colors
val MaleBluePrimary = Color(0xFF1E40AF)
val MaleBlueBg = Color(0xFFEFF6FF)
val MaleBlueBorder = Color(0xFF3B82F6)

val FemalePinkPrimary = Color(0xFFBE185D)
val FemalePinkBg = Color(0xFFFDF2F8)
val FemalePinkBorder = Color(0xFFEC4899)

val IncenseGlow = Color(0xFFF97316)
val AncestralGreen = Color(0xFF065F46)

val TextPrimaryDark = Color(0xFF261D15)
val TextSecondaryDark = Color(0xFF6B5848)
