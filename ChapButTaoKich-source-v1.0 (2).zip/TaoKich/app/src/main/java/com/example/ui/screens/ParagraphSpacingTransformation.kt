package com.example.ui.screens

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.unit.TextUnit

/**
 * Hiển thị khoảng cách giữa các đoạn văn trong ô soạn thảo mà KHÔNG thay đổi nội dung thật.
 *
 * Compose chưa hỗ trợ "paragraph spacing", nên ta biến đổi phần hiển thị:
 * - Mỗi chuỗi xuống dòng "\n…\n" được vẽ bằng ký tự vô hình (U+200B), mỗi ký tự nằm trong
 *   một đoạn riêng (ParagraphStyle tự tạo ngắt dòng), nên dòng trống vẫn là dòng trống.
 * - Sau mỗi chuỗi xuống dòng chèn thêm 1 "đoạn đệm" vô hình có chiều cao = [spacing].
 * - Nếu văn bản kết thúc bằng xuống dòng, thêm 1 đoạn rỗng để con trỏ nằm đúng dòng mới.
 *
 * Bản sao chép, lưu, đếm từ… vẫn dùng văn bản gốc. OffsetMapping được tính sẵn bằng mảng
 * nên con trỏ và vùng chọn luôn khớp.
 */
class ParagraphSpacingTransformation(
    private val spacing: TextUnit
) : VisualTransformation {

    override fun filter(text: AnnotatedString): TransformedText {
        val src = text.text
        if (src.indexOf('\n') < 0) return TransformedText(text, OffsetMapping.Identity)

        val n = src.length
        val sb = StringBuilder(n + 16)
        val o2t = IntArray(n + 1)
        val t2o = ArrayList<Int>(n + 16)
        val blankRanges = ArrayList<IntRange>()
        val spacerRanges = ArrayList<IntRange>()

        fun put(ch: Char, origOffset: Int) {
            // t2o[i] = vị trí gốc tương ứng với vị trí biến đổi i (trước ký tự thứ i)
            t2o.add(origOffset)
            sb.append(ch)
        }

        var i = 0
        while (i < n) {
            val c = src[i]
            if (c != '\n') {
                o2t[i] = sb.length
                put(c, i)
                i++
                continue
            }
            var j = i
            while (j < n && src[j] == '\n') j++

            for (idx in i until j) {
                o2t[idx] = sb.length
                if (idx == i) {
                    // Ký tự đầu: kết thúc đoạn trước (con trỏ ở cuối dòng trước nằm đúng chỗ)
                    put(ZW, idx)
                } else {
                    // Dòng trống: 1 đoạn riêng, cao bằng dòng thường
                    val start = sb.length
                    put(ZW, idx)
                    blankRanges.add(start until start + 1)
                }
            }
            // Đoạn đệm tạo khoảng cách. Vị trí ngay trước nó = cuối dòng cuối cùng của chuỗi xuống dòng.
            val s = sb.length
            put(ZW, j - 1)
            spacerRanges.add(s until s + 1)

            if (j == n) {
                // Văn bản kết thúc bằng xuống dòng: thêm đoạn rỗng cuối để đặt con trỏ
                o2t[n] = sb.length
                put(ZW, n)
            }
            i = j
        }
        if (src[n - 1] != '\n') o2t[n] = sb.length
        val tLen = sb.length
        t2o.add(n) // vị trí cuối văn bản biến đổi

        val noIndent = TextIndent.None
        val builder = AnnotatedString.Builder(sb.toString())
        // Giữ nguyên các SpanStyle gốc (nếu có) theo vị trí đã ánh xạ
        text.spanStyles.forEach { r ->
            val a = o2t[r.start.coerceIn(0, n)]
            val b = o2t[r.end.coerceIn(0, n)]
            if (b > a) builder.addStyle(r.item, a, b)
        }
        blankRanges.forEach { r ->
            builder.addStyle(ParagraphStyle(textIndent = noIndent), r.first, r.last + 1)
        }
        spacerRanges.forEach { r ->
            builder.addStyle(ParagraphStyle(lineHeight = spacing, textIndent = noIndent), r.first, r.last + 1)
        }
        val transformed = builder.toAnnotatedString()

        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int =
                o2t[offset.coerceIn(0, n)].coerceIn(0, tLen)

            override fun transformedToOriginal(offset: Int): Int =
                t2o[offset.coerceIn(0, tLen)].coerceIn(0, n)
        }
        return TransformedText(transformed, mapping)
    }

    override fun equals(other: Any?): Boolean =
        other is ParagraphSpacingTransformation && other.spacing == spacing

    override fun hashCode(): Int = spacing.hashCode()

    private companion object {
        const val ZW = '​'
    }
}
