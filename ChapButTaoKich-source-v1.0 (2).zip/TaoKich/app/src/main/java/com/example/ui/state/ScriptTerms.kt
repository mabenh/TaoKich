package com.example.ui.state

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf

/** Loại dự án kịch bản. */
object ProjectKind {
    const val FILM = "FILM"
    const val TV = "TV"

    val ALL: List<Pair<String, String>> = listOf(
        FILM to "Phim điện ảnh / phim ngắn",
        TV to "Phim truyền hình nhiều tập"
    )

    fun label(kind: String): String = if (kind == TV) "Truyền hình" else "Điện ảnh"
}

/**
 * Tên gọi các phần của kịch bản theo loại dự án:
 * điện ảnh: Hồi → Phân đoạn; truyền hình: Mùa → Tập.
 * [volName]/[chapName]: viết hoa chữ đầu (Hồi, Phân đoạn); [vol]/[chap]: chữ thường.
 * (Không đặt tên chỉ khác nhau hoa/thường như Vol/vol: trên JVM cùng thành getVol() và bị trùng.)
 */
data class ScriptTerms(val volName: String, val chapName: String) {
    val vol: String = volName.lowercase()
    val chap: String = chapName.lowercase()
}

fun termsOf(kind: String): ScriptTerms =
    if (kind == ProjectKind.TV) ScriptTerms("Mùa", "Tập") else ScriptTerms("Hồi", "Phân đoạn")

val LocalTerms = staticCompositionLocalOf { termsOf(ProjectKind.FILM) }

/** Tên gọi của dự án đang mở (dùng trong giao diện). */
val terms: ScriptTerms
    @Composable
    @ReadOnlyComposable
    get() = LocalTerms.current
