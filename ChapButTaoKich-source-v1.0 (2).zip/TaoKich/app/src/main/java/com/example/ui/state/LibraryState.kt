package com.example.ui.state

/** Trạng thái truyện (bản 1.5). */
object NovelStatus {
    const val WRITING = "WRITING"
    const val PAUSED = "PAUSED"
    const val COMPLETED = "COMPLETED"

    val ALL: List<Pair<String, String>> = listOf(
        WRITING to "Đang sáng tác",
        PAUSED to "Tạm ngưng",
        COMPLETED to "Hoàn thành"
    )

    fun label(key: String): String = ALL.firstOrNull { it.first == key }?.second ?: "Đang sáng tác"
}

/** Cách sắp xếp thư viện truyện. Truyện đã ghim luôn đứng đầu. */
enum class LibrarySort(val title: String) {
    UPDATED_DESC("Mới chỉnh sửa"),
    CREATED_DESC("Mới tạo"),
    CREATED_ASC("Cũ nhất"),
    TITLE_AZ("Tên A → Z"),
    WORDS_DESC("Nhiều chữ nhất"),
    PROGRESS_DESC("Gần đạt mục tiêu nhất")
}

/** Thiết kế bìa đang chọn trong hộp thoại tạo / sửa truyện. */
data class CoverDesign(
    val style: String = "MAKER",          // MAKER | COLOR
    val colorHex: String = "#8B1E1E",
    val border: String = "co-dien",       // mã viền có sẵn hoặc "none"
    val paper: String = "nga",
    val borderImage: String = "",         // đường dẫn ảnh viền tự tải lên
    val paperImage: String = "",          // đường dẫn ảnh giấy tự tải lên
    val ink: String = ""                  // #RRGGBB hoặc rỗng = tự động
)

/** Phạm vi thay tên khi đổi tên nhân vật / thiết lập. */
enum class RenameScope { CARD_ONLY, WHOLE_STORY }
