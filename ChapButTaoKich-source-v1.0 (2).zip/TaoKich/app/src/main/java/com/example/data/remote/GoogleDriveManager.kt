package com.example.data.remote

import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

data class GoogleAccountInfo(
    val email: String,
    val displayName: String,
    val photoUrl: String? = null
)

data class GoogleDriveBackupFile(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val modifiedTime: String,
    val createdTime: String
)

class GoogleDriveManager(private val context: Context) {

    private val driveScope = "https://www.googleapis.com/auth/drive.file"
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val gso: GoogleSignInOptions by lazy {
        try {
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .requestScopes(Scope(driveScope))
                .build()
        } catch (e: Throwable) {
            e.printStackTrace()
            GoogleSignInOptions.DEFAULT_SIGN_IN
        }
    }

    val signInClient: GoogleSignInClient? by lazy {
        try {
            GoogleSignIn.getClient(context, gso)
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    fun getSignInIntent(): Intent? {
        return try {
            signInClient?.signInIntent
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    fun getCurrentAccount(): GoogleAccountInfo? {
        return try {
            val account: GoogleSignInAccount? = GoogleSignIn.getLastSignedInAccount(context)
            account?.let {
                GoogleAccountInfo(
                    email = it.email ?: "Tài khoản Google",
                    displayName = it.displayName ?: (it.email?.substringBefore("@") ?: "Tác giả"),
                    photoUrl = it.photoUrl?.toString()
                )
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    fun handleSignInResult(data: Intent?): Result<GoogleAccountInfo> {
        return try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.getResult(ApiException::class.java)
            val info = GoogleAccountInfo(
                email = account.email ?: "Tài khoản Google",
                displayName = account.displayName ?: (account.email?.substringBefore("@") ?: "Tác giả"),
                photoUrl = account.photoUrl?.toString()
            )
            Result.success(info)
        } catch (e: ApiException) {
            val msg = when (e.statusCode) {
                10 -> "Lỗi cấu hình (mã 10): SHA-1 của khóa ký app chưa được đăng ký trong Google Cloud/Firebase cho gói com.aistudio.litewriter.vnwrtr."
                12501 -> "Bạn đã hủy đăng nhập."
                7 -> "Không có kết nối mạng."
                else -> "Mã lỗi ${e.statusCode}: ${e.localizedMessage ?: ""}"
            }
            Result.failure(Exception(msg))
        } catch (e: Throwable) {
            Result.failure(Exception(e.localizedMessage ?: "Đăng nhập Google thất bại"))
        }
    }

    suspend fun signOut(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Đợi signOut thực sự hoàn tất (trước đây không đợi nên tài khoản cũ vẫn có thể còn)
            signInClient?.signOut()?.let { com.google.android.gms.tasks.Tasks.await(it, 15, TimeUnit.SECONDS) }
            Result.success(Unit)
        } catch (e: Throwable) {
            Result.failure(Exception(e.localizedMessage ?: "Lỗi khi đăng xuất"))
        }
    }

    suspend fun getAccessToken(): String? = withContext(Dispatchers.IO) {
        val account = GoogleSignIn.getLastSignedInAccount(context)?.account ?: return@withContext null
        try {
            val scopes = "oauth2:$driveScope https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile"
            GoogleAuthUtil.getToken(context, account, scopes)
        } catch (e: com.google.android.gms.auth.UserRecoverableAuthException) {
            // Cần người dùng cấp lại quyền Drive -> báo rõ thay vì "Chưa đăng nhập"
            throw IllegalStateException("Cần cấp lại quyền Google Drive. Hãy đăng xuất rồi đăng nhập lại.", e)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Upload a JSON backup file directly to Google Drive via Drive v3 multipart upload.
     */
    suspend fun uploadBackupFile(file: File, backupName: String): Result<GoogleDriveBackupFile> = withContext(Dispatchers.IO) {
        try {
            val token = getAccessToken()
                ?: return@withContext Result.failure(IllegalStateException("Chưa đăng nhập hoặc chưa được cấp quyền truy cập Google Drive."))

            val metadataJson = JSONObject().apply {
                put("name", file.name)
                put("description", "Chấp Bút Tạo Kịch Backup: $backupName")
                put("mimeType", "application/json")
            }.toString()

            val requestBody = MultipartBody.Builder()
                // Drive API yêu cầu "multipart/related" cho uploadType=multipart.
                // MultipartBody.FORM (multipart/form-data) khiến Google trả lỗi 400 hoặc tạo tệp "Untitled".
                .setType("multipart/related".toMediaType())
                .addPart(
                    metadataJson.toRequestBody("application/json; charset=UTF-8".toMediaType())
                )
                .addPart(
                    file.asRequestBody("application/json".toMediaType())
                )
                .build()

            // Google Drive multipart upload URL
            val request = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
                .addHeader("Authorization", "Bearer $token")
                .post(requestBody)
                .build()

            val (code, responseBody) = httpClient.newCall(request).execute().use { r ->
                r.code to (r.body?.string() ?: "")
            }

            if (code !in 200..299) {
                return@withContext Result.failure(Exception("Lỗi máy chủ Google Drive ($code): $responseBody"))
            }

            val json = JSONObject(responseBody)
            val driveFile = GoogleDriveBackupFile(
                id = json.optString("id", ""),
                name = json.optString("name", file.name),
                sizeBytes = file.length(),
                modifiedTime = json.optString("modifiedTime", ""),
                createdTime = json.optString("createdTime", "")
            )
            Result.success(driveFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * List all novel backup files from Google Drive.
     */
    suspend fun listBackups(): Result<List<GoogleDriveBackupFile>> = withContext(Dispatchers.IO) {
        try {
            val token = getAccessToken()
                ?: return@withContext Result.failure(IllegalStateException("Chưa đăng nhập Google Drive."))

            val query = "trashed = false and name contains 'TaoKich_Backup'"
            val url = "https://www.googleapis.com/drive/v3/files" +
                    "?q=" + java.net.URLEncoder.encode(query, "UTF-8") +
                    "&fields=" + java.net.URLEncoder.encode("files(id, name, size, modifiedTime, createdTime)", "UTF-8") +
                    "&orderBy=" + java.net.URLEncoder.encode("modifiedTime desc", "UTF-8")

            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            val (code, responseBody) = httpClient.newCall(request).execute().use { r ->
                r.code to (r.body?.string() ?: "")
            }

            if (code !in 200..299) {
                return@withContext Result.failure(Exception("Lỗi lấy danh sách Drive ($code): $responseBody"))
            }

            val json = JSONObject(responseBody)
            val filesArray = json.optJSONArray("files")
            val list = mutableListOf<GoogleDriveBackupFile>()

            if (filesArray != null) {
                for (i in 0 until filesArray.length()) {
                    val obj = filesArray.getJSONObject(i)
                    list.add(
                        GoogleDriveBackupFile(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            sizeBytes = obj.optLong("size", 0L),
                            modifiedTime = obj.optString("modifiedTime", ""),
                            createdTime = obj.optString("createdTime", "")
                        )
                    )
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Download backup content from Google Drive to local destination file.
     */
    suspend fun downloadBackup(fileId: String, destFile: File): Result<File> = withContext(Dispatchers.IO) {
        try {
            val token = getAccessToken()
                ?: return@withContext Result.failure(IllegalStateException("Chưa đăng nhập Google Drive."))

            val url = "https://www.googleapis.com/drive/v3/files/$fileId?alt=media"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            // Đóng response sau khi đọc xong (trước đây bị rò rỉ kết nối)
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Lỗi tải tệp Drive (${response.code})"))
                }
                val body = response.body
                    ?: return@withContext Result.failure(Exception("Không nhận được dữ liệu từ Google Drive"))

                destFile.parentFile?.mkdirs()
                body.byteStream().use { input ->
                    FileOutputStream(destFile).use { out -> input.copyTo(out) }
                }
            }

            Result.success(destFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Delete backup from Google Drive.
     */
    suspend fun deleteDriveBackup(fileId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val token = getAccessToken()
                ?: return@withContext Result.failure(IllegalStateException("Chưa đăng nhập Google Drive."))

            val url = "https://www.googleapis.com/drive/v3/files/$fileId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete()
                .build()

            val code = httpClient.newCall(request).execute().use { it.code }
            if (code in 200..299 || code == 404) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Lỗi xóa tệp Drive ($code)"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
