package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.state.EditorThemeType
import com.example.ui.state.terms
import com.example.util.LineType
import com.example.util.Scene
import com.example.util.Screenplay
import com.example.util.ScriptStats
import java.util.Locale

/**
 * Trình bày kịch bản trong ô soạn thảo mà KHÔNG đổi nội dung thật (vị trí ký tự giữ nguyên):
 * tiêu đề cảnh in đậm có nền nhạt, tên nhân vật căn giữa in đậm, chỉ dẫn diễn xuất thụt sâu in nghiêng,
 * lời thoại thụt vào, chuyển cảnh căn phải.
 */
class ScreenplayTransformation(
    private val accent: Color,
    private val muted: Color
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val src = text.text
        val b = AnnotatedString.Builder(text)
        for (l in Screenplay.classify(src)) {
            if (l.end <= l.start) continue
            when (l.type) {
                LineType.SCENE -> {
                    b.addStyle(SpanStyle(fontWeight = FontWeight.Bold, color = accent, background = accent.copy(alpha = 0.10f)), l.start, l.end)
                }
                LineType.CHARACTER -> {
                    b.addStyle(ParagraphStyle(textAlign = TextAlign.Center, textIndent = TextIndent.None), l.start, l.end)
                    b.addStyle(SpanStyle(fontWeight = FontWeight.Bold), l.start, l.end)
                }
                LineType.PARENTHETICAL -> {
                    b.addStyle(ParagraphStyle(textIndent = TextIndent(firstLine = 56.sp, restLine = 56.sp)), l.start, l.end)
                    b.addStyle(SpanStyle(fontStyle = FontStyle.Italic, color = muted), l.start, l.end)
                }
                LineType.DIALOGUE -> {
                    b.addStyle(ParagraphStyle(textIndent = TextIndent(firstLine = 36.sp, restLine = 36.sp)), l.start, l.end)
                }
                LineType.TRANSITION -> {
                    b.addStyle(ParagraphStyle(textAlign = TextAlign.End, textIndent = TextIndent.None), l.start, l.end)
                    b.addStyle(SpanStyle(fontWeight = FontWeight.Bold, color = muted), l.start, l.end)
                }
                LineType.SECTION -> b.addStyle(SpanStyle(fontWeight = FontWeight.Bold, color = accent), l.start, l.end)
                LineType.NOTE -> b.addStyle(SpanStyle(fontStyle = FontStyle.Italic, color = muted), l.start, l.end)
                else -> {}
            }
        }
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }

    override fun equals(other: Any?): Boolean =
        other is ScreenplayTransformation && other.accent == accent && other.muted == muted

    override fun hashCode(): Int = accent.hashCode() * 31 + muted.hashCode()
}

/** Thanh kiểu dòng: đổi dòng đang gõ sang Cảnh / Hành động / Nhân vật / Chỉ dẫn / Chuyển cảnh, kèm gợi ý. */
@Composable
fun ScreenplayLineBar(
    theme: EditorThemeType,
    currentType: LineType,
    suggestions: List<Pair<String, String>>,
    onConvert: (LineType) -> Unit,
    onSuggestion: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().background(theme.surfaceColor)) {
        if (suggestions.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Gợi ý:", fontSize = 11.sp, color = theme.secondaryTextColor)
                suggestions.forEach { (label, value) ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(theme.accentColor.copy(alpha = 0.15f))
                            .clickable { onSuggestion(value) }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(label, fontSize = 12.sp, color = theme.textColor, fontWeight = FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Dòng: ${if (currentType == LineType.BLANK) "trống" else currentType.label.lowercase()}",
                fontSize = 11.sp,
                color = theme.secondaryTextColor,
                modifier = Modifier.padding(end = 4.dp)
            )
            listOf(LineType.SCENE, LineType.ACTION, LineType.CHARACTER, LineType.PARENTHETICAL, LineType.TRANSITION).forEach { t ->
                val sel = t == currentType
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (sel) theme.accentColor.copy(alpha = 0.25f) else theme.backgroundColor)
                        .clickable { onConvert(t) }
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                        .testTag("line_type_${t.name}")
                ) {
                    Text(t.short, fontSize = 12.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.SemiBold, color = theme.textColor)
                }
            }
        }
    }
}

/** Danh sách cảnh của phân đoạn / tập đang soạn. Bấm để nhảy tới cảnh. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SceneListSheet(
    scenes: List<Scene>,
    numberOffset: Int,
    onDismiss: () -> Unit,
    onJump: (Int) -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Text("Danh sách cảnh (${scenes.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (scenes.isEmpty()) {
                Text(
                    "Chưa có cảnh nào. Gõ dòng bắt đầu bằng NỘI. hoặc NGOẠI. (ví dụ: NỘI. NHÀ LAN – ĐÊM) để mở cảnh mới.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
            LazyColumn(modifier = Modifier.heightIn(max = 480.dp)) {
                itemsIndexed(scenes) { i, sc ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onJump(sc.start) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${numberOffset + i + 1}",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.width(36.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(sc.heading.uppercase(), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                listOf(sc.interior, sc.time).filter { it.isNotEmpty() }.joinToString(" · "),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    HorizontalDivider()
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

fun formatPages(p: Double): String = String.format(Locale("vi", "VN"), "%.1f", p)

/** Phút phim (1 trang ≈ 1 phút) dạng "12 phút" / "1 giờ 05 phút". */
fun formatMinutes(p: Double): String {
    val m = Math.round(p).toInt()
    if (m < 1) return "dưới 1 phút"
    return if (m >= 60) "${m / 60} giờ ${String.format(Locale.US, "%02d", m % 60)} phút" else "$m phút"
}

/** Thống kê kịch bản: số trang / phút, cảnh, bối cảnh, nội–ngoại, ngày–đêm, lượng thoại theo nhân vật. */
@Composable
fun ScriptStatsDialog(title: String, stats: ScriptStats, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.heightIn(max = 480.dp)) {
                item {
                    StatRow("Số trang (ước tính):", "≈ ${formatPages(stats.pages)} trang")
                    StatRow("Thời lượng phim:", "≈ ${formatMinutes(stats.minutes)}")
                    StatRow("Số cảnh:", "${stats.scenes}")
                    StatRow("Số bối cảnh:", "${stats.locations.size}")
                    StatRow("Chữ hành động / thoại:", "${stats.actionWords} / ${stats.dialogueWords}")
                }
                if (stats.interiorCounts.isNotEmpty()) item {
                    Text("Nội / ngoại cảnh", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    stats.interiorCounts.forEach { (k, v) -> StatRow("  $k", "$v cảnh") }
                }
                if (stats.timeCounts.isNotEmpty()) item {
                    Text("Thời điểm", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    stats.timeCounts.forEach { (k, v) -> StatRow("  $k", "$v cảnh") }
                }
                if (stats.characters.isNotEmpty()) item {
                    Text("Lượng thoại theo nhân vật", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    val maxW = stats.characters.maxOf { it.words }.coerceAtLeast(1)
                    stats.characters.forEach { c ->
                        Column(Modifier.padding(vertical = 2.dp)) {
                            StatRow("  ${c.name}", "${c.blocks} lượt · ${c.words} chữ")
                            LinearProgressIndicator(
                                progress = { c.words.toFloat() / maxW },
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                            )
                        }
                    }
                }
                if (stats.locations.isNotEmpty()) item {
                    Text("Bối cảnh", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    Text(stats.locations.joinToString(" · "), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}

/** Gợi ý trình bày kịch bản (hiện trong cài đặt soạn thảo). */
@Composable
fun ScreenplayHelp() {
    val t = terms
    Text(
        "Cách gõ kịch bản: dòng bắt đầu bằng NỘI. / NGOẠI. là tiêu đề cảnh (ví dụ NỘI. NHÀ LAN – ĐÊM). " +
            "Tên nhân vật VIẾT HOA trên một dòng riêng, lời thoại ngay dòng dưới; chỉ dẫn diễn xuất đặt trong ( ). " +
            "Chuyển cảnh viết hoa, kết thúc bằng dấu hai chấm (CẮT SANG:). Để trống một dòng giữa các khối. " +
            "Mỗi ${t.chap} là một tệp kịch bản riêng; xuất cả kịch bản ra PDF / Fountain ở màn hình chi tiết.",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
