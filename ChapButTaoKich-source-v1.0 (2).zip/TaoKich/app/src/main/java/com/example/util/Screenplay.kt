package com.example.util

/**
 * Xử lý kịch bản phim (thuần Kotlin, kiểm thử được trên JVM).
 *
 * Nội dung mỗi phân đoạn / tập được lưu dạng chữ thường theo lối Fountain:
 * - Tiêu đề cảnh: dòng bắt đầu bằng NỘI. / NGOẠI. / NỘI./NGOẠI. / INT. / EXT. … (hoặc "." ở đầu để ép).
 * - Nhân vật: dòng VIẾT HOA đứng sau dòng trống, ngay dưới là lời thoại (hoặc "@" ở đầu để ép).
 * - Chỉ dẫn diễn xuất: dòng trong ngoặc ( ) nằm trong khối thoại.
 * - Lời thoại: các dòng dưới tên nhân vật cho tới dòng trống.
 * - Chuyển cảnh: dòng VIẾT HOA kết thúc bằng "SANG:" / "TO:" … (hoặc ">" ở đầu để ép).
 * - Còn lại là hành động.
 */
enum class LineType(val label: String, val short: String) {
    SCENE("Tiêu đề cảnh", "Cảnh"),
    ACTION("Hành động", "Hành động"),
    CHARACTER("Nhân vật", "Nhân vật"),
    PARENTHETICAL("Chỉ dẫn diễn xuất", "( )"),
    DIALOGUE("Lời thoại", "Thoại"),
    TRANSITION("Chuyển cảnh", "Chuyển"),
    SECTION("Mục", "Mục"),
    NOTE("Ghi chú", "Ghi chú"),
    BLANK("", "")
}

/** Một dòng kịch bản: [start, end) trong văn bản gốc (không gồm ký tự xuống dòng). */
data class ScriptLine(val start: Int, val end: Int, val type: LineType, val text: String)

data class Scene(
    val start: Int,
    val heading: String,
    val interior: String,   // "NỘI", "NGOẠI", "NỘI/NGOẠI" hoặc ""
    val location: String,
    val time: String
)

data class CharacterStat(val name: String, val blocks: Int, val words: Int)

data class ScriptStats(
    val pages: Double,
    val scenes: Int,
    val interiorCounts: Map<String, Int>,
    val timeCounts: Map<String, Int>,
    val locations: List<String>,
    val characters: List<CharacterStat>,
    val actionWords: Int,
    val dialogueWords: Int
) {
    /** Quy ước ngành: 1 trang kịch bản ≈ 1 phút phim. */
    val minutes: Double get() = pages
}

object Screenplay {

    val SCENE_PREFIXES = listOf("NỘI.", "NGOẠI.", "NỘI./NGOẠI.", "INT.", "EXT.", "INT./EXT.")
    val TIMES = listOf("NGÀY", "ĐÊM", "SÁNG", "TRƯA", "CHIỀU", "TỐI", "BÌNH MINH", "HOÀNG HÔN", "LIÊN TỤC", "CÙNG LÚC", "SAU ĐÓ")
    val TRANSITIONS = listOf(
        "CẮT SANG:", "CẮT NHANH SANG:", "HÒA SANG:", "MỜ DẦN SANG:", "CHUYỂN CẢNH:",
        "HỒI TƯỞNG:", "HẾT HỒI TƯỞNG.", "MỜ DẦN.", "TỐI ĐEN.", "HẾT."
    )
    val EXTENSIONS = listOf("(V.O.)", "(O.S.)", "(TIẾNG)", "(GỌI ĐIỆN)", "(TIẾP)")

    private const val SCENE_KEYS = """(?:NỘI\.?\s*/\s*NGOẠI|NGOẠI\.?\s*/\s*NỘI|INT\.?\s*/\s*EXT|EXT\.?\s*/\s*INT|I/E|NỘI|NGOẠI|INT|EXT|EST)"""
    // Viết HOA: "NỘI BẾP", "NGOẠI. SÂN" … (không nhận "Nội dung…", "Ngoại hình…" của câu thường)
    private val SCENE_UPPER_RE = Regex("""^$SCENE_KEYS(?:\.|\s)""")
    // Có dấu chấm thì nhận cả chữ thường: "nội. bếp – ngày"
    private val SCENE_DOT_RE = Regex("""^$SCENE_KEYS\.""", RegexOption.IGNORE_CASE)
    private val ENDS_SENTENCE = Regex("""[.!?…]["”']?$""")

    fun isUpper(t: String): Boolean = t.any { it.isLetter() } && t == t.uppercase()

    fun isSceneHeading(t: String): Boolean {
        val x = t.trimStart()
        if (x.length > 1 && x[0] == '.' && x[1] != '.' && !x[1].isWhitespace()) return true
        return SCENE_UPPER_RE.containsMatchIn(x) || SCENE_DOT_RE.containsMatchIn(x)
    }

    fun isTransition(t: String): Boolean {
        val s = t.trim()
        if (s.startsWith(">") && !s.endsWith("<")) return true
        if (TRANSITIONS.any { it.equals(s, ignoreCase = true) }) return true
        if (!isUpper(s)) return false
        return s.endsWith("TO:") || s.endsWith("SANG:") || TRANSITIONS.any { it == s }
    }

    /** Tên nhân vật từ dòng gọi tên: bỏ "@", "^" (thoại đôi) và phần mở rộng trong ngoặc như (V.O.). */
    fun characterName(cue: String): String =
        cue.trim().removePrefix("@").removeSuffix("^").replace(Regex("""\s*\([^)]*\)"""), "").trim()

    private fun looksLikeCue(t: String): Boolean {
        if (t.startsWith("@")) return t.length > 1
        if (t.length > 45) return false
        val core = t.substringBefore('(').trim().removeSuffix("^").trim()
        if (core.isEmpty() || !isUpper(core)) return false
        if (core.endsWith(":")) return false
        if (ENDS_SENTENCE.containsMatchIn(core)) return false
        return true
    }

    /** Chia văn bản thành các dòng và nhận kiểu từng dòng. */
    fun classify(text: String): List<ScriptLine> {
        val out = ArrayList<ScriptLine>()
        val starts = ArrayList<Int>()
        starts.add(0)
        for (i in text.indices) if (text[i] == '\n') starts.add(i + 1)
        val ends = starts.mapIndexed { idx, s -> if (idx + 1 < starts.size) starts[idx + 1] - 1 else text.length }
        var inDialogue = false
        for (k in starts.indices) {
            val s = starts[k]
            val e = ends[k]
            val raw = text.substring(s, e)
            val t = raw.trim()
            val prevBlank = k == 0 || text.substring(starts[k - 1], ends[k - 1]).isBlank()
            val nextNonBlank = k + 1 < starts.size && text.substring(starts[k + 1], ends[k + 1]).isNotBlank()
            val type = when {
                t.isEmpty() -> { inDialogue = false; LineType.BLANK }
                t.startsWith("#") -> { inDialogue = false; LineType.SECTION }
                t.startsWith("[[") && t.endsWith("]]") -> LineType.NOTE
                inDialogue && t.startsWith("(") && t.endsWith(")") -> LineType.PARENTHETICAL
                inDialogue -> LineType.DIALOGUE
                isSceneHeading(t) -> LineType.SCENE
                prevBlank && isTransition(t) -> LineType.TRANSITION
                prevBlank && nextNonBlank && looksLikeCue(t) -> { inDialogue = true; LineType.CHARACTER }
                else -> LineType.ACTION
            }
            out.add(ScriptLine(s, e, type, raw))
        }
        return out
    }

    /** Kiểu dòng tại vị trí [offset]. */
    fun typeAt(text: String, offset: Int): LineType {
        val lines = classify(text)
        return lines.firstOrNull { offset in it.start..it.end }?.type ?: LineType.ACTION
    }

    /** Tách tiêu đề cảnh: NỘI./NGOẠI., địa điểm, thời điểm. */
    fun parseHeading(heading: String): Scene {
        var h = heading.trim().removePrefix(".").trim()
        // Bỏ số cảnh kiểu Fountain "#12#" ở cuối
        h = h.replace(Regex("""\s*#[^#]*#\s*$"""), "")
        val up = h.uppercase()
        val interior = when {
            Regex("""^(NỘI\.?\s*/\s*NGOẠI|NGOẠI\.?\s*/\s*NỘI|INT\.?\s*/\s*EXT|EXT\.?\s*/\s*INT|I/E)""").containsMatchIn(up) -> "NỘI/NGOẠI"
            up.startsWith("NỘI") || up.startsWith("INT") -> "NỘI"
            up.startsWith("NGOẠI") || up.startsWith("EXT") -> "NGOẠI"
            else -> ""
        }
        val rest = h.replaceFirst(
            Regex("""^(?:NỘI\.?\s*/\s*NGOẠI|NGOẠI\.?\s*/\s*NỘI|INT\.?\s*/\s*EXT|EXT\.?\s*/\s*INT|I/E|NỘI|NGOẠI|INT|EXT|EST)\.?\s*""", RegexOption.IGNORE_CASE),
            ""
        ).trim()
        val sep = Regex("""\s+[–—-]\s+""").findAll(rest).lastOrNull()
        val location = (if (sep != null) rest.substring(0, sep.range.first) else rest).trim()
        val time = (if (sep != null) rest.substring(sep.range.last + 1) else "").trim().uppercase()
        return Scene(0, h, interior, location, time)
    }

    fun scenes(text: String): List<Scene> =
        classify(text).filter { it.type == LineType.SCENE }.map { parseHeading(it.text).copy(start = it.start) }

    /** Số dòng in trên trang của một dòng kịch bản (khổ chuẩn: hành động 60 ký tự/dòng, thoại 35, chỉ dẫn 25). */
    private fun printedLines(l: ScriptLine): Int {
        val len = l.text.trim().length
        return when (l.type) {
            LineType.BLANK -> 1
            LineType.SCENE, LineType.CHARACTER, LineType.TRANSITION -> 1
            LineType.DIALOGUE -> maxOf(1, (len + 34) / 35)
            LineType.PARENTHETICAL -> maxOf(1, (len + 24) / 25)
            LineType.SECTION, LineType.NOTE -> 0
            LineType.ACTION -> maxOf(1, (len + 59) / 60)
        }
    }

    fun estimatePages(text: String): Double {
        val lines = classify(text).sumOf { printedLines(it) }
        return lines / 55.0
    }

    fun stats(text: String): ScriptStats {
        val lines = classify(text)
        val scenes = lines.filter { it.type == LineType.SCENE }.map { parseHeading(it.text) }
        val ie = scenes.groupingBy { it.interior.ifEmpty { "Khác" } }.eachCount()
        val times = scenes.groupingBy { it.time.ifEmpty { "Không ghi" } }.eachCount()
        val locations = scenes.map { it.location.uppercase() }.filter { it.isNotEmpty() }.distinct()
        val chars = LinkedHashMap<String, IntArray>()
        var current: String? = null
        var actionWords = 0
        var dialogueWords = 0
        for (l in lines) {
            when (l.type) {
                LineType.CHARACTER -> {
                    current = characterName(l.text).uppercase()
                    chars.getOrPut(current) { IntArray(2) }[0]++
                }
                LineType.DIALOGUE -> {
                    val w = TextTools.wordCount(l.text)
                    dialogueWords += w
                    current?.let { chars.getOrPut(it) { IntArray(2) }[1] += w }
                }
                LineType.ACTION -> actionWords += TextTools.wordCount(l.text)
                LineType.BLANK -> current = null
                else -> {}
            }
        }
        val pages = lines.sumOf { printedLines(it) } / 55.0
        return ScriptStats(
            pages = pages,
            scenes = scenes.size,
            interiorCounts = ie,
            timeCounts = times,
            locations = locations,
            characters = chars.map { (n, a) -> CharacterStat(n, a[0], a[1]) }.sortedByDescending { it.words },
            actionWords = actionWords,
            dialogueWords = dialogueWords
        )
    }

    /** Tên nhân vật (đã chuẩn hóa) có lời thoại trong văn bản, theo thứ tự xuất hiện. */
    fun characterNames(text: String): List<String> =
        classify(text).filter { it.type == LineType.CHARACTER }.map { characterName(it.text) }
            .filter { it.isNotEmpty() }.distinctBy { it.uppercase() }

    fun locationsIn(text: String): List<String> =
        scenes(text).map { it.location.uppercase() }.filter { it.isNotEmpty() }.distinct()

    /**
     * Chuẩn hóa: viết hoa tiêu đề cảnh, tên nhân vật, chuyển cảnh; đảm bảo có dòng trống trước tiêu đề cảnh,
     * tên nhân vật và chuyển cảnh; gộp nhiều dòng trống; bỏ khoảng trắng cuối dòng.
     */
    fun normalize(text: String): String {
        val lines = classify(text)
        val out = ArrayList<String>()
        for (l in lines) {
            val t = l.text.trimEnd()
            when (l.type) {
                LineType.SCENE, LineType.CHARACTER, LineType.TRANSITION -> {
                    if (out.isNotEmpty() && out.last().isNotBlank()) out.add("")
                    out.add(t.trim().uppercase())
                }
                LineType.BLANK -> if (out.isNotEmpty() && out.last().isNotBlank()) out.add("")
                LineType.PARENTHETICAL, LineType.DIALOGUE -> out.add(t.trim())
                else -> out.add(t)
            }
        }
        while (out.isNotEmpty() && out.last().isBlank()) out.removeAt(out.lastIndex)
        return out.joinToString("\n")
    }

    /** Đổi dòng tại [offset] sang kiểu [type]. Trả về (văn bản mới, vị trí con trỏ mới). */
    fun convertLine(text: String, offset: Int, type: LineType): Pair<String, Int> {
        val s = if (offset <= 0) 0 else text.lastIndexOf('\n', offset - 1) + 1
        val eIdx = text.indexOf('\n', offset)
        val e = if (eIdx < 0) text.length else eIdx
        var line = text.substring(s, e).trim()
        // bỏ ký hiệu ép kiểu cũ
        line = line.removePrefix("@").removePrefix(">").trim()
        if (line.startsWith(".") && line.length > 1 && line[1] != '.') line = line.substring(1)
        if (line.startsWith("(") && line.endsWith(")")) line = line.substring(1, line.length - 1).trim()
        val newLine = when (type) {
            LineType.SCENE -> if (isSceneHeading(line)) line.uppercase() else ("NỘI. " + line).trimEnd().uppercase()
            LineType.CHARACTER -> line.uppercase()
            LineType.PARENTHETICAL -> "($line)"
            LineType.TRANSITION -> if (isTransition(line.uppercase())) line.uppercase() else (if (line.isEmpty()) "CẮT SANG:" else line.uppercase() + if (line.endsWith(":")) "" else ":")
            LineType.ACTION -> line
            else -> line
        }
        val before = text.substring(0, s)
        val after = text.substring(e)
        // Tiêu đề cảnh, nhân vật, chuyển cảnh cần dòng trống phía trên
        val needBlank = type == LineType.SCENE || type == LineType.CHARACTER || type == LineType.TRANSITION
        val prefix = if (needBlank && before.isNotEmpty() && !before.endsWith("\n\n")) before + "\n" else before
        val result = prefix + newLine + after
        return result to (prefix.length + newLine.length)
    }

    /** Thay dòng chứa [offset] bằng [replacement] (dùng khi bấm gợi ý). */
    fun replaceLine(text: String, offset: Int, replacement: String): Pair<String, Int> {
        val s = if (offset == 0) 0 else text.lastIndexOf('\n', offset - 1) + 1
        val eIdx = text.indexOf('\n', offset)
        val e = if (eIdx < 0) text.length else eIdx
        val result = text.substring(0, s) + replacement + text.substring(e)
        return result to (s + replacement.length)
    }

    /** Dòng hiện tại (chứa [offset]). */
    fun currentLine(text: String, offset: Int): String {
        val o = offset.coerceIn(0, text.length)
        val s = if (o == 0) 0 else text.lastIndexOf('\n', o - 1) + 1
        val eIdx = text.indexOf('\n', o)
        return text.substring(s, if (eIdx < 0) text.length else eIdx)
    }

    /**
     * Gợi ý cho dòng đang gõ:
     * - Dòng trống / đầu cảnh: NỘI., NGOẠI.
     * - Đang gõ tiêu đề cảnh: địa điểm đã dùng, rồi " – NGÀY / ĐÊM …".
     * - Dòng sau dòng trống: tên nhân vật (từ thẻ nhân vật và tên đã có thoại), chuyển cảnh.
     */
    fun suggestions(
        text: String,
        offset: Int,
        knownCharacters: List<String>,
        knownLocations: List<String>
    ): List<Pair<String, String>> {
        val o = offset.coerceIn(0, text.length)
        val line = currentLine(text, o)
        val t = line.trim()
        val upper = t.uppercase()
        val s = if (o == 0) 0 else text.lastIndexOf('\n', o - 1) + 1
        val prevBlank = s == 0 || text.substring(0, s).trimEnd(' ', '\t').endsWith("\n\n") || text.substring(0, s).isBlank()
        val out = ArrayList<Pair<String, String>>()
        if (isSceneHeading(t)) {
            val sc = parseHeading(t)
            val prefix = t.substring(0, t.length - t.trimStart().length) +
                when (sc.interior) { "NỘI/NGOẠI" -> "NỘI./NGOẠI."; "NGOẠI" -> "NGOẠI."; "NỘI" -> "NỘI."; else -> t.substringBefore(' ') }
            val hasSep = Regex("""\s+[–—-]\s*""").containsMatchIn(t.substringAfter(' ', ""))
            if (!hasSep) {
                val typed = sc.location.uppercase()
                knownLocations.filter { it.startsWith(typed) && it != typed }.take(8).forEach {
                    out.add(it to "$prefix $it")
                }
                if (sc.location.isNotEmpty()) TIMES.take(6).forEach { out.add("– $it" to "${t.trimEnd()} – $it") }
            } else {
                val typedTime = sc.time
                TIMES.filter { it.startsWith(typedTime) && it != typedTime }.forEach { tm ->
                    out.add(tm to "$prefix ${sc.location.uppercase()} – $tm")
                }
            }
            return out
        }
        if (t.isEmpty() || (prevBlank && upper == t && t.length <= 30)) {
            if (t.isEmpty()) {
                SCENE_PREFIXES.take(3).forEach { out.add(it to "$it ") }
            }
            if (prevBlank) {
                knownCharacters.map { it.uppercase() }.distinct()
                    .filter { it.startsWith(upper) && it != upper }
                    .take(10).forEach { out.add(it to it) }
                TRANSITIONS.filter { it.startsWith(upper) && it != upper }.take(4).forEach { out.add(it to it) }
            }
        }
        return out
    }

    // ------------------------------------------------------------------
    // FOUNTAIN: xuất / nhập
    // ------------------------------------------------------------------

    /** Một mục để xuất: tiêu đề phần lớn (Hồi/Mùa) và phần nhỏ (Phân đoạn/Tập). */
    data class ExportPart(val volumeTitle: String?, val chapterTitle: String, val content: String)

    /** Xuất định dạng Fountain (mở được bằng Highland, Fade In, WriterSolo, Beat…). */
    fun toFountain(title: String, author: String, parts: List<ExportPart>): String {
        val sb = StringBuilder()
        sb.append("Title: ").append(title).append('\n')
        if (author.isNotBlank()) sb.append("Credit: Viết bởi\nAuthor: ").append(author).append('\n')
        sb.append('\n')
        var lastVol: String? = null
        for (p in parts) {
            if (p.volumeTitle != null && p.volumeTitle != lastVol) {
                sb.append("# ").append(p.volumeTitle).append("\n\n")
                lastVol = p.volumeTitle
            }
            sb.append("## ").append(p.chapterTitle).append("\n\n")
            for (l in classify(p.content)) {
                val t = l.text.trimEnd()
                when (l.type) {
                    // Tiêu đề cảnh tiếng Việt (NỘI./NGOẠI.) không phải chuẩn Fountain: thêm "." để ép
                    LineType.SCENE -> sb.append(
                        if (Regex("""^(INT|EXT|EST|I/E)[.\s/]""", RegexOption.IGNORE_CASE).containsMatchIn(t.trim()) || t.trim().startsWith(".")) t.trim()
                        else "." + t.trim()
                    )
                    LineType.TRANSITION -> sb.append(if (t.trim().endsWith("TO:") || t.trim().startsWith(">")) t.trim() else "> " + t.trim())
                    LineType.CHARACTER -> sb.append(if (t.trim().startsWith("@")) t.trim() else t.trim())
                    else -> sb.append(t)
                }
                sb.append('\n')
            }
            sb.append('\n')
        }
        return sb.toString().trimEnd() + "\n"
    }

    data class ImportedChapter(val title: String, val content: String, val outline: String)
    data class ImportedVolume(val title: String, val chapters: List<ImportedChapter>)
    data class ImportedScript(val title: String, val author: String, val volumes: List<ImportedVolume>) {
        val chapterCount: Int get() = volumes.sumOf { it.chapters.size }
    }

    /**
     * Đọc tệp Fountain. "# …" = phần lớn (Hồi / Mùa), "## …" = phần nhỏ (Phân đoạn / Tập).
     * Không có mục thì cả kịch bản vào một phần. Dòng "= …" (tóm tắt) đưa vào dàn ý.
     */
    fun parseFountain(source: String, fallbackTitle: String, volName: String = "Hồi", chapName: String = "Phân đoạn"): ImportedScript {
        var text = source.replace("\r\n", "\n").replace('\r', '\n').removePrefix("﻿")
        // Bỏ phần "boneyard" /* … */
        text = text.replace(Regex("""/\*.*?\*/""", RegexOption.DOT_MATCHES_ALL), "")
        var title = fallbackTitle
        var author = ""
        val allLines = text.split('\n')
        var bodyStart = 0
        // Trang tiêu đề: các dòng "Khóa: giá trị" ở đầu tệp, kết thúc ở dòng trống
        if (allLines.isNotEmpty() && Regex("""^[A-Za-z][A-Za-z ]*:""").containsMatchIn(allLines[0])) {
            var i = 0
            var key = ""
            while (i < allLines.size && allLines[i].isNotBlank()) {
                val l = allLines[i]
                val m = Regex("""^([A-Za-z][A-Za-z ]*):\s*(.*)$""").find(l)
                if (m != null) {
                    key = m.groupValues[1].lowercase()
                    val v = m.groupValues[2].trim()
                    if (v.isNotEmpty()) {
                        if (key == "title") title = v.replace("_", "").replace("*", "")
                        if (key == "author" || key == "authors") author = v
                    }
                } else if (key == "title" && title == fallbackTitle) {
                    title = l.trim().replace("_", "").replace("*", "")
                } else if ((key == "author" || key == "authors") && author.isEmpty()) {
                    author = l.trim()
                }
                i++
            }
            bodyStart = i
        }

        data class MCh(val title: String, val lines: MutableList<String> = ArrayList(), val outline: MutableList<String> = ArrayList())
        data class MVol(val title: String, val chapters: MutableList<MCh> = ArrayList())
        val vols = ArrayList<MVol>()
        var curVol: MVol? = null
        var curCh: MCh? = null
        fun vol(): MVol = curVol ?: MVol("$volName 1").also { vols.add(it); curVol = it }
        fun ch(): MCh = curCh ?: MCh("$chapName ${vols.sumOf { it.chapters.size } + 1}").also { vol().chapters.add(it); curCh = it }

        for (idx in bodyStart until allLines.size) {
            val raw = allLines[idx]
            val t = raw.trim()
            when {
                t.startsWith("###") -> ch().lines.add("[[${t.trimStart('#').trim()}]]")
                t.startsWith("##") -> { curCh = MCh(t.trimStart('#').trim()).also { vol().chapters.add(it) } }
                t.startsWith("#") -> { curVol = MVol(t.trimStart('#').trim()).also { vols.add(it) }; curCh = null }
                t.startsWith("=") && !t.startsWith("===") -> ch().outline.add(t.removePrefix("=").trim())
                t.startsWith("===") -> {}
                else -> {
                    var l = raw.trimEnd()
                    val tt = l.trim()
                    // Bỏ ký hiệu ép kiểu của Fountain cho dễ đọc khi đã nhận dạng được
                    if (tt.startsWith(".") && tt.length > 1 && tt[1] != '.' && isSceneHeading(tt.substring(1))) l = tt.substring(1)
                    else if (tt.startsWith(">") && tt.endsWith("<")) l = tt.removePrefix(">").removeSuffix("<").trim()
                    if (curCh == null && l.isBlank()) continue
                    ch().lines.add(l)
                }
            }
        }
        val result = vols.map { v ->
            ImportedVolume(v.title, v.chapters.map { c ->
                val lines = c.lines.toMutableList()
                while (lines.isNotEmpty() && lines.first().isBlank()) lines.removeAt(0)
                while (lines.isNotEmpty() && lines.last().isBlank()) lines.removeAt(lines.lastIndex)
                ImportedChapter(c.title, collapseBlank(lines).joinToString("\n"), c.outline.joinToString("\n"))
            })
        }.filter { it.chapters.isNotEmpty() }
        return ImportedScript(
            title.ifBlank { fallbackTitle },
            author,
            result.ifEmpty { listOf(ImportedVolume("$volName 1", listOf(ImportedChapter("$chapName 1", "", "")))) }
        )
    }

    private fun collapseBlank(lines: List<String>): List<String> {
        val out = ArrayList<String>()
        for (l in lines) {
            if (l.isBlank() && out.isNotEmpty() && out.last().isBlank()) continue
            out.add(if (l.isBlank()) "" else l)
        }
        return out
    }

    // ------------------------------------------------------------------
    // TRÌNH BÀY TRANG (dùng cho xuất PDF): khổ chuẩn kịch bản, phông đơn cách 12pt
    // ------------------------------------------------------------------

    /** Một dòng in: [indent] và [width] tính theo số ký tự; [align] 0 trái, 2 phải. */
    data class PrintLine(val text: String, val type: LineType, val indent: Int, val width: Int, val align: Int = 0, val bold: Boolean = false)

    const val LINES_PER_PAGE = 55
    const val PAGE_CHARS = 60

    private fun geometry(type: LineType): Triple<Int, Int, Int> = when (type) {
        // indent, width, align (ký tự tính từ lề trái 1.5in; 10 ký tự / inch)
        LineType.CHARACTER -> Triple(22, 38, 0)
        LineType.PARENTHETICAL -> Triple(16, 25, 0)
        LineType.DIALOGUE -> Triple(10, 35, 0)
        LineType.TRANSITION -> Triple(0, 60, 2)
        else -> Triple(0, 60, 0)
    }

    fun wrap(text: String, width: Int): List<String> {
        val words = text.trim().split(Regex("""\s+""")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return listOf("")
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (w in words) {
            var word = w
            while (word.length > width) {
                if (cur.isNotEmpty()) { out.add(cur.toString()); cur = StringBuilder() }
                out.add(word.substring(0, width))
                word = word.substring(width)
            }
            if (cur.isEmpty()) cur.append(word)
            else if (cur.length + 1 + word.length <= width) cur.append(' ').append(word)
            else { out.add(cur.toString()); cur = StringBuilder(word) }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    /** Các khối in (mỗi khối không bị tách giữa hai trang nếu tránh được). */
    private fun blocks(parts: List<ExportPart>, showChapterTitles: Boolean): List<List<PrintLine>> {
        val out = ArrayList<List<PrintLine>>()
        for (p in parts) {
            if (showChapterTitles) {
                out.add(listOf(PrintLine(p.chapterTitle.uppercase(), LineType.SECTION, 0, 60, bold = true), PrintLine("", LineType.BLANK, 0, 60)))
            }
            val lines = classify(p.content)
            var i = 0
            while (i < lines.size) {
                val l = lines[i]
                when (l.type) {
                    LineType.BLANK -> { out.add(listOf(PrintLine("", LineType.BLANK, 0, 60))); i++ }
                    LineType.SECTION, LineType.NOTE -> i++
                    LineType.CHARACTER -> {
                        // Khối thoại: tên + chỉ dẫn + lời thoại, giữ liền nhau
                        val b = ArrayList<PrintLine>()
                        var j = i
                        while (j < lines.size && lines[j].type in setOf(LineType.CHARACTER, LineType.PARENTHETICAL, LineType.DIALOGUE)) {
                            val lj = lines[j]
                            val (ind, w, al) = geometry(lj.type)
                            val txt = if (lj.type == LineType.CHARACTER) lj.text.trim().removePrefix("@").removeSuffix("^").trim().uppercase() else lj.text.trim()
                            wrap(txt, w).forEach { b.add(PrintLine(it, lj.type, ind, w, al)) }
                            j++
                        }
                        out.add(b); i = j
                    }
                    else -> {
                        val (ind, w, al) = geometry(l.type)
                        var txt = l.text.trim()
                        if (l.type == LineType.SCENE) txt = txt.removePrefix(".").trim().uppercase()
                        if (l.type == LineType.TRANSITION) txt = txt.removePrefix(">").trim().uppercase()
                        out.add(wrap(txt, w).map { PrintLine(it, l.type, ind, w, al, bold = l.type == LineType.SCENE) })
                        i++
                    }
                }
            }
            out.add(listOf(PrintLine("", LineType.BLANK, 0, 60)))
        }
        return out
    }

    /**
     * Chia trang: tối đa [LINES_PER_PAGE] dòng mỗi trang; không để tiêu đề cảnh nằm cuối trang;
     * khối thoại dài bị tách thì thêm "(CÒN NỮA)" / "TÊN (TIẾP)".
     */
    fun paginate(parts: List<ExportPart>, showChapterTitles: Boolean = true): List<List<PrintLine>> {
        val pages = ArrayList<List<PrintLine>>()
        var page = ArrayList<PrintLine>()
        fun newPage() {
            while (page.isNotEmpty() && page.last().type == LineType.BLANK) page.removeAt(page.lastIndex)
            if (page.isNotEmpty()) pages.add(page)
            page = ArrayList()
        }
        val bl = blocks(parts, showChapterTitles)
        var k = 0
        while (k < bl.size) {
            val b = bl[k]
            if (page.isEmpty() && b.all { it.type == LineType.BLANK }) { k++; continue }
            val room = LINES_PER_PAGE - page.size
            val isScene = b.firstOrNull()?.type == LineType.SCENE
            if (b.size <= room && !(isScene && room <= 3)) {
                page.addAll(b); k++; continue
            }
            val isDialogue = b.firstOrNull()?.type == LineType.CHARACTER
            if (isDialogue && room >= 4 && b.size > room) {
                // Tách khối thoại: phần đầu + (CÒN NỮA), trang sau: TÊN (TIẾP)
                val head = b.subList(0, room - 1)
                page.addAll(head)
                page.add(PrintLine("(CÒN NỮA)", LineType.PARENTHETICAL, 22, 38))
                newPage()
                val name = b.first().text
                page.add(PrintLine("$name (TIẾP)", LineType.CHARACTER, 22, 38))
                for (pl in b.subList(room - 1, b.size)) {
                    if (page.size >= LINES_PER_PAGE) newPage()
                    page.add(pl)
                }
                k++
                continue
            }
            if (!isDialogue && !isScene && b.size > LINES_PER_PAGE / 2 && room >= 3) {
                // Đoạn hành động rất dài: chia theo dòng
                for (pl in b) {
                    if (page.size >= LINES_PER_PAGE) newPage()
                    page.add(pl)
                }
                k++
                continue
            }
            if (page.isEmpty()) {
                for (pl in b) {
                    if (page.size >= LINES_PER_PAGE) newPage()
                    page.add(pl)
                }
                k++
                continue
            }
            newPage()
        }
        newPage()
        return pages
    }
}
