package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.entities.CharacterProfile
import com.example.ui.state.CoverDesign
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

// =====================================================================
// HÌNH ĐẠI DIỆN NHÂN VẬT (45 hình, giống Chấp Bút 1.7)
// =====================================================================

data class AvatarInfo(val id: String, val res: Int, val gender: String, val elder: Boolean)

object Avatars {
    val ALL: List<AvatarInfo> = listOf(
        AvatarInfo("b01", R.drawable.av_b01, "F", false),
        AvatarInfo("b02", R.drawable.av_b02, "F", false),
        AvatarInfo("b03", R.drawable.av_b03, "F", false),
        AvatarInfo("b04", R.drawable.av_b04, "F", false),
        AvatarInfo("b05", R.drawable.av_b05, "F", false),
        AvatarInfo("b06", R.drawable.av_b06, "F", false),
        AvatarInfo("b07", R.drawable.av_b07, "F", false),
        AvatarInfo("b08", R.drawable.av_b08, "F", true),
        AvatarInfo("b09", R.drawable.av_b09, "M", false),
        AvatarInfo("b10", R.drawable.av_b10, "M", false),
        AvatarInfo("b11", R.drawable.av_b11, "M", false),
        AvatarInfo("b12", R.drawable.av_b12, "M", false),
        AvatarInfo("b13", R.drawable.av_b13, "M", true),
        AvatarInfo("b14", R.drawable.av_b14, "M", false),
        AvatarInfo("b15", R.drawable.av_b15, "F", false),
        AvatarInfo("b16", R.drawable.av_b16, "F", false),
        AvatarInfo("b17", R.drawable.av_b17, "M", false),
        AvatarInfo("b18", R.drawable.av_b18, "M", false),
        AvatarInfo("b19", R.drawable.av_b19, "M", false),
        AvatarInfo("b20", R.drawable.av_b20, "M", false),
        AvatarInfo("b21", R.drawable.av_b21, "M", false),
        AvatarInfo("b22", R.drawable.av_b22, "M", false),
        AvatarInfo("b23", R.drawable.av_b23, "M", false),
        AvatarInfo("b24", R.drawable.av_b24, "M", false),
        AvatarInfo("b25", R.drawable.av_b25, "F", true),
        AvatarInfo("b26", R.drawable.av_b26, "F", false),
        AvatarInfo("b27", R.drawable.av_b27, "F", false),
        AvatarInfo("b28", R.drawable.av_b28, "F", false),
        AvatarInfo("b29", R.drawable.av_b29, "F", false),
        AvatarInfo("b30", R.drawable.av_b30, "F", false),
        AvatarInfo("b31", R.drawable.av_b31, "M", false),
        AvatarInfo("b32", R.drawable.av_b32, "F", false),
        AvatarInfo("b33", R.drawable.av_b33, "M", false),
        AvatarInfo("b34", R.drawable.av_b34, "M", false),
        AvatarInfo("b35", R.drawable.av_b35, "M", false),
        AvatarInfo("b36", R.drawable.av_b36, "M", false),
        AvatarInfo("b37", R.drawable.av_b37, "M", false),
        AvatarInfo("b38", R.drawable.av_b38, "F", false),
        AvatarInfo("b39", R.drawable.av_b39, "M", false),
        AvatarInfo("b40", R.drawable.av_b40, "M", false),
        AvatarInfo("b41", R.drawable.av_b41, "M", false),
        AvatarInfo("b42", R.drawable.av_b42, "M", false),
        AvatarInfo("b43", R.drawable.av_b43, "M", true),
        AvatarInfo("b44", R.drawable.av_b44, "M", true),
        AvatarInfo("b45", R.drawable.av_b45, "M", false)
    )
    private val byId = ALL.associateBy { it.id }

    fun find(id: String): AvatarInfo? = byId[id]

    /** Hình của nhân vật: hình đã chọn, nếu chưa chọn thì tự gán ổn định theo tên và giới tính. */
    fun of(c: CharacterProfile): AvatarInfo {
        find(c.avatarId)?.let { return it }
        val pool = ALL.filter { !it.elder && (c.gender.isEmpty() || it.gender == c.gender) }.ifEmpty { ALL }
        return pool[abs(c.name.hashCode() % pool.size)]
    }
}

@Composable
fun CharacterAvatar(character: CharacterProfile, size: androidx.compose.ui.unit.Dp, ring: Color = MaterialTheme.colorScheme.primary) {
    val info = Avatars.of(character)
    Image(
        painter = painterResource(info.res),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .border(2.dp, ring.copy(alpha = 0.6f), CircleShape)
            .background(Color(0xFFF3EDE0))
    )
}

/** Lưới chọn hình đại diện, lọc Tất cả / Nam / Nữ. */
@Composable
fun AvatarPicker(selectedId: String, gender: String, onSelect: (String) -> Unit) {
    var filter by remember { mutableStateOf(if (gender == "M" || gender == "F") gender else "") }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("" to "Tất cả", "M" to "Nam", "F" to "Nữ").forEach { (k, label) ->
                FilterChip(selected = filter == k, onClick = { filter = k }, label = { Text(label, fontSize = 12.sp) })
            }
        }
        val list = Avatars.ALL.filter { filter.isEmpty() || it.gender == filter }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            list.forEach { a ->
                val sel = a.id == selectedId
                Image(
                    painter = painterResource(a.res),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        .clickable { onSelect(a.id) }
                )
            }
        }
    }
}

// =====================================================================
// BÌA SÁCH TỰ TẠO: viền + nền giấy (vẽ / sinh bằng mã, không cần xin phép)
// =====================================================================

data class CoverAsset(val key: String, val name: String, val res: Int, val ink: Long)

object CoverAssets {
    val FRAMES: List<CoverAsset> = listOf(
        CoverAsset("la-xanh", "Lá xanh", R.drawable.cover_frame_la_xanh, 0xFF2F5A3C),
        CoverAsset("co-dien", "Cổ điển lam", R.drawable.cover_frame_co_dien, 0xFF1F3A6B),
        CoverAsset("toi-gian", "Tối giản", R.drawable.cover_frame_toi_gian, 0xFF222222),
        CoverAsset("lua-do", "Lửa đỏ", R.drawable.cover_frame_lua_do, 0xFF9C2A1C),
        CoverAsset("tim-o-vuong", "Tím ô vuông", R.drawable.cover_frame_tim_o_vuong, 0xFF4B2A6B)
    )
    val PAPERS: List<CoverAsset> = listOf(
        CoverAsset("trang", "Giấy trắng", R.drawable.cover_paper_trang, 0xFF2A2A2A),
        CoverAsset("nga", "Giấy ngà", R.drawable.cover_paper_nga, 0xFF3B2A1A),
        CoverAsset("kraft", "Giấy kraft", R.drawable.cover_paper_kraft, 0xFF2E1D0F),
        CoverAsset("xanh", "Xanh ngọc nhạt", R.drawable.cover_paper_xanh, 0xFF23453A),
        CoverAsset("hong", "Hồng phấn", R.drawable.cover_paper_hong, 0xFF5A2635)
    )
    val PRESET_COLORS = listOf("#8B1E1E", "#1B5E20", "#0D47A1", "#4A148C", "#3E2723", "#E65100")
    val INKS = listOf("" to "Tự động", "#222222" to "Đen", "#3B2A1A" to "Nâu", "#1F3A6B" to "Lam", "#FFFFFF" to "Trắng", "#C9A227" to "Vàng kim")

    fun frame(key: String): CoverAsset? = FRAMES.firstOrNull { it.key == key }
    fun paper(key: String): CoverAsset = PAPERS.firstOrNull { it.key == key } ?: PAPERS[1]

    fun inkOf(d: CoverDesign): Color {
        parseHex(d.ink)?.let { return it }
        val fromFrame = if (d.borderImage.isEmpty()) frame(d.border)?.ink else null
        return Color(fromFrame ?: if (d.paperImage.isNotEmpty()) 0xFF2A2A2A else paper(d.paper).ink)
    }

    fun parseHex(hex: String): Color? = try {
        if (hex.isBlank()) null else Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) { null }

    fun uploadDir(context: Context, kind: String): File =
        File(context.filesDir, "cover_uploads/$kind").apply { mkdirs() }

    fun uploads(context: Context, kind: String): List<File> =
        uploadDir(context, kind).listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()

    /**
     * Chép ảnh người dùng chọn vào bộ nhớ app, thu về 600x900.
     * kind = "frames": kéo vừa khổ, giữ nền trong suốt (PNG). kind = "papers": cắt phủ kín khổ (JPEG).
     * Trả về (đường dẫn tệp, ảnh có tối không) hoặc null nếu lỗi.
     */
    fun importImage(context: Context, uri: Uri, kind: String): Pair<String, Boolean>? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 600 && bounds.outHeight / (sample * 2) >= 900) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val src = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (src == null) null else {
            val out = Bitmap.createBitmap(600, 900, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val dst = Rect(0, 0, 600, 900)
            val srcRect = if (kind == "frames") Rect(0, 0, src.width, src.height) else {
                // Cắt giữa theo tỉ lệ 2:3
                val r = 600f / 900f
                if (src.width.toFloat() / src.height > r) {
                    val w = (src.height * r).toInt(); val x = (src.width - w) / 2
                    Rect(x, 0, x + w, src.height)
                } else {
                    val h = (src.width / r).toInt(); val y = (src.height - h) / 2
                    Rect(0, y, src.width, y + h)
                }
            }
            canvas.drawBitmap(src, srcRect, dst, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
            src.recycle()
            // Độ sáng vùng giữa (chỗ in chữ) để chọn màu chữ
            var lum = 0.0; var cnt = 0
            for (y in 250 until 650 step 16) for (x in 150 until 450 step 16) {
                val p = out.getPixel(x, y)
                lum += 0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255)
                cnt++
            }
            val dark = kind == "papers" && cnt > 0 && lum / cnt < 120
            val ext = if (kind == "frames") "png" else "jpg"
            val file = File(uploadDir(context, kind), "u_${System.currentTimeMillis()}.$ext")
            FileOutputStream(file).use {
                if (kind == "frames") out.compress(Bitmap.CompressFormat.PNG, 100, it)
                else out.compress(Bitmap.CompressFormat.JPEG, 88, it)
            }
            out.recycle()
            file.absolutePath to dark
        }
    } catch (e: Exception) {
        android.util.Log.e("CoverAssets", "importImage failed", e)
        null
    }
}

/** Lớp ảnh: tệp người dùng tải lên (nếu còn) hoặc ảnh có sẵn. */
@Composable
private fun CoverLayer(path: String, fallbackRes: Int?, modifier: Modifier = Modifier.fillMaxSize()) {
    val file = remember(path) { if (path.isNotEmpty()) File(path).takeIf { it.exists() } else null }
    if (file != null) {
        AsyncImage(model = file, contentDescription = null, contentScale = ContentScale.FillBounds, modifier = modifier)
    } else if (fallbackRes != null) {
        Image(painter = painterResource(fallbackRes), contentDescription = null, contentScale = ContentScale.FillBounds, modifier = modifier)
    }
}

/** Bìa sách (tỉ lệ 2:3). Tên truyện và tác giả tự in lên bìa. */
@Composable
fun BookCover(
    title: String,
    author: String,
    design: CoverDesign,
    modifier: Modifier = Modifier,
    genre: String = ""
) {
    BoxWithConstraints(
        modifier = modifier
            .aspectRatio(2f / 3f)
            .clip(RoundedCornerShape(6.dp))
    ) {
        val w = maxWidth.value
        if (design.style == "COLOR") {
            val c = CoverAssets.parseHex(design.colorHex) ?: Color(0xFF8B1E1E)
            Box(Modifier.fillMaxSize().background(c).padding((w * 0.1f).dp), contentAlignment = Alignment.Center) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = (w * 0.12f).coerceIn(8f, 30f).sp,
                    lineHeight = (w * 0.15f).coerceIn(10f, 36f).sp,
                    textAlign = TextAlign.Center,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
            }
            return@BoxWithConstraints
        }
        CoverLayer(design.paperImage, CoverAssets.paper(design.paper).res)
        val frameRes = CoverAssets.frame(design.border)?.res
        if (design.borderImage.isNotEmpty() || frameRes != null) {
            CoverLayer(design.borderImage, if (design.borderImage.isNotEmpty()) null else frameRes)
        }
        val ink = CoverAssets.inkOf(design)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = (w * 0.16f).dp, vertical = (w * 0.2f).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(Modifier.height(1.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = title.uppercase(),
                    color = ink,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = (w * 0.105f).coerceIn(7f, 30f).sp,
                    lineHeight = (w * 0.135f).coerceIn(9f, 38f).sp,
                    textAlign = TextAlign.Center,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
                if (genre.isNotBlank() && w >= 90f) {
                    Text(
                        text = "— $genre —",
                        color = ink.copy(alpha = 0.85f),
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        fontSize = (w * 0.055f).coerceIn(7f, 16f).sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            Text(
                text = author,
                color = ink,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.SemiBold,
                fontSize = (w * 0.065f).coerceIn(6f, 18f).sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun PickTile(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    onDelete: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(58.dp)) {
        Box(
            modifier = Modifier
                .width(54.dp)
                .height(81.dp)
                .clip(RoundedCornerShape(6.dp))
                .border(
                    BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                    RoundedCornerShape(6.dp)
                )
                .clickable(onClick = onClick),
            content = {
                content()
                if (onDelete != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(2.dp)
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .clickable(onClick = onDelete),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Xóa ảnh này", tint = Color.White, modifier = Modifier.size(12.dp))
                    }
                }
            }
        )
        Text(label, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 12.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

/**
 * Bộ chọn bìa: Tự tạo bìa (viền + nền giấy, tải ảnh riêng) hoặc Màu trơn.
 * Ảnh tải lên được lưu thành thư viện trong máy, dùng lại cho mọi truyện.
 */
@Composable
fun CoverPicker(
    title: String,
    author: String,
    design: CoverDesign,
    onChange: (CoverDesign) -> Unit
) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val frameUploads = remember(refresh) { CoverAssets.uploads(context, "frames") }
    val paperUploads = remember(refresh) { CoverAssets.uploads(context, "papers") }
    val current by rememberUpdatedState(design)

    val pickFrame = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val r = CoverAssets.importImage(context, uri, "frames")
            if (r == null) android.widget.Toast.makeText(context, "Không đọc được ảnh", android.widget.Toast.LENGTH_SHORT).show()
            else { onChange(current.copy(borderImage = r.first)); refresh++ }
        }
    }
    val pickPaper = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val r = CoverAssets.importImage(context, uri, "papers")
            if (r == null) android.widget.Toast.makeText(context, "Không đọc được ảnh", android.widget.Toast.LENGTH_SHORT).show()
            else { onChange(current.copy(paperImage = r.first, ink = if (r.second) "#FFFFFF" else current.ink)); refresh++ }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Bìa sách:", style = MaterialTheme.typography.labelMedium)
        Row(verticalAlignment = Alignment.Top) {
            BookCover(title = title.ifBlank { "Tên kịch bản" }, author = author.ifBlank { "Tác giả" }, design = design, modifier = Modifier.width(84.dp))
            Spacer(Modifier.width(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(selected = design.style == "MAKER", onClick = { onChange(design.copy(style = "MAKER")) }, label = { Text("Tự tạo bìa", fontSize = 12.sp) })
                FilterChip(selected = design.style == "COLOR", onClick = { onChange(design.copy(style = "COLOR")) }, label = { Text("Màu trơn", fontSize = 12.sp) })
            }
        }

        if (design.style == "COLOR") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CoverAssets.PRESET_COLORS.forEach { hex ->
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(CoverAssets.parseHex(hex) ?: Color.Gray)
                            .clickable { onChange(design.copy(colorHex = hex)) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (design.colorHex.equals(hex, ignoreCase = true)) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
            return@Column
        }

        val paperRes = CoverAssets.paper(design.paper).res
        Text("Viền bìa", style = MaterialTheme.typography.labelSmall)
        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PickTile("Không viền", design.border == "none" && design.borderImage.isEmpty(), { onChange(design.copy(border = "none", borderImage = "")) }) {
                CoverLayer(design.paperImage, paperRes)
            }
            CoverAssets.FRAMES.forEach { f ->
                PickTile(f.name, design.border == f.key && design.borderImage.isEmpty(), { onChange(design.copy(border = f.key, borderImage = "")) }) {
                    CoverLayer(design.paperImage, paperRes)
                    Image(painterResource(f.res), null, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
                }
            }
            frameUploads.forEach { file ->
                PickTile("Ảnh tải lên", design.borderImage == file.absolutePath, { onChange(design.copy(borderImage = file.absolutePath)) },
                    onDelete = {
                        file.delete(); refresh++
                        if (design.borderImage == file.absolutePath) onChange(design.copy(borderImage = ""))
                    }) {
                    CoverLayer(design.paperImage, paperRes)
                    CoverLayer(file.absolutePath, null)
                }
            }
            PickTile("Tải ảnh viền…", false, { pickFrame.launch("image/*") }) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.align(Alignment.Center))
            }
        }
        Text("Nên dùng ảnh PNG nền trong suốt, tỉ lệ 2:3.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Text("Nền giấy", style = MaterialTheme.typography.labelSmall)
        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CoverAssets.PAPERS.forEach { p ->
                PickTile(p.name, design.paper == p.key && design.paperImage.isEmpty(), { onChange(design.copy(paper = p.key, paperImage = "")) }) {
                    Image(painterResource(p.res), null, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
                }
            }
            paperUploads.forEach { file ->
                PickTile("Ảnh tải lên", design.paperImage == file.absolutePath, { onChange(design.copy(paperImage = file.absolutePath)) },
                    onDelete = {
                        file.delete(); refresh++
                        if (design.paperImage == file.absolutePath) onChange(design.copy(paperImage = ""))
                    }) {
                    CoverLayer(file.absolutePath, null)
                }
            }
            PickTile("Tải nền giấy…", false, { pickPaper.launch("image/*") }) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.align(Alignment.Center))
            }
        }

        Text("Màu chữ trên bìa", style = MaterialTheme.typography.labelSmall)
        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CoverAssets.INKS.forEach { (hex, label) ->
                val dot: (@Composable () -> Unit)? = if (hex.isEmpty()) null else {
                    @Composable {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(CoverAssets.parseHex(hex) ?: Color.Gray).border(1.dp, Color.Gray, CircleShape))
                    }
                }
                FilterChip(
                    selected = design.ink.equals(hex, ignoreCase = true),
                    onClick = { onChange(design.copy(ink = hex)) },
                    label = { Text(label, fontSize = 11.sp) },
                    leadingIcon = dot
                )
            }
        }
    }
}
