package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.data.local.AppDatabase
import com.example.data.repository.BackupRepository
import com.example.data.repository.NovelRepository
import com.example.ui.screens.BackupRestoreScreen
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.NovelDetailScreen
import com.example.ui.screens.NovelListScreen
import com.example.ui.screens.TrashBinDialog
import com.example.ui.state.Screen
import com.example.ui.state.WritingSettingsStore
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.BackupViewModel
import com.example.viewmodel.EditorViewModel
import com.example.viewmodel.NovelViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ghi lại lỗi nếu app bị văng, để lần mở sau hiện ra cho người dùng gửi đi
        com.example.util.CrashLogger.install(applicationContext)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(this)
        val novelRepository = NovelRepository(
            novelDao = database.novelDao(),
            volumeDao = database.volumeDao(),
            chapterDao = database.chapterDao(),
            snapshotDao = database.snapshotDao(),
            characterWorldDao = database.characterWorldDao(),
            backupDao = database.backupDao()
        )
        val backupRepository = BackupRepository(
            context = applicationContext,
            novelRepository = novelRepository,
            backupDao = database.backupDao(),
            database = database
        )
        val settingsStore = WritingSettingsStore(applicationContext)

        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NovelWriterApp(
                        novelRepository = novelRepository,
                        backupRepository = backupRepository,
                        settingsStore = settingsStore
                    )
                }
            }
        }
    }
}

/** Lưu màn hình hiện tại qua xoay màn hình / đổi chế độ tối (trước đây luôn bị đá về danh sách truyện). */
private val ScreenSaver = Saver<Screen, LongArray>(
    save = { screen ->
        when (screen) {
            is Screen.NovelList -> longArrayOf(0)
            is Screen.NovelDetail -> longArrayOf(1, screen.novelId)
            is Screen.Editor -> longArrayOf(2, screen.novelId, screen.chapterId)
            is Screen.BackupRestore -> longArrayOf(3)
        }
    },
    restore = { a ->
        when (a.getOrNull(0)) {
            1L -> Screen.NovelDetail(a[1])
            2L -> Screen.Editor(a[1], a[2])
            3L -> Screen.BackupRestore
            else -> Screen.NovelList
        }
    }
)

@Composable
fun NovelWriterApp(
    novelRepository: NovelRepository,
    backupRepository: BackupRepository,
    settingsStore: WritingSettingsStore
) {
    var currentScreen by rememberSaveable(stateSaver = ScreenSaver) { mutableStateOf<Screen>(Screen.NovelList) }
    var showTrashDialog by rememberSaveable { mutableStateOf(false) }

    val context = androidx.compose.ui.platform.LocalContext.current
    // Dùng viewModel() thật thay vì remember{}: ViewModel sống qua xoay màn hình và
    // viewModelScope được hủy đúng lúc (trước đây không bao giờ được hủy -> rò rỉ).
    val novelViewModel: NovelViewModel = viewModel { NovelViewModel(novelRepository) }
    val backupViewModel: BackupViewModel = viewModel {
        BackupViewModel(backupRepository, com.example.data.remote.GoogleDriveManager(context.applicationContext))
    }

    // Nếu lần trước app bị văng: hiện nội dung lỗi để người dùng sao chép gửi đi
    var lastCrash by remember { mutableStateOf(com.example.util.CrashLogger.readAndClear(context)) }
    lastCrash?.let { crashText ->
        val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { lastCrash = null },
            title = { androidx.compose.material3.Text("Lần trước app bị lỗi") },
            text = {
                androidx.compose.foundation.layout.Column {
                    androidx.compose.material3.Text(
                        "Hãy bấm \"Sao chép lỗi\" rồi gửi nội dung cho người hỗ trợ. " +
                            "Chức năng Giãn đoạn văn đã được tạm tắt.",
                        fontSize = 13.sp
                    )
                    androidx.compose.foundation.text.selection.SelectionContainer(
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .heightIn(max = 300.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        androidx.compose.material3.Text(
                            crashText,
                            fontSize = 11.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    clipboard.setText(androidx.compose.ui.text.AnnotatedString(crashText))
                    android.widget.Toast.makeText(context, "Đã sao chép nội dung lỗi", android.widget.Toast.LENGTH_SHORT).show()
                }) { androidx.compose.material3.Text("Sao chép lỗi") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { lastCrash = null }) {
                    androidx.compose.material3.Text("Đóng")
                }
            }
        )
    }

    // Nút Back hệ thống: trước đây ở màn Chi tiết truyện / Sao lưu bấm Back là thoát hẳn app.
    BackHandler(enabled = currentScreen is Screen.NovelDetail || currentScreen is Screen.BackupRestore) {
        currentScreen = Screen.NovelList
    }

    Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
        when (screen) {
            is Screen.NovelList -> {
                NovelListScreen(
                    novelViewModel = novelViewModel,
                    onSelectNovel = { novelId ->
                        currentScreen = Screen.NovelDetail(novelId)
                    },
                    onOpenBackup = {
                        currentScreen = Screen.BackupRestore
                    },
                    onOpenTrash = {
                        showTrashDialog = true
                    }
                )
            }
            is Screen.NovelDetail -> {
                NovelDetailScreen(
                    novelId = screen.novelId,
                    novelViewModel = novelViewModel,
                    backupViewModel = backupViewModel,
                    onBack = {
                        currentScreen = Screen.NovelList
                    },
                    onOpenChapter = { chapterId ->
                        currentScreen = Screen.Editor(screen.novelId, chapterId)
                    }
                )
            }
            is Screen.Editor -> {
                val editorViewModel: EditorViewModel = viewModel(key = "editor_${screen.chapterId}") {
                    EditorViewModel(
                        novelRepository = novelRepository,
                        backupRepository = backupRepository,
                        chapterId = screen.chapterId,
                        settingsStore = settingsStore,
                        appContext = context.applicationContext
                    )
                }
                EditorScreen(
                    editorViewModel = editorViewModel,
                    onBack = {
                        editorViewModel.stopReading()
                        currentScreen = Screen.NovelDetail(screen.novelId)
                    }
                )
            }
            is Screen.BackupRestore -> {
                BackupRestoreScreen(
                    backupViewModel = backupViewModel,
                    onBack = {
                        currentScreen = Screen.NovelList
                    }
                )
            }
        }
    }

    if (showTrashDialog) {
        TrashBinDialog(
            novelViewModel = novelViewModel,
            onDismiss = { showTrashDialog = false }
        )
    }
}
