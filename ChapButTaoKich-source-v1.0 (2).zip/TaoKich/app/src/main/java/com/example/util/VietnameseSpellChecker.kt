package com.example.util

data class SpellingIssue(
    val originalWord: String,
    val suggestedWord: String,
    val startIndex: Int,
    val endIndex: Int,
    val reason: String
)

object VietnameseSpellChecker {

    private val commonTypos = mapOf(
        "dc" to "được",
        "đc" to "được",
        "ko" to "không",
        "k" to "không",
        "khong" to "không",
        "hok" to "không",
        "wa" to "quá",
        "zui" to "vui",
        "thik" to "thích",
        "bit" to "biết",
        "rùi" to "rồi",
        "hẻm" to "hẻm",
        "mềnh" to "mình",
        "tui" to "tôi",
        "ngta" to "người ta",
        "nx" to "nữa",
        "hnay" to "hôm nay",
        "bjo" to "bây giờ",
        "hqua" to "hôm qua",
        "bt" to "biết",
        "trc" to "trước",
        "sauh" to "sau",
        "chăngr" to "chẳng",
        "ngừoi" to "người",
        "ngừơi" to "người",
        "ngươif" to "người",
        "chuaw" to "chưa",
        "dduoc" to "được",
        "dduowcj" to "được",
        "khoong" to "không",
        "thoonng" to "thông",
        "tieengs" to "tiếng",
        "tieeur" to "tiểu",
        "thuyeets" to "thuyết",
        "gioongf" to "giống",
        "gioosng" to "giống",
        "xuyt" to "suýt",
        "xắp" to "sắp",
        "xơ xuất" to "sơ suất",
        "xơ sót" to "sơ sót",
        "chân chọng" to "trân trọng",
        "trưng cầu" to "trưng cầu",
        "giành giật" to "giành giật",
        "dành dụm" to "dành dụm",
        "giấu diếm" to "giấu giếm",
        "bổ xung" to "bổ sung",
        "sáng lạng" to "xán lạn",
        "vô hình chung" to "vô hình trung",
        "chuẩn xuất" to "chuẩn xác"
    )

    // Các mục ánh xạ sang chính nó (vd "hẻm" -> "hẻm") bị loại bỏ: trước đây chúng bị báo lỗi
    // dù từ hoàn toàn đúng.
    private val singleWordTypos = commonTypos.filter { (k, v) -> !k.contains(' ') && k != v }
    private val phraseTypos = commonTypos.filter { (k, v) -> k.contains(' ') && k != v }

    private val telexDoubleKeys = listOf("aa", "ee", "oo", "dd")
    private val asciiWord = Regex("^[a-z]+$")

    fun check(text: String): List<SpellingIssue> {
        val issues = mutableListOf<SpellingIssue>()
        if (text.isBlank()) return issues
        val lowerText = text.lowercase()

        // 1) Cụm từ nhiều chữ (vd "bổ xung", "sáng lạng"). Trước đây regex chỉ tách từng chữ
        //    nên các cụm này KHÔNG BAO GIỜ được phát hiện.
        val coveredRanges = mutableListOf<IntRange>()
        // lowercase() có thể đổi độ dài chuỗi với vài ký tự đặc biệt -> khi đó bỏ qua bước này để không lệch vị trí
        if (lowerText.length == text.length) for ((phrase, fix) in phraseTypos) {
            val regex = Regex("(?<![\\p{L}\\p{M}])" + Regex.escape(phrase) + "(?![\\p{L}\\p{M}])")
            for (m in regex.findAll(lowerText)) {
                val original = text.substring(m.range.first, m.range.last + 1)
                issues.add(
                    SpellingIssue(
                        originalWord = original,
                        suggestedWord = matchCase(original, fix),
                        startIndex = m.range.first,
                        endIndex = m.range.last + 1,
                        reason = "Cụm từ dùng sai thông dụng"
                    )
                )
                coveredRanges.add(m.range)
            }
        }

        // 2) Từng chữ đơn
        val wordRegex = Regex("""[\p{L}\p{M}]+""")
        for (match in wordRegex.findAll(text)) {
            if (coveredRanges.any { match.range.first in it }) continue
            val word = match.value
            val lower = word.lowercase()
            val start = match.range.first
            val end = match.range.last + 1

            val dictFix = singleWordTypos[lower]
            if (dictFix != null) {
                issues.add(
                    SpellingIssue(
                        originalWord = word,
                        suggestedWord = matchCase(word, dictFix),
                        startIndex = start,
                        endIndex = end,
                        reason = "Từ viết tắt hoặc sai chính tả thông dụng"
                    )
                )
                continue
            }

            // 3) Telex chưa được bộ gõ chuyển đổi (vd "khoong", "dduowcj").
            //    Chỉ xét từ toàn chữ Latin không dấu, để không báo nhầm tên riêng/từ có dấu.
            if (lower.length > 2 && asciiWord.matches(lower) && telexDoubleKeys.any { lower.contains(it) }) {
                val simplified = lower
                    .replace("aa", "â")
                    .replace("ee", "ê")
                    .replace("oo", "ô")
                    .replace("dd", "đ")
                    .replace("uow", "ươ")
                    .replace("ow", "ơ")
                    .replace("uw", "ư")
                    .replace("aw", "ă")
                if (simplified != lower) {
                    issues.add(
                        SpellingIssue(
                            originalWord = word,
                            suggestedWord = matchCase(word, simplified),
                            startIndex = start,
                            endIndex = end,
                            reason = "Có thể là lỗi gõ Telex chưa chuyển dấu"
                        )
                    )
                }
            }
        }

        return issues.sortedBy { it.startIndex }
    }

    private fun matchCase(original: String, target: String): String {
        if (original.isEmpty()) return target
        return if (original[0].isUpperCase()) {
            target.replaceFirstChar { it.uppercase() }
        } else {
            target
        }
    }
}
