package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "novels")
data class Novel(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val author: String = "Tác giả",
    val synopsis: String = "",
    val genre: String = "Chính kịch",
    val wordCount: Int = 0,
    val targetWordCount: Int = 100000,
    val coverColorHex: String = "#795548",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false,
    val isDeleted: Boolean = false,
    // ---- Bản 1.5 (DB version 3) ----
    /** Trạng thái truyện: WRITING (đang sáng tác), PAUSED (tạm ngưng), COMPLETED (hoàn thành). */
    val status: String = "WRITING",
    /** Ghim lên đầu thư viện. pinnedAt dùng để xếp các truyện đã ghim theo lúc ghim. */
    val isPinned: Boolean = false,
    val pinnedAt: Long = 0,
    /** Đại cương toàn truyện (cốt truyện chính, tuyến nhân vật, các mốc lớn, kết thúc...). */
    val outline: String = "",
    /** Kiểu bìa: MAKER (tự tạo: viền + nền giấy) hoặc COLOR (màu trơn cũ = coverColorHex). */
    val coverStyle: String = "MAKER",
    /** Mã viền có sẵn (xem CoverAssets.FRAMES), "none" = không viền. */
    val coverBorder: String = "co-dien",
    /** Mã nền giấy có sẵn (xem CoverAssets.PAPERS). */
    val coverPaper: String = "nga",
    /** Đường dẫn ảnh viền / nền giấy người dùng tải lên (rỗng = dùng mẫu có sẵn). */
    val coverBorderImage: String = "",
    val coverPaperImage: String = "",
    /** Màu chữ trên bìa dạng #RRGGBB, rỗng = tự chọn theo viền / giấy. */
    val coverInk: String = "",
    // ---- Chấp Bút Tạo Kịch (DB version 4) ----
    /** Loại dự án: FILM (phim điện ảnh / phim ngắn: Hồi → Phân đoạn) hoặc TV (phim truyền hình: Mùa → Tập). */
    val projectKind: String = "FILM"
)

@Entity(
    tableName = "volumes",
    foreignKeys = [
        ForeignKey(
            entity = Novel::class,
            parentColumns = ["id"],
            childColumns = ["novelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("novelId")]
)
data class Volume(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val novelId: Long,
    val title: String,
    val orderIndex: Int = 1,
    val description: String = "",
    val isDeleted: Boolean = false
)

@Entity(
    tableName = "chapters",
    foreignKeys = [
        ForeignKey(
            entity = Novel::class,
            parentColumns = ["id"],
            childColumns = ["novelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("novelId"), Index("volumeId")]
)
data class Chapter(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val novelId: Long,
    val volumeId: Long? = null,
    val title: String,
    val content: String = "",
    val orderIndex: Int = 1,
    val wordCount: Int = 0,
    val status: String = "DRAFT", // DRAFT, COMPLETED, REVISING
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isDeleted: Boolean = false,
    // ---- Bản 1.5 (DB version 3) ----
    /** Dàn ý chương: sự kiện chính, xung đột, cao trào... */
    val outline: String = "",
    /** Ghi chú chương: việc cần sửa, ý tưởng... */
    val notes: String = ""
)

@Entity(
    tableName = "chapter_snapshots",
    foreignKeys = [
        ForeignKey(
            entity = Chapter::class,
            parentColumns = ["id"],
            childColumns = ["chapterId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("chapterId")]
)
data class ChapterSnapshot(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val chapterId: Long,
    val snapshotTitle: String = "Tự động sao lưu",
    val content: String,
    val wordCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "character_profiles",
    foreignKeys = [
        ForeignKey(
            entity = Novel::class,
            parentColumns = ["id"],
            childColumns = ["novelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("novelId")]
)
data class CharacterProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val novelId: Long,
    val name: String,
    val role: String = "PROTAGONIST", // PROTAGONIST, SUPPORTING, ANTAGONIST, OTHER
    val appearance: String = "",
    val personality: String = "",
    val background: String = "",
    val notes: String = "",
    val avatarEmoji: String = "👤",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    // ---- Bản 1.5 (DB version 3) ----
    /** Mã hình đại diện (b01..b45), rỗng = tự gán theo giới tính. */
    val avatarId: String = "",
    /** Giới tính: "M" nam, "F" nữ, "" chưa rõ. */
    val gender: String = "",
    /** Biệt danh / tên gọi khác, cách nhau bằng dấu phẩy (dùng khi tìm chỗ xuất hiện). */
    val aliases: String = ""
)

@Entity(
    tableName = "world_notes",
    foreignKeys = [
        ForeignKey(
            entity = Novel::class,
            parentColumns = ["id"],
            childColumns = ["novelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("novelId")]
)
data class WorldNote(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val novelId: Long,
    val title: String,
    // Bản 1.5: LOCATION (Địa danh/Thế giới), FACTION (Thế lực/Hệ phái), CLASS (Giai cấp/Địa vị),
    // MAGIC_POWER (Thể chất/Sức mạnh), TALENT (Thiên phú/Kĩ năng), ITEM (Vật phẩm/Công cụ), OTHER (Khác).
    // HISTORY cũ được chuyển sang OTHER kèm nhãn "Lịch sử" (xem WorldCategories).
    val category: String = "LOCATION",
    val content: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    // ---- Bản 1.5 (DB version 3) ----
    /** Nhãn tự do, cách nhau bằng dấu phẩy. */
    val tags: String = ""
)

@Entity(tableName = "backup_records")
data class BackupRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val backupName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val novelCount: Int = 0,
    val chapterCount: Int = 0,
    val filePath: String = "",
    val fileSizeKb: Long = 0
)
