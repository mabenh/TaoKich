package com.example.viewmodel

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.Chapter
import com.example.data.local.entities.ChapterSnapshot
import com.example.data.repository.BackupRepository
import com.example.data.repository.NovelRepository
import com.example.ui.state.WritingSettings
import com.example.ui.state.WritingSettingsStore
import com.example.util.ReadAloudController
import com.example.util.ReadState
import com.example.util.SpellingIssue
import com.example.util.VietnameseSpellChecker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class EditorViewModel(
    private val novelRepository: NovelRepository,
    private val backupRepository: BackupRepository,
    val chapterId: Long,
    private val settingsStore: WritingSettingsStore? = null,
    appContext: android.content.Context? = null
) : ViewModel() {

    // ---- Đọc văn bản bằng giọng nói (bản 1.5) ----
    private val readAloud: ReadAloudController? = appContext?.let {
        try { ReadAloudController(it) } catch (e: Exception) {
            android.util.Log.e("EditorViewModel", "TTS init failed", e); null
        }
    }
    val readState: StateFlow<ReadState> = readAloud?.state ?: MutableStateFlow(ReadState()).asStateFlow()

    /** Đọc từ vị trí con trỏ (nếu con trỏ ở cuối chương thì đọc từ đầu). */
    fun startReading() {
        val v = _textFieldValue.value
        val from = if (v.selection.min >= v.text.length) 0 else v.selection.min
        readAloud?.start(v.text, from)
    }
    fun pauseReading() { readAloud?.pause() }
    fun resumeReading() { readAloud?.resume() }
    fun stopReading() { readAloud?.stop() }
    fun nextSentence() { readAloud?.next() }
    fun previousSentence() { readAloud?.previous() }
    fun setReadingRate(rate: Float) { readAloud?.setRate(rate) }
    fun clearReadingMessage() { readAloud?.clearMessage() }

    override fun onCleared() {
        readAloud?.shutdown()
        super.onCleared()
    }

    private val _chapter = MutableStateFlow<Chapter?>(null)
    val chapter: StateFlow<Chapter?> = _chapter.asStateFlow()

    /** Loại dự án (FILM / TV) để hiển thị đúng tên gọi Phân đoạn / Tập. */
    private val _projectKind = MutableStateFlow("FILM")
    val projectKind: StateFlow<String> = _projectKind.asStateFlow()

    /** Tên nhân vật (thẻ nhân vật + tên đã có thoại) và địa điểm đã dùng trong cả kịch bản, để gợi ý khi gõ. */
    private val _knownCharacters = MutableStateFlow<List<String>>(emptyList())
    val knownCharacters: StateFlow<List<String>> = _knownCharacters.asStateFlow()
    private val _knownLocations = MutableStateFlow<List<String>>(emptyList())
    val knownLocations: StateFlow<List<String>> = _knownLocations.asStateFlow()

    /** Số cảnh của các phân đoạn trước (phim điện ảnh đánh số cảnh liên tục; truyền hình đánh lại từ 1 mỗi tập). */
    private val _sceneNumberOffset = MutableStateFlow(0)
    val sceneNumberOffset: StateFlow<Int> = _sceneNumberOffset.asStateFlow()

    private val _textFieldValue = MutableStateFlow(TextFieldValue(""))
    val textFieldValue: StateFlow<TextFieldValue> = _textFieldValue.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _saveStatus = MutableStateFlow("Đã đồng bộ")
    val saveStatus: StateFlow<String> = _saveStatus.asStateFlow()

    private val _settings = MutableStateFlow(settingsStore?.load() ?: WritingSettings())
    val settings: StateFlow<WritingSettings> = _settings.asStateFlow()

    // Undo / Redo stacks
    private val undoStack = mutableListOf<TextFieldValue>()
    private val redoStack = mutableListOf<TextFieldValue>()
    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()
    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    // Snapshots
    val snapshots: StateFlow<List<ChapterSnapshot>> = novelRepository.getSnapshots(chapterId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Spell check
    private val _spellingIssues = MutableStateFlow<List<SpellingIssue>>(emptyList())
    val spellingIssues: StateFlow<List<SpellingIssue>> = _spellingIssues.asStateFlow()

    private val _isCheckingSpelling = MutableStateFlow(false)
    val isCheckingSpelling: StateFlow<Boolean> = _isCheckingSpelling.asStateFlow()

    private var autoSaveJob: Job? = null
    private var lastAutoSnapshotWordCount = 0

    // Tuần tự hóa mọi thao tác ghi chương để tránh 2 lần lưu chồng nhau (ví dụ lưu nội dung
    // và đổi tiêu đề cùng lúc làm mất tiêu đề mới).
    private val saveMutex = Mutex()
    // Đánh dấu có thay đổi trong phiên này -> chỉ tạo bản sao lưu khi thoát nếu thật sự có sửa.
    private var hasEditsThisSession = false
    private var isLoaded = false

    init {
        loadChapter()
    }

    private fun loadChapter() {
        viewModelScope.launch {
            val loaded = try {
                novelRepository.getChapterById(chapterId)
            } catch (e: Exception) {
                android.util.Log.e("EditorViewModel", "Load chapter failed", e)
                _saveStatus.value = "Không tải được chương"
                null
            }
            if (loaded != null) {
                try {
                    novelRepository.getNovelById(loaded.novelId)?.let { _projectKind.value = it.projectKind }
                    val all = novelRepository.getChaptersDirect(loaded.novelId)
                    val cards = novelRepository.getCharactersDirect(loaded.novelId).map { it.name }
                    _knownCharacters.value = (cards + all.flatMap { com.example.util.Screenplay.characterNames(it.content) })
                        .map { it.trim() }.filter { it.isNotEmpty() }.distinctBy { it.uppercase() }
                    _knownLocations.value = all.flatMap { com.example.util.Screenplay.locationsIn(it.content) }.distinct()
                    if (_projectKind.value != "TV") {
                        _sceneNumberOffset.value = all.filter { it.orderIndex < loaded.orderIndex && it.id != loaded.id }
                            .sumOf { com.example.util.Screenplay.scenes(it.content).size }
                    }
                } catch (e: Exception) {
                    android.util.Log.e("EditorViewModel", "Load script context failed", e)
                }
                _chapter.value = loaded
                val initialText = loaded.content
                _textFieldValue.value = TextFieldValue(
                    text = initialText,
                    selection = TextRange(initialText.length)
                )
                undoStack.clear()
                redoStack.clear()
                undoStack.add(_textFieldValue.value)
                lastAutoSnapshotWordCount = calculateWordCount(initialText)
                isLoaded = true
            }
        }
    }

    fun onTextChanged(newValue: TextFieldValue) {
        val oldValue = _textFieldValue.value
        _textFieldValue.value = newValue

        // Push to undo stack if text changed significantly
        if (oldValue.text != newValue.text) {
            // Văn bản đổi thì vị trí câu đang đọc không còn đúng → dừng đọc
            if (readState.value.active) readAloud?.stop()
            if (undoStack.isEmpty() || undoStack.last().text != oldValue.text) {
                undoStack.add(oldValue)
                if (undoStack.size > 50) undoStack.removeAt(0)
            }
            redoStack.clear()
            _canUndo.value = undoStack.isNotEmpty()
            _canRedo.value = false

            hasEditsThisSession = true
            _saveStatus.value = "Đang gõ..."
            scheduleAutoSave()
        }
    }

    private fun scheduleAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(1200)
            saveInternal()
        }
    }

    fun saveImmediately() {
        autoSaveJob?.cancel()
        viewModelScope.launch { saveInternal() }
    }

    private suspend fun saveInternal() {
        // Chưa nạp xong chương thì không lưu (tránh ghi đè nội dung bằng chuỗi rỗng)
        if (!isLoaded) return
        saveMutex.withLock {
            val currentCh = _chapter.value ?: return
            val currentText = _textFieldValue.value.text
            if (currentText == currentCh.content) {
                if (_saveStatus.value != "Lỗi lưu! Thử lại...") _saveStatus.value = "Đã lưu tự động"
                return
            }
            val words = calculateWordCount(currentText)

            _isSaving.value = true
            _saveStatus.value = "Đang lưu..."
            try {
                val updated = currentCh.copy(
                    content = currentText,
                    wordCount = words,
                    updatedAt = System.currentTimeMillis()
                )
                novelRepository.updateChapter(updated)
                _chapter.value = updated

                // Auto-snapshot every ~500 new words
                if (kotlin.math.abs(words - lastAutoSnapshotWordCount) >= 500 && words > 0) {
                    novelRepository.insertSnapshot(
                        ChapterSnapshot(
                            chapterId = chapterId,
                            snapshotTitle = "Mốc tự động (${words} từ)",
                            content = currentText,
                            wordCount = words
                        )
                    )
                    lastAutoSnapshotWordCount = words
                }
                // Nếu người dùng gõ thêm trong lúc đang lưu thì giữ trạng thái "Đang gõ..."
                if (_textFieldValue.value.text == currentText) {
                    _saveStatus.value = "Đã lưu tự động"
                }
            } catch (e: Exception) {
                android.util.Log.e("EditorViewModel", "Save failed", e)
                _saveStatus.value = "Lỗi lưu! Thử lại..."
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val prev = undoStack.removeAt(undoStack.lastIndex)
            redoStack.add(_textFieldValue.value)
            _textFieldValue.value = prev
            _canUndo.value = undoStack.isNotEmpty()
            _canRedo.value = true
            scheduleAutoSave()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.lastIndex)
            undoStack.add(_textFieldValue.value)
            _textFieldValue.value = next
            _canUndo.value = true
            _canRedo.value = redoStack.isNotEmpty()
            scheduleAutoSave()
        }
    }

    // Punctuation macros
    fun insertVietnameseQuotes() {
        insertSurroundingText("“", "”")
    }

    fun insertEmDash() {
        insertText("— ")
    }

    fun insertEllipsis() {
        insertText("... ")
    }

    /** Thêm phần mở rộng "(V.O.)" (giọng đọc ngoài hình) sau tên nhân vật. */
    fun insertIndent() {
        insertText(" (V.O.)")
    }

    fun insertParenthesis() {
        insertSurroundingText("(", ")")
    }

    fun insertCornerBrackets() {
        insertSurroundingText("「", "」")
    }

    fun insertText(insert: String) {
        val current = _textFieldValue.value
        val selStart = current.selection.min
        val selEnd = current.selection.max
        val before = current.text.substring(0, selStart)
        val after = current.text.substring(selEnd)
        val newText = before + insert + after
        val newCursor = selStart + insert.length

        onTextChanged(
            TextFieldValue(
                text = newText,
                selection = TextRange(newCursor)
            )
        )
    }

    private fun insertSurroundingText(open: String, close: String) {
        val current = _textFieldValue.value
        val selStart = current.selection.min
        val selEnd = current.selection.max
        val selected = current.text.substring(selStart, selEnd)

        val newText = current.text.substring(0, selStart) + open + selected + close + current.text.substring(selEnd)
        val newCursor = if (selected.isEmpty()) selStart + open.length else selStart + open.length + selected.length + close.length

        onTextChanged(
            TextFieldValue(
                text = newText,
                selection = TextRange(newCursor)
            )
        )
    }

    // Spell check
    fun runSpellCheck() {
        viewModelScope.launch {
            _isCheckingSpelling.value = true
            val issues = VietnameseSpellChecker.check(_textFieldValue.value.text)
            _spellingIssues.value = issues
            _isCheckingSpelling.value = false
        }
    }

    fun fixSpellingIssue(issue: SpellingIssue) {
        val current = _textFieldValue.value.text
        if (issue.startIndex in 0..current.length && issue.endIndex in issue.startIndex..current.length &&
            current.substring(issue.startIndex, issue.endIndex) == issue.originalWord
        ) {
            val before = current.substring(0, issue.startIndex)
            val after = current.substring(issue.endIndex)
            val replaced = before + issue.suggestedWord + after
            val newCursor = issue.startIndex + issue.suggestedWord.length
            onTextChanged(
                TextFieldValue(
                    text = replaced,
                    selection = TextRange(newCursor)
                )
            )
            runSpellCheck()
        } else {
            // Văn bản đã thay đổi sau lần quét -> vị trí cũ không còn đúng, quét lại
            runSpellCheck()
        }
    }

    fun fixAllSpellingIssues() {
        var text = _textFieldValue.value.text
        val issues = _spellingIssues.value.sortedByDescending { it.startIndex }
        for (issue in issues) {
            if (issue.startIndex in 0..text.length && issue.endIndex in issue.startIndex..text.length &&
                text.substring(issue.startIndex, issue.endIndex) == issue.originalWord
            ) {
                val before = text.substring(0, issue.startIndex)
                val after = text.substring(issue.endIndex)
                text = before + issue.suggestedWord + after
            }
        }
        onTextChanged(
            TextFieldValue(
                text = text,
                selection = TextRange(text.length)
            )
        )
        _spellingIssues.value = emptyList()
    }

    // ---- Kịch bản ----

    /** Đổi dòng đang gõ sang kiểu [type] (Cảnh, Hành động, Nhân vật, Chỉ dẫn, Chuyển cảnh). */
    fun convertCurrentLine(type: com.example.util.LineType) {
        val v = _textFieldValue.value
        val (text, cursor) = com.example.util.Screenplay.convertLine(v.text, v.selection.min.coerceIn(0, v.text.length), type)
        onTextChanged(TextFieldValue(text = text, selection = TextRange(cursor.coerceIn(0, text.length))))
    }

    /** Thay dòng đang gõ bằng gợi ý. Chọn tên nhân vật thì xuống dòng để gõ lời thoại ngay. */
    fun applySuggestion(value: String) {
        val v = _textFieldValue.value
        val (text0, cursor0) = com.example.util.Screenplay.replaceLine(v.text, v.selection.min.coerceIn(0, v.text.length), value)
        var text = text0
        var cursor = cursor0
        val isCue = !com.example.util.Screenplay.isSceneHeading(value) && !com.example.util.Screenplay.isTransition(value) &&
            value == value.uppercase() && !value.endsWith(" ")
        if (isCue || com.example.util.Screenplay.isTransition(value)) {
            val extra = if (isCue) "\n" else "\n\n"
            text = text.substring(0, cursor) + extra + text.substring(cursor)
            cursor += extra.length
        }
        onTextChanged(TextFieldValue(text = text, selection = TextRange(cursor)))
    }

    /** Chuẩn hóa trình bày kịch bản (viết hoa tiêu đề cảnh / nhân vật / chuyển cảnh, dòng trống giữa các khối). */
    fun formatScript() {
        val formatted = com.example.util.Screenplay.normalize(_textFieldValue.value.text)
        onTextChanged(TextFieldValue(text = formatted, selection = TextRange(formatted.length)))
    }

    /** Đặt con trỏ tại [offset] (không đổi nội dung). */
    fun moveCursor(offset: Int) {
        val v = _textFieldValue.value
        _textFieldValue.value = v.copy(selection = TextRange(offset.coerceIn(0, v.text.length)))
    }

    fun formatNovelParagraphs() {
        val raw = _textFieldValue.value.text
        // Bỏ các dòng trống trước khi nối bằng "\n\n" — trước đây mỗi lần bấm định dạng
        // số dòng trống giữa các đoạn lại nhân đôi (1 -> 3 -> 7...).
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val formatted = lines.joinToString("\n\n") { trimmed ->
            if (!trimmed.startsWith("—")) "    $trimmed" else trimmed
        }
        onTextChanged(TextFieldValue(text = formatted, selection = TextRange(formatted.length)))
    }

    fun replaceAll(findText: String, replaceWith: String) {
        if (findText.isEmpty()) return
        val current = _textFieldValue.value.text
        val newText = current.replace(findText, replaceWith)
        onTextChanged(TextFieldValue(text = newText, selection = TextRange(newText.length)))
    }

    fun createSnapshot(title: String) {
        viewModelScope.launch {
            val text = _textFieldValue.value.text
            val words = calculateWordCount(text)
            novelRepository.insertSnapshot(
                ChapterSnapshot(
                    chapterId = chapterId,
                    snapshotTitle = title.trim().ifEmpty { "Bản lưu mốc" },
                    content = text,
                    wordCount = words
                )
            )
        }
    }

    fun restoreSnapshot(snapshot: ChapterSnapshot) {
        onTextChanged(TextFieldValue(text = snapshot.content, selection = TextRange(snapshot.content.length)))
        saveImmediately()
    }

    fun deleteSnapshot(snapshot: ChapterSnapshot) {
        viewModelScope.launch {
            novelRepository.deleteSnapshot(snapshot.id)
        }
    }

    fun updateChapterTitle(newTitle: String) {
        viewModelScope.launch {
            saveMutex.withLock {
                val current = _chapter.value ?: return@withLock
                val updated = current.copy(title = newTitle.trim(), updatedAt = System.currentTimeMillis())
                novelRepository.updateChapter(updated)
                _chapter.value = updated
            }
        }
    }

    /** Lưu dàn ý và ghi chú của chương (bản 1.5). */
    fun saveOutlineAndNotes(outline: String, notes: String) {
        viewModelScope.launch {
            saveMutex.withLock {
                val current = _chapter.value ?: return@withLock
                if (current.outline == outline && current.notes == notes) return@withLock
                val updated = current.copy(outline = outline, notes = notes, updatedAt = System.currentTimeMillis())
                try {
                    novelRepository.updateChapter(updated)
                    _chapter.value = updated
                } catch (e: Exception) {
                    android.util.Log.e("EditorViewModel", "Save outline failed", e)
                }
            }
        }
    }

    fun toggleDistractionFree() {
        _settings.value = _settings.value.copy(distractionFree = !_settings.value.distractionFree)
    }

    fun updateSettings(newSettings: WritingSettings) {
        _settings.value = newSettings
        settingsStore?.save(newSettings)
    }

    /**
     * Lưu chương rồi MỚI sao lưu (trước đây 2 việc chạy song song nên bản sao lưu có thể
     * thiếu đoạn vừa gõ). Chỉ sao lưu nếu có chỉnh sửa, và tự dọn bớt bản sao lưu tự động cũ.
     */
    fun saveAndBackupOnExit() {
        autoSaveJob?.cancel()
        viewModelScope.launch {
            saveInternal()
            if (hasEditsThisSession) {
                hasEditsThisSession = false
                try {
                    backupRepository.createFullJsonBackup(BackupRepository.AUTO_BACKUP_PREFIX)
                    backupRepository.pruneAutoBackups(keep = 10)
                } catch (e: Exception) {
                    android.util.Log.e("EditorViewModel", "Auto backup failed", e)
                }
            }
        }
    }

    /** Gọi khi app bị đưa xuống nền: lưu ngay, không đợi 1.2 giây. */
    fun flushPendingSave() {
        if (autoSaveJob?.isActive == true || _saveStatus.value == "Đang gõ...") {
            saveImmediately()
        }
    }

    fun calculateWordCount(text: String): Int {
        if (text.isBlank()) return 0
        return text.trim().split(Regex("""\s+""")).filter { it.isNotBlank() }.size
    }
}
