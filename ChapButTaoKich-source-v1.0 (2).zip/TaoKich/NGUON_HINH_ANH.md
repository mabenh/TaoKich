# Nguồn hình ảnh trong app

| Hình | Tệp | Nguồn |
|---|---|---|
| Logo ứng dụng (chữ V) | `app/src/main/res/mipmap-*/ic_launcher*.png`, `drawable-nodpi/logo_v.png` | Văn Mọn tạo bằng **ChatGPT** (OpenAI). Nền tím than và dải bảng phim của biểu tượng Tạo Kịch được vẽ bằng mã |
| Hình đại diện nhân vật (45 hình) | `app/src/main/res/drawable-nodpi/av_b01.webp` … `av_b45.webp` | Văn Mọn tạo bằng **Gemini** (Google), đã chỉnh sửa để xóa logo thương hiệu và phù hiệu, cấp hiệu trên trang phục |
| Viền bìa (5 mẫu) | `drawable-nodpi/cover_frame_*.png` | Tự vẽ bằng mã (SVG) của Chấp Bút, không dùng ảnh của bên thứ ba. Mã sinh: `tools/cover-frames.py` trong dự án Chấp Bút |
| Nền giấy (5 mẫu) | `drawable-nodpi/cover_paper_*.jpg` | Sinh bằng thuật toán (nhiễu ngẫu nhiên), không dùng ảnh của bên thứ ba. Mã sinh: `tools/cover-papers.py` trong dự án Chấp Bút |
| Biểu tượng nút bấm | Material Icons | Google, giấy phép Apache 2.0 (đi kèm thư viện Compose) |

Ảnh do người dùng tự tải lên (viền, nền giấy) chỉ lưu trong máy của người dùng. Người dùng tự chịu trách nhiệm về quyền sử dụng các ảnh đó.

**Nên lưu lại** lời nhắc (prompt), ngày tạo và tài khoản đã dùng để tạo logo và hình đại diện, làm bằng chứng nguồn gốc khi cần.
