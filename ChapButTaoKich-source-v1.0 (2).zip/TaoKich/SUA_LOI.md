# Bút Văn: các lỗi đã sửa

## Mất dữ liệu / lưu sai
1. **Lỗi khởi tạo database thì xóa sạch truyện mà không báo** (`AppDatabase`). App sẽ chép tệp DB lỗi sang `files/db_rescue/` trước khi tạo DB mới. Đã bỏ `fallbackToDestructiveMigration`, vì nếu sau này tăng version mà quên viết migration thì tùy chọn này sẽ xóa hết dữ liệu.
2. **Thoát chương thì sao lưu chạy song song với việc lưu** nên bản sao lưu có thể thiếu đoạn vừa gõ. Giờ app lưu xong rồi mới sao lưu, và chỉ sao lưu khi chương thật sự có sửa.
3. **App bị đưa xuống nền (bấm Home) trong 1,2 giây chờ lưu tự động** thì có thể mất chữ. Giờ app lưu ngay khi bị đưa xuống nền (ON_STOP).
4. **Hai lần lưu chạy chồng nhau** (lưu nội dung và đổi tiêu đề) làm mất tiêu đề mới. Các lần ghi giờ chạy lần lượt qua một Mutex.
5. **Bản sao lưu trùng tên khi tạo trong cùng một giây**: tệp sau ghi đè tệp trước, và xóa một bản thì mất luôn tệp của bản kia. Tên tệp giờ là duy nhất, tệp được ghi ra bản tạm rồi mới đổi tên.
6. **Sao lưu không lưu trạng thái "đã xóa"** nên khôi phục làm truyện trong thùng rác sống lại. Ngày tạo và ngày sửa cũng được giữ lại khi khôi phục.
7. **Khôi phục bị lỗi giữa chừng để lại dữ liệu dở dang**. Giờ toàn bộ việc khôi phục chạy trong một transaction.
8. **Mỗi lần thoát chương tạo thêm một bản sao lưu tự động, không bao giờ dọn**. Giờ chỉ giữ 10 bản tự động mới nhất.

## Treo, nháy màn hình, điều hướng
9. **Màn chi tiết truyện tạo Flow mới mỗi lần vẽ lại**, nên màn hình nháy vòng "đang tải" và truy vấn DB lặp liên tục. Đã sửa bằng `remember(novelId)`.
10. **Bấm Back hệ thống ở màn chi tiết truyện hoặc sao lưu là thoát hẳn app**. Giờ Back quay về danh sách. Trong chế độ không phân tâm, Back thoát chế độ đó trước.
11. **Xoay màn hình hoặc đổi chế độ sáng/tối là bị đá về danh sách truyện**. Màn hình hiện tại giờ được giữ lại qua các lần đó.
12. **ViewModel tạo bằng `remember {}`** nên không bao giờ được hủy (rò rỉ bộ nhớ) và bị tạo lại khi xoay màn hình. Đã chuyển sang `viewModel()`.

## Chức năng sai hoặc thiếu
13. **Dữ liệu mẫu không bao giờ được tạo**, vì callback `onCreate` đọc `INSTANCE` lúc biến này vẫn còn null.
14. **Không có nút xóa tác phẩm** (chưa có chỗ nào gọi `softDeleteNovel`). Đã thêm nút xóa có hỏi xác nhận ở màn chi tiết.
15. **"Dọn sạch" thùng rác không xóa các chương đã xóa**. Đã thêm hộp thoại xác nhận cho "Dọn sạch" và "Xóa vĩnh viễn".
16. **Số thứ tự chương/quyển mới bị trùng sau khi xóa**: trước dùng số lượng + 1, giờ dùng số lớn nhất + 1.
17. **Chưa có chương nào thì không thể thêm quyển**, vì chế độ "Cột quyển" bị ẩn. Giờ chế độ này vẫn hiện.
18. **Cài đặt soạn thảo (chủ đề, phông, cỡ chữ) bị reset mỗi lần mở chương**. Giờ cài đặt được lưu lại.
19. **"Định dạng chuẩn đoạn văn" làm số dòng trống nhân đôi** sau mỗi lần bấm.
20. **Bấm tạo truyện hoặc chương 2 lần nhanh thì tạo ra 2 bản**.

## Kiểm tra chính tả
21. Các lỗi dạng cụm từ ("bổ xung", "sáng lạng", "xơ xuất"...) **không bao giờ được phát hiện**, vì trước đây app chỉ tách từng chữ. Đã sửa.
22. **Báo lỗi cả những từ đúng** ("hẻm", "dành dụm", "giành giật"...). Đã sửa.
23. **Mọi từ có chữ "w" đều bị báo lỗi Telex**. Giờ chỉ xét từ Latin không dấu.
24. **"Sửa" theo vị trí cũ sau khi văn bản đã đổi** có thể thay nhầm chữ. Giờ app kiểm tra lại trước khi thay.

## Google Drive
25. **Tải lên Drive dùng sai định dạng multipart** (`form-data` thay vì `related`) nên Drive trả lỗi hoặc tạo tệp "Untitled".
26. **Rò rỉ kết nối mạng** vì response không được đóng.
27. **Đăng nhập lỗi nhưng chỉ báo "Đã hủy"**. Giờ app hiện mã lỗi thật, ví dụ mã 10 là chưa đăng ký SHA-1.
28. **Tên tệp tải về từ Drive không được làm sạch** (lỗi path traversal).
29. Thông báo khôi phục giờ nói rõ là **thêm bản sao**, không ghi đè truyện đang có.

## Build
30. Build debug **không cần tệp `debug.keystore` của AI Studio nữa**, nên build được bằng Android Studio trên máy cá nhân.

## Bổ sung (lần 2)
31. Thanh trượt **"Giãn đoạn văn" đã hoạt động**: tạo khoảng cách giữa các đoạn trong ô soạn thảo, từ 0 (tắt) đến 32 dp. Nội dung thật của chương không thay đổi; khi sao chép, lưu, xuất TXT hay đếm từ, văn bản vẫn y như cũ.
32. **Đổi tên và xóa quyển:**
    - Mở bằng nút ⋮ trên đầu mỗi cột quyển (chế độ "Cột quyển"), hoặc nút **Quản lý quyển** (biểu tượng sách) trên thanh tiêu đề của màn chi tiết truyện, dùng được ở cả chế độ "Liệt kê".
    - Sửa được tên, thứ tự và mô tả quyển.
    - Khi xóa quyển có chương, app hỏi bạn muốn **giữ chương** (chuyển sang "Chưa phân quyển") hay **chuyển cả chương vào thùng rác**.

## Còn lại (không phải lỗi mã nguồn)
- **Đăng nhập Google Drive:** app đã được ký bằng khóa tự tạo. Bạn chỉ cần đăng ký SHA-1 của khóa này trong Google Cloud (miễn phí), các bước có trong `KY_APP.md`.
- Các thư viện Firebase (AI, Firestore, Auth, App Check) được khai báo nhưng không được dùng, chỉ làm app nặng thêm.
