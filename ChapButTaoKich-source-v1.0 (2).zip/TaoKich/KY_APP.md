# Ký app Chấp Bút Tạo Kịch

Tạo Kịch dùng **cùng khóa ký** với Chấp Bút Kiến Văn (`keystore/butvan-release.jks` + `keystore.properties`). Chép 2 tệp này vào thư mục dự án Tạo Kịch trước khi build, hoặc đặt vào secrets của GitHub như đang làm với Kiến Văn.
Tạo Kịch có mã gói riêng (`com.vanmon.chapbut.taokich`), nên cài **song song** với Kiến Văn, không đè lên nhau, dữ liệu cũng tách riêng.

---

# Ký app bằng khóa tự tạo (self-signed)

Dự án đã có sẵn khóa ký riêng, không cần Google Play Console:

- `keystore/butvan-release.jks`: tệp khóa
- `keystore.properties`: mật khẩu khóa

Cả bản debug lẫn release đều được ký bằng khóa này.

| Thông tin | Giá trị |
|---|---|
| Alias | `butvan` |
| Hạn dùng | đến năm 2054 |
| **SHA-1** | `DD:30:80:E6:EF:A0:E1:50:D9:17:02:02:C1:46:FB:B3:38:F9:08:DE` |
| SHA-256 | `4F:31:3F:B8:54:BD:BB:2D:0C:2F:E0:3A:0C:A4:57:08:28:A9:E3:80:68:28:86:79:54:87:67:3E:31:57:41:A8` |

## ⚠️ Giữ kỹ 2 tệp khóa
- **Sao lưu `keystore/` và `keystore.properties` ra nơi an toàn** (USB, Drive cá nhân). Nếu mất khóa, bạn không thể cài bản cập nhật đè lên app cũ. Khi đó phải gỡ app, và **gỡ app là mất toàn bộ truyện trong máy**.
- **Không gửi 2 tệp này cho người khác**, và không đưa lên GitHub. `.gitignore` đã chặn sẵn.

## Tạo tệp APK để cài
1. Mở dự án bằng Android Studio và đợi Gradle Sync xong.
2. Mở **Build › Select Build Variant…**, chọn `release` cho module `app`.
3. Bấm **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.
4. Tệp nằm ở `app/build/outputs/apk/release/app-release.apk`. Chép tệp sang điện thoại và mở để cài. Điện thoại sẽ hỏi cho phép "Cài ứng dụng không rõ nguồn gốc", bạn chọn cho phép.

> **Lưu ý khi đã cài bản cũ (bản tải từ AI Studio):** bản cũ ký bằng khóa khác, nên Android sẽ báo "Ứng dụng xung đột". Bạn phải gỡ bản cũ trước, và gỡ app thì **mất dữ liệu trong app**. Trước khi gỡ, hãy vào từng truyện và bấm nút **Chia sẻ (xuất TXT)** để giữ bản thảo.

## Bật đăng nhập Google Drive (miễn phí, không cần Play Console)
Google chỉ cho app đăng nhập khi gói + SHA-1 đã được đăng ký trong một dự án Google Cloud:

1. Vào https://console.cloud.google.com, tạo dự án mới (hoặc dùng lại dự án của Kiến Văn).
2. Vào **APIs & Services › Library**, tìm **Google Drive API** và bấm **Enable**.
3. Vào **Google Auth Platform**, mục *OAuth consent screen*, rồi làm như sau:
   - Loại người dùng: **External**.
   - Tên app: Chấp Bút Tạo Kịch. Email hỗ trợ: email của bạn.
   - Ở mục **Data Access / Scopes**, thêm `.../auth/drive.file`.
   - Ở mục **Audience**, thêm Gmail bạn dùng để đăng nhập vào **Test users**. Nếu không muốn phải đăng nhập lại định kỳ, bấm **Publish app** (quyền `drive.file` không cần Google xét duyệt).
4. Vào **Credentials › Create credentials › OAuth client ID**, rồi điền:
   - Application type: **Android**
   - Package name: `com.vanmon.chapbut.taokich` (Tạo Kịch là app riêng nên **cần tạo OAuth client riêng**, không dùng chung client của Kiến Văn)
   - SHA-1: `DD:30:80:E6:EF:A0:E1:50:D9:17:02:02:C1:46:FB:B3:38:F9:08:DE`
5. Bấm Create. Sau khoảng 5 phút, mở app, vào **Sao lưu & Đồng bộ** và bấm đăng nhập Google.

Không cần sửa mã nguồn và không cần tải `google-services.json` mới.
