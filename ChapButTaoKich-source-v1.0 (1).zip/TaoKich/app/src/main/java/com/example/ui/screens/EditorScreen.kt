package com.example.ui.screens

import com.example.ui.state.terms
import com.example.ui.state.LocalTerms
import com.example.ui.state.termsOf
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.ChapterSnapshot
import com.example.ui.state.EditorThemeType
import com.example.ui.state.WritingSettings
import com.example.ui.theme.EditorFontOption
import com.example.util.HighlightTransformation
import com.example.util.Screenplay
import kotlinx.coroutines.launch
import com.example.util.ReadState
import com.example.util.SpellingIssue
import com.example.viewmodel.EditorViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    editorViewModel: EditorViewModel,
    onBack: () -> Unit
) {
    val chapter by editorViewModel.chapter.collectAsState()
    val textFieldValue by editorViewModel.textFieldValue.collectAsState()
    val isSaving by editorViewModel.isSaving.collectAsState()
    val saveStatus by editorViewModel.saveStatus.collectAsState()
    val settings by editorViewModel.settings.collectAsState()
    val canUndo by editorViewModel.canUndo.collectAsState()
    val canRedo by editorViewModel.canRedo.collectAsState()
    val snapshots by editorViewModel.snapshots.collectAsState()
    val readState by editorViewModel.readState.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var showOutlineSheet by remember { mutableStateOf(false) }
    var showSceneList by remember { mutableStateOf(false) }
    val knownCharacters by editorViewModel.knownCharacters.collectAsState()
    val knownLocations by editorViewModel.knownLocations.collectAsState()
    val sceneOffset by editorViewModel.sceneNumberOffset.collectAsState()
    var showVoiceHelp by remember { mutableStateOf(false) }
    var voiceHelpShown by remember { mutableStateOf(false) }

    var showSettingsSheet by remember { mutableStateOf(false) }
    var showSnapshotSheet by remember { mutableStateOf(false) }
    var showStatsDialog by remember { mutableStateOf(false) }
    var showFindReplaceDialog by remember { mutableStateOf(false) }
    var showEditTitleDialog by remember { mutableStateOf(false) }
    var showSpellCheckSheet by remember { mutableStateOf(false) }
    var isAccessoryBarCollapsed by remember { mutableStateOf(false) }

    val editorTheme = settings.theme
    val currentWords = remember(textFieldValue.text) {
        editorViewModel.calculateWordCount(textFieldValue.text)
    }

    // Khoảng cách giữa các đoạn văn (thanh trượt "Giãn đoạn văn"). 0 = tắt.
    val density = androidx.compose.ui.platform.LocalDensity.current
    val paragraphTransformation = remember(settings.paragraphSpacingDp, density) {
        if (settings.paragraphSpacingDp < 1f) {
            androidx.compose.ui.text.input.VisualTransformation.None
        } else {
            ParagraphSpacingTransformation(with(density) { settings.paragraphSpacingDp.dp.toSp() })
        }
    }
    // Trình bày kịch bản (tiêu đề cảnh, nhân vật, thoại, chuyển cảnh) — không đổi nội dung thật
    val scriptTransformation = remember(editorTheme) {
        ScreenplayTransformation(editorTheme.accentColor, editorTheme.secondaryTextColor)
    }
    // Tô sáng câu đang đọc bằng giọng nói
    val readHighlight = editorTheme.accentColor.copy(alpha = 0.28f)
    val readRange = readState.range
    val displayTransformation = remember(scriptTransformation, readRange, readHighlight) {
        if (readRange == null) scriptTransformation
        else HighlightTransformation(readRange, readHighlight, scriptTransformation)
    }
    // Kiểu dòng đang gõ + gợi ý (tên nhân vật, địa điểm, thời điểm, chuyển cảnh)
    val cursorPos = textFieldValue.selection.min.coerceIn(0, textFieldValue.text.length)
    val currentLineType = remember(textFieldValue.text, cursorPos) {
        Screenplay.typeAt(textFieldValue.text, cursorPos)
    }
    val lineSuggestions = remember(textFieldValue.text, cursorPos, knownCharacters, knownLocations) {
        Screenplay.suggestions(
            textFieldValue.text, cursorPos,
            knownCharacters + Screenplay.characterNames(textFieldValue.text),
            (knownLocations + Screenplay.locationsIn(textFieldValue.text)).distinct()
        )
    }
    val pages = remember(textFieldValue.text) { Screenplay.estimatePages(textFieldValue.text) }
    val scrollState = rememberScrollState()
    var textLayout by remember { mutableStateOf<androidx.compose.ui.text.TextLayoutResult?>(null) }

    // Cuộn theo câu đang đọc
    LaunchedEffect(readRange) {
        val r = readRange ?: return@LaunchedEffect
        val layout = textLayout ?: return@LaunchedEffect
        try {
            val t = r.first
            val len = layout.layoutInput.text.length
            val line = layout.getLineForOffset(t.coerceIn(0, len))
            val top = layout.getLineTop(line).toInt()
            val viewport = scrollState.viewportSize
            if (top < scrollState.value + 40 || top > scrollState.value + viewport - 120) {
                scrollState.animateScrollTo((top - viewport / 3).coerceAtLeast(0))
            }
        } catch (_: Exception) {
        }
    }

    // Thông báo của bộ đọc (đọc xong, lỗi...)
    LaunchedEffect(readState.message) {
        val m = readState.message ?: return@LaunchedEffect
        android.widget.Toast.makeText(context, m, android.widget.Toast.LENGTH_SHORT).show()
        editorViewModel.clearReadingMessage()
    }
    LaunchedEffect(readState.missingVoice, readState.active) {
        if (readState.missingVoice && readState.active && !voiceHelpShown) {
            voiceHelpShown = true
            showVoiceHelp = true
        }
    }

    val editorTextStyle = TextStyle(
        fontFamily = settings.fontOption.fontFamily,
        fontSize = settings.fontSizeSp.sp,
        lineHeight = (settings.fontSizeSp * settings.lineHeightMultiplier).sp,
        color = editorTheme.textColor,
        textIndent = TextIndent.None
    )

    BackHandler {
        if (settings.distractionFree) {
            // Nút Back trong chế độ không phân tâm: thoát chế độ trước, không rời khỏi chương
            editorViewModel.toggleDistractionFree()
        } else {
            editorViewModel.saveAndBackupOnExit()
            onBack()
        }
    }

    // Lưu ngay khi app bị đưa xuống nền (bấm Home, nghe điện thoại...) để không mất chữ
    // nếu hệ thống tắt app trong lúc đang đợi lưu tự động.
    // Dùng thẳng lifecycle của Activity (không qua LocalLifecycleOwner, vốn có thể gây văng app
    // khi phiên bản thư viện Compose và Lifecycle không khớp nhau).
    val hostActivity = androidx.compose.ui.platform.LocalContext.current as? androidx.activity.ComponentActivity
    DisposableEffect(hostActivity, editorViewModel) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) editorViewModel.flushPendingSave()
        }
        hostActivity?.lifecycle?.addObserver(observer)
        onDispose { hostActivity?.lifecycle?.removeObserver(observer) }
    }

    val projectKind by editorViewModel.projectKind.collectAsState()
    CompositionLocalProvider(LocalTerms provides termsOf(projectKind)) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        color = editorTheme.backgroundColor
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header: Different in Distraction-Free mode vs Standard mode
            if (!settings.distractionFree) {
                StandardEditorHeader(
                    title = chapter?.title ?: "Đang tải...",
                    saveStatus = saveStatus,
                    isSaving = isSaving,
                    wordCount = currentWords,
                    theme = editorTheme,
                    onBack = {
                        editorViewModel.saveAndBackupOnExit()
                        onBack()
                    },
                    onTitleClick = { showEditTitleDialog = true },
                    onToggleDistractionFree = { editorViewModel.toggleDistractionFree() },
                    onOpenSettings = { showSettingsSheet = true },
                    onOpenHistory = { showSnapshotSheet = true },
                    onOpenStats = { showStatsDialog = true },
                    onOpenFindReplace = { showFindReplaceDialog = true },
                    onOpenSpellCheck = {
                        editorViewModel.runSpellCheck()
                        showSpellCheckSheet = true
                    },
                    onManualSave = { editorViewModel.saveImmediately() },
                    isReading = readState.active,
                    onReadAloud = {
                        if (readState.active) editorViewModel.stopReading() else editorViewModel.startReading()
                    },
                    onOpenOutline = { showOutlineSheet = true },
                    pages = pages,
                    onOpenScenes = { showSceneList = true }
                )
            } else {
                DistractionFreeHeader(
                    saveStatus = saveStatus,
                    wordCount = currentWords,
                    theme = editorTheme,
                    onExitDistractionFree = { editorViewModel.toggleDistractionFree() },
                    onOpenSettings = { showSettingsSheet = true },
                    onOpenStats = { showStatsDialog = true }
                )
            }

            // Main Writing Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = if (settings.distractionFree) 20.dp else 16.dp, vertical = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                ) {
                    BasicTextField(
                        value = textFieldValue,
                        onValueChange = { editorViewModel.onTextChanged(it) },
                        textStyle = editorTextStyle,
                        visualTransformation = displayTransformation,
                        onTextLayout = { textLayout = it },
                        cursorBrush = SolidColor(editorTheme.accentColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_editor_content"),
                        decorationBox = { innerTextField ->
                            Box(modifier = Modifier.fillMaxWidth()) {
                                if (textFieldValue.text.isEmpty()) {
                                    Text(
                                        text = if (settings.distractionFree)
                                            "Tĩnh tâm... Hãy để câu chuyện dẫn dắt ngòi bút của bạn..."
                                        else
                                            "NỘI. ĐỊA ĐIỂM – NGÀY\n\nMô tả hành động…\n\nTÊN NHÂN VẬT\nLời thoại…",
                                        style = editorTextStyle.copy(
                                            color = editorTheme.secondaryTextColor.copy(alpha = 0.5f)
                                        )
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )
                    // Compact bottom spacer - prevents clipping and eliminates large empty gaps
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            if (readState.active) {
                ReadAloudBar(
                    state = readState,
                    theme = editorTheme,
                    onPlayPause = {
                        if (readState.speaking) editorViewModel.pauseReading() else editorViewModel.resumeReading()
                    },
                    onPrevious = { editorViewModel.previousSentence() },
                    onNext = { editorViewModel.nextSentence() },
                    onStop = { editorViewModel.stopReading() },
                    onRate = { editorViewModel.setReadingRate(it) }
                )
            }

            ScreenplayLineBar(
                theme = editorTheme,
                currentType = currentLineType,
                suggestions = lineSuggestions,
                onConvert = { editorViewModel.convertCurrentLine(it) },
                onSuggestion = { editorViewModel.applySuggestion(it) }
            )

            // The Author Punctuation Bar (Vietnamese Macro Bar)
            AuthorAccessoryBar(
                theme = editorTheme,
                isCollapsed = isAccessoryBarCollapsed,
                onToggleCollapse = { isAccessoryBarCollapsed = !isAccessoryBarCollapsed },
                canUndo = canUndo,
                canRedo = canRedo,
                onUndo = { editorViewModel.undo() },
                onRedo = { editorViewModel.redo() },
                onInsertQuotes = { editorViewModel.insertVietnameseQuotes() },
                onInsertDash = { editorViewModel.insertEmDash() },
                onInsertEllipsis = { editorViewModel.insertEllipsis() },
                onInsertIndent = { editorViewModel.insertIndent() },
                onInsertParenthesis = { editorViewModel.insertParenthesis() },
                onInsertCornerBrackets = { editorViewModel.insertCornerBrackets() },
                onInsertQuestion = { editorViewModel.insertText("?") },
                onInsertExclamation = { editorViewModel.insertText("!") },
                onOpenSpellCheck = {
                    editorViewModel.runSpellCheck()
                    showSpellCheckSheet = true
                },
                onCreateSnapshot = { editorViewModel.createSnapshot("Bản lưu mốc thủ công") }
            )
        }
    }

    // Modal Bottom Sheets & Dialogs
    if (showSettingsSheet) {
        WritingSettingsSheet(
            settings = settings,
            onDismiss = { showSettingsSheet = false },
            onUpdateSettings = { editorViewModel.updateSettings(it) },
            onFormatParagraphs = {
                editorViewModel.formatScript()
                showSettingsSheet = false
            }
        )
    }

    if (showSpellCheckSheet) {
        val issues by editorViewModel.spellingIssues.collectAsState()
        val isChecking by editorViewModel.isCheckingSpelling.collectAsState()
        SpellCheckSheet(
            issues = issues,
            isChecking = isChecking,
            onDismiss = { showSpellCheckSheet = false },
            onRescan = { editorViewModel.runSpellCheck() },
            onFixIssue = { editorViewModel.fixSpellingIssue(it) },
            onFixAll = { editorViewModel.fixAllSpellingIssues() }
        )
    }

    if (showSnapshotSheet) {
        SnapshotHistorySheet(
            snapshots = snapshots,
            onDismiss = { showSnapshotSheet = false },
            onRestore = {
                editorViewModel.restoreSnapshot(it)
                showSnapshotSheet = false
            },
            onDelete = { editorViewModel.deleteSnapshot(it) },
            onCreateNew = { title ->
                editorViewModel.createSnapshot(title)
            }
        )
    }

    if (showStatsDialog) {
        val st = remember(textFieldValue.text) { Screenplay.stats(textFieldValue.text) }
        ScriptStatsDialog(
            title = "Thống kê ${terms.chap} này",
            stats = st,
            onDismiss = { showStatsDialog = false }
        )
    }

    if (showSceneList) {
        val scenes = remember(textFieldValue.text) { Screenplay.scenes(textFieldValue.text) }
        SceneListSheet(
            scenes = scenes,
            numberOffset = sceneOffset,
            onDismiss = { showSceneList = false },
            onJump = { off ->
                showSceneList = false
                editorViewModel.moveCursor(off)
                textLayout?.let { layout ->
                    val line = layout.getLineForOffset(off.coerceIn(0, layout.layoutInput.text.length))
                    val top = layout.getLineTop(line).toInt()
                    scope.launch { scrollState.animateScrollTo((top - 40).coerceAtLeast(0)) }
                }
            }
        )
    }

    if (showFindReplaceDialog) {
        FindReplaceDialog(
            onDismiss = { showFindReplaceDialog = false },
            onReplaceAll = { find, replace ->
                editorViewModel.replaceAll(find, replace)
            }
        )
    }

    if (showOutlineSheet) {
        ChapterOutlineSheet(
            initialOutline = chapter?.outline ?: "",
            initialNotes = chapter?.notes ?: "",
            onDismiss = { showOutlineSheet = false },
            onSave = { o, n ->
                editorViewModel.saveOutlineAndNotes(o, n)
                showOutlineSheet = false
                android.widget.Toast.makeText(context, "Đã lưu dàn ý & ghi chú", android.widget.Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showVoiceHelp) {
        AlertDialog(
            onDismissRequest = { showVoiceHelp = false },
            title = { Text("Chưa có giọng đọc tiếng Việt", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Máy đang đọc bằng giọng mặc định. Để nghe tiếng Việt, hãy vào Cài đặt → Chuyển văn bản thành giọng nói, " +
                        "chọn bộ Google và tải gói giọng nói Tiếng Việt."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showVoiceHelp = false
                    try {
                        context.startActivity(
                            android.content.Intent("com.android.settings.TTS_SETTINGS")
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                        try {
                            context.startActivity(
                                android.content.Intent(android.speech.tts.TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
                                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {
                        }
                    }
                }) { Text("Mở cài đặt giọng nói") }
            },
            dismissButton = { TextButton(onClick = { showVoiceHelp = false }) { Text("Để sau") } }
        )
    }

    if (showEditTitleDialog) {
        EditChapterTitleDialog(
            initialTitle = chapter?.title ?: "",
            onDismiss = { showEditTitleDialog = false },
            onConfirm = {
                editorViewModel.updateChapterTitle(it)
                showEditTitleDialog = false
            }
        )
    }
    }
}

@Composable
fun StandardEditorHeader(
    title: String,
    saveStatus: String,
    isSaving: Boolean,
    wordCount: Int,
    theme: EditorThemeType,
    onBack: () -> Unit,
    onTitleClick: () -> Unit,
    onToggleDistractionFree: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenFindReplace: () -> Unit,
    onOpenSpellCheck: () -> Unit,
    onManualSave: () -> Unit,
    isReading: Boolean = false,
    onReadAloud: () -> Unit = {},
    onOpenOutline: () -> Unit = {},
    pages: Double = 0.0,
    onOpenScenes: () -> Unit = {}
) {
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(theme.surfaceColor)
            .padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.size(34.dp).testTag("btn_editor_back")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Quay lại",
                tint = theme.textColor,
                modifier = Modifier.size(18.dp)
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onTitleClick)
                .padding(horizontal = 6.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = theme.textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (isSaving) Color(0xFFFFA000) else Color(0xFF4CAF50))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "$saveStatus • $wordCount chữ • ≈ ${formatPages(pages)} trang",
                    fontSize = 11.sp,
                    color = theme.secondaryTextColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Đọc bằng giọng nói
        IconButton(
            onClick = onReadAloud,
            modifier = Modifier.size(34.dp).testTag("btn_editor_read_aloud")
        ) {
            Icon(
                imageVector = if (isReading) Icons.Default.StopCircle else Icons.Default.RecordVoiceOver,
                contentDescription = if (isReading) "Dừng đọc" else "Đọc bằng giọng nói (từ vị trí con trỏ)",
                tint = theme.accentColor,
                modifier = Modifier.size(18.dp)
            )
        }

        // Spellcheck button
        IconButton(
            onClick = onOpenSpellCheck,
            modifier = Modifier.size(34.dp).testTag("btn_editor_spellcheck")
        ) {
            Icon(
                imageVector = Icons.Default.Spellcheck,
                contentDescription = "Soát lỗi chính tả",
                tint = theme.accentColor,
                modifier = Modifier.size(18.dp)
            )
        }

        // Distraction-Free Toggle
        IconButton(
            onClick = onToggleDistractionFree,
            modifier = Modifier.size(34.dp).testTag("btn_toggle_distraction_free")
        ) {
            Icon(
                imageVector = Icons.Default.Fullscreen,
                contentDescription = "Bật Chế độ không phân tâm",
                tint = theme.accentColor,
                modifier = Modifier.size(18.dp)
            )
        }

        IconButton(
            onClick = onOpenSettings,
            modifier = Modifier.size(34.dp).testTag("btn_editor_settings")
        ) {
            Icon(
                imageVector = Icons.Default.Palette,
                contentDescription = "Giao diện & Cỡ chữ",
                tint = theme.textColor,
                modifier = Modifier.size(18.dp)
            )
        }

        Box {
            IconButton(
                onClick = { showMenu = true },
                modifier = Modifier.size(34.dp).testTag("btn_editor_more")
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Thêm tùy chọn",
                    tint = theme.textColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Lưu ngay bây giờ") },
                    onClick = {
                        showMenu = false
                        onManualSave()
                    },
                    leadingIcon = { Icon(Icons.Default.Save, contentDescription = null) }
                )
                DropdownMenuItem(
                    text = { Text("Danh sách cảnh") },
                    onClick = {
                        showMenu = false
                        onOpenScenes()
                    },
                    leadingIcon = { Icon(Icons.Default.Movie, contentDescription = null) }
                )
                DropdownMenuItem(
                    text = { Text("Dàn ý & ghi chú ${terms.chap}") },
                    onClick = {
                        showMenu = false
                        onOpenOutline()
                    },
                    leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null) }
                )
                DropdownMenuItem(
                    text = { Text("Lịch sử bản lưu (Snapshots)") },
                    onClick = {
                        showMenu = false
                        onOpenHistory()
                    },
                    leadingIcon = { Icon(Icons.Default.History, contentDescription = null) }
                )
                DropdownMenuItem(
                    text = { Text("Tìm kiếm & Thay thế") },
                    onClick = {
                        showMenu = false
                        onOpenFindReplace()
                    },
                    leadingIcon = { Icon(Icons.Default.FindReplace, contentDescription = null) }
                )
                DropdownMenuItem(
                    text = { Text("Thống kê kịch bản") },
                    onClick = {
                        showMenu = false
                        onOpenStats()
                    },
                    leadingIcon = { Icon(Icons.Default.BarChart, contentDescription = null) }
                )
            }
        }
    }
}

@Composable
fun DistractionFreeHeader(
    saveStatus: String,
    wordCount: Int,
    theme: EditorThemeType,
    onExitDistractionFree: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenStats: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable(onClick = onOpenStats)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF4CAF50).copy(alpha = 0.8f))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$wordCount từ",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = theme.secondaryTextColor.copy(alpha = 0.7f)
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Palette,
                    contentDescription = "Chỉnh hiển thị",
                    tint = theme.secondaryTextColor.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onExitDistractionFree,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("btn_exit_distraction_free")
            ) {
                Icon(
                    imageVector = Icons.Default.FullscreenExit,
                    contentDescription = "Thoát chế độ không phân tâm",
                    tint = theme.secondaryTextColor.copy(alpha = 0.7f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun AuthorAccessoryBar(
    theme: EditorThemeType,
    isCollapsed: Boolean,
    onToggleCollapse: () -> Unit,
    canUndo: Boolean,
    canRedo: Boolean,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onInsertQuotes: () -> Unit,
    onInsertDash: () -> Unit,
    onInsertEllipsis: () -> Unit,
    onInsertIndent: () -> Unit,
    onInsertParenthesis: () -> Unit,
    onInsertCornerBrackets: () -> Unit,
    onInsertQuestion: () -> Unit,
    onInsertExclamation: () -> Unit,
    onOpenSpellCheck: () -> Unit,
    onCreateSnapshot: () -> Unit
) {
    if (isCollapsed) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggleCollapse)
                .background(theme.surfaceColor.copy(alpha = 0.9f))
                .padding(vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowUp,
                    contentDescription = "Hiện phím tắt",
                    tint = theme.secondaryTextColor,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Hiện phím tắt viết kịch bản",
                    fontSize = 11.sp,
                    color = theme.secondaryTextColor,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        return
    }

    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(theme.surfaceColor.copy(alpha = 0.98f))
            .horizontalScroll(scrollState)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Thu gọn button
        IconButton(
            onClick = onToggleCollapse,
            modifier = Modifier.size(28.dp)
        ) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = "Thu gọn phím tắt",
                tint = theme.secondaryTextColor,
                modifier = Modifier.size(15.dp)
            )
        }

        // Undo / Redo
        IconButton(
            onClick = onUndo,
            enabled = canUndo,
            modifier = Modifier.size(28.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Undo,
                contentDescription = "Hoàn tác",
                tint = if (canUndo) theme.textColor else theme.secondaryTextColor.copy(alpha = 0.3f),
                modifier = Modifier.size(15.dp)
            )
        }

        IconButton(
            onClick = onRedo,
            enabled = canRedo,
            modifier = Modifier.size(28.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Redo,
                contentDescription = "Làm lại",
                tint = if (canRedo) theme.textColor else theme.secondaryTextColor.copy(alpha = 0.3f),
                modifier = Modifier.size(15.dp)
            )
        }

        PunctuationButton(label = "Chính tả", onClick = onOpenSpellCheck, theme = theme, testTag = "macro_spellcheck")
        PunctuationButton(label = "“ ”", onClick = onInsertQuotes, theme = theme, testTag = "macro_quotes")
        PunctuationButton(label = "—", onClick = onInsertDash, theme = theme, testTag = "macro_dash")
        PunctuationButton(label = "...", onClick = onInsertEllipsis, theme = theme, testTag = "macro_ellipsis")
        PunctuationButton(label = "(V.O.)", onClick = onInsertIndent, theme = theme, testTag = "macro_vo")
        PunctuationButton(label = "( )", onClick = onInsertParenthesis, theme = theme)
        PunctuationButton(label = "「 」", onClick = onInsertCornerBrackets, theme = theme)
        PunctuationButton(label = "?", onClick = onInsertQuestion, theme = theme)
        PunctuationButton(label = "!", onClick = onInsertExclamation, theme = theme)

        IconButton(onClick = onCreateSnapshot, modifier = Modifier.size(28.dp)) {
            Icon(
                imageVector = Icons.Default.BookmarkAdd,
                contentDescription = "Lưu mốc lịch sử",
                tint = theme.accentColor,
                modifier = Modifier.size(15.dp)
            )
        }
    }
}

@Composable
fun PunctuationButton(
    label: String,
    onClick: () -> Unit,
    theme: EditorThemeType,
    testTag: String? = null
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(theme.backgroundColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 4.dp)
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = theme.textColor
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WritingSettingsSheet(
    settings: WritingSettings,
    onDismiss: () -> Unit,
    onUpdateSettings: (WritingSettings) -> Unit,
    onFormatParagraphs: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Tùy Chỉnh Soạn Thảo",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            // Themes
            Column {
                Text("Chủ đề nền & màu sắc:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EditorThemeType.values().forEach { t ->
                        val isSelected = settings.theme == t
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = t.backgroundColor,
                            border = androidx.compose.foundation.BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier
                                .clickable { onUpdateSettings(settings.copy(theme = t)) }
                                .padding(2.dp)
                        ) {
                            Text(
                                text = t.displayName,
                                color = t.textColor,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Fonts
            Column {
                Text("Phông chữ văn học:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EditorFontOption.values().forEach { f ->
                        FilterChip(
                            selected = settings.fontOption == f,
                            onClick = { onUpdateSettings(settings.copy(fontOption = f)) },
                            label = { Text(f.displayName, fontSize = 12.sp) }
                        )
                    }
                }
            }

            // Font size slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Cỡ chữ:", style = MaterialTheme.typography.labelMedium)
                    Text("${settings.fontSizeSp.toInt()} sp", fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = settings.fontSizeSp,
                    onValueChange = { onUpdateSettings(settings.copy(fontSizeSp = it)) },
                    valueRange = 13f..26f,
                    steps = 12
                )
            }

            // Line height multiplier slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Giãn dòng:", style = MaterialTheme.typography.labelMedium)
                    Text("${String.format(Locale.US, "%.1f", settings.lineHeightMultiplier)}x", fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = settings.lineHeightMultiplier,
                    onValueChange = { onUpdateSettings(settings.copy(lineHeightMultiplier = it)) },
                    valueRange = 1.2f..2.4f
                )
            }

            ScreenplayHelp()

            // Auto-format novel paragraphs button
            OutlinedButton(
                onClick = onFormatParagraphs,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Chuẩn Hóa Trình Bày Kịch Bản")
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpellCheckSheet(
    issues: List<SpellingIssue>,
    isChecking: Boolean,
    onDismiss: () -> Unit,
    onRescan: () -> Unit,
    onFixIssue: (SpellingIssue) -> Unit,
    onFixAll: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Spellcheck,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Kiểm Tra Chính Tả Tiếng Việt",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(onClick = onRescan, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = "Quét lại")
                }
            }

            if (isChecking) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(36.dp))
                }
            } else if (issues.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Tuyệt vời! Không phát hiện lỗi chính tả",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Text(
                            text = "Văn phong tiếng Việt chuẩn xác và mạch lạc.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tìm thấy ${issues.size} điểm cần sửa",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                    Button(
                        onClick = onFixAll,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Sửa Tất Cả", fontSize = 12.sp)
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(issues) { issue ->
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = issue.originalWord,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowForward,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp).padding(horizontal = 2.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = issue.suggestedWord,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF2E7D32)
                                        )
                                    }
                                    Text(
                                        text = issue.reason,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                FilledTonalButton(
                                    onClick = { onFixIssue(issue) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("Sửa", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SnapshotHistorySheet(
    snapshots: List<ChapterSnapshot>,
    onDismiss: () -> Unit,
    onRestore: (ChapterSnapshot) -> Unit,
    onDelete: (ChapterSnapshot) -> Unit,
    onCreateNew: (String) -> Unit
) {
    var newSnapshotTitle by remember { mutableStateOf("") }
    val dateFormat = remember { SimpleDateFormat("HH:mm - dd/MM/yyyy", Locale.getDefault()) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(
                text = "Lịch Sử Bản Lưu (Snapshots)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newSnapshotTitle,
                    onValueChange = { newSnapshotTitle = it },
                    placeholder = { Text("Tên mốc lưu (Ví dụ: Trước khi sửa kết)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        onCreateNew(newSnapshotTitle.ifEmpty { "Mốc lưu thủ công" })
                        newSnapshotTitle = ""
                    }
                ) {
                    Text("Lưu Mốc")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (snapshots.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Chưa có bản lưu mốc nào.\nHệ thống sẽ tự động tạo mốc khi viết đủ 500 từ.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(snapshots, key = { it.id }) { snap ->
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = snap.snapshotTitle,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "${snap.wordCount} từ • ${dateFormat.format(Date(snap.createdAt))}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row {
                                    TextButton(onClick = { onRestore(snap) }) {
                                        Text("Khôi phục", fontSize = 12.sp)
                                    }
                                    IconButton(
                                        onClick = { onDelete(snap) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.DeleteOutline,
                                            contentDescription = "Xóa",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun ChapterStatsDialog(
    text: String,
    onDismiss: () -> Unit
) {
    val words = remember(text) {
        if (text.isBlank()) 0 else text.trim().split(Regex("""\s+""")).size
    }
    val charsNoSpaces = remember(text) { text.replace(Regex("""\s"""), "").length }
    val charsWithSpaces = text.length
    val paragraphs = remember(text) { if (text.isBlank()) 0 else text.lines().filter { it.isNotBlank() }.size }
    val readingTimeMinutes = remember(words) { (words / 220f).coerceAtLeast(0.1f) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Thống Kê Chi Tiết", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatRow(label = "Số lượng từ:", value = "$words từ")
                StatRow(label = "Ký tự (không tính dấu cách):", value = "$charsNoSpaces")
                StatRow(label = "Tổng ký tự:", value = "$charsWithSpaces")
                StatRow(label = "Số đoạn văn:", value = "$paragraphs đoạn")
                StatRow(label = "Thời gian đọc ước tính:", value = "~${String.format(Locale.US, "%.1f", readingTimeMinutes)} phút")
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Đóng") }
        }
    )
}

@Composable
fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(text = value, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun FindReplaceDialog(
    onDismiss: () -> Unit,
    onReplaceAll: (find: String, replace: String) -> Unit
) {
    var findText by remember { mutableStateOf("") }
    var replaceText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tìm Kiếm & Thay Thế", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = findText,
                    onValueChange = { findText = it },
                    label = { Text("Tìm từ / cụm từ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = replaceText,
                    onValueChange = { replaceText = it },
                    label = { Text("Thay thế bằng") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onReplaceAll(findText, replaceText)
                    onDismiss()
                },
                enabled = findText.isNotEmpty()
            ) {
                Text("Thay Thế Tất Cả")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}

@Composable
fun EditChapterTitleDialog(
    initialTitle: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var title by remember { mutableStateOf(initialTitle) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Đổi Tiêu Đề ${terms.Chap}", fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Tiêu đề ${terms.chap}") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title) },
                enabled = title.isNotBlank()
            ) {
                Text("Lưu")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}


// ----------------------------------------------------
// ĐỌC BẰNG GIỌNG NÓI: thanh điều khiển
// ----------------------------------------------------

@Composable
fun ReadAloudBar(
    state: ReadState,
    theme: EditorThemeType,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onStop: () -> Unit,
    onRate: (Float) -> Unit
) {
    val rates = listOf(0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(theme.surfaceColor)
            .padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = theme.accentColor, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(
            text = if (state.total > 0) "Câu ${state.index + 1}/${state.total}" else "Đang chuẩn bị…",
            fontSize = 11.sp,
            color = theme.secondaryTextColor,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onPrevious, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.SkipPrevious, contentDescription = "Câu trước", tint = theme.textColor, modifier = Modifier.size(18.dp))
        }
        IconButton(onClick = onPlayPause, modifier = Modifier.size(32.dp)) {
            Icon(
                if (state.speaking) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (state.speaking) "Tạm dừng" else "Đọc tiếp",
                tint = theme.accentColor,
                modifier = Modifier.size(20.dp)
            )
        }
        IconButton(onClick = onNext, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.SkipNext, contentDescription = "Câu sau", tint = theme.textColor, modifier = Modifier.size(18.dp))
        }
        IconButton(onClick = onStop, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Stop, contentDescription = "Dừng", tint = theme.textColor, modifier = Modifier.size(18.dp))
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(theme.backgroundColor)
                .clickable {
                    val i = rates.indexOfFirst { kotlin.math.abs(it - state.rate) < 0.01f }
                    onRate(rates[(i + 1) % rates.size])
                }
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = "${String.format(Locale.US, "%.2f", state.rate).trimEnd('0').trimEnd('.')}×",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = theme.textColor
            )
        }
    }
}

// ----------------------------------------------------
// DÀN Ý & GHI CHÚ CHƯƠNG
// ----------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterOutlineSheet(
    initialOutline: String,
    initialNotes: String,
    onDismiss: () -> Unit,
    onSave: (outline: String, notes: String) -> Unit
) {
    var outline by remember { mutableStateOf(initialOutline) }
    var notes by remember { mutableStateOf(initialNotes) }
    var fontSize by remember { mutableFloatStateOf(14f) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Dàn ý & ghi chú ${terms.chap}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { fontSize = (fontSize - 1f).coerceAtLeast(11f) }) { Text("A−") }
                TextButton(onClick = { fontSize = (fontSize + 1f).coerceAtMost(22f) }) { Text("A+") }
            }
            OutlinedTextField(
                value = outline,
                onValueChange = { outline = it },
                label = { Text("Dàn ý") },
                placeholder = { Text("Sự kiện chính, xung đột, cao trào của ${terms.chap}…", fontSize = fontSize.sp) },
                textStyle = LocalTextStyle.current.copy(fontSize = fontSize.sp, lineHeight = (fontSize * 1.5f).sp),
                minLines = 5,
                modifier = Modifier.fillMaxWidth().testTag("input_chapter_outline")
            )
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Ghi chú") },
                placeholder = { Text("Ghi chú, việc cần sửa…", fontSize = fontSize.sp) },
                textStyle = LocalTextStyle.current.copy(fontSize = fontSize.sp, lineHeight = (fontSize * 1.5f).sp),
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = onDismiss) { Text("Hủy") }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { onSave(outline, notes) }) { Text("Lưu") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
