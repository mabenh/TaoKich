package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.*
import com.example.data.repository.NovelRepository
import com.example.ui.state.ChapterSortOption
import com.example.ui.state.ChapterViewMode
import com.example.ui.state.CoverDesign
import com.example.ui.state.LibrarySort
import com.example.ui.state.RenameScope
import com.example.ui.state.termsOf
import com.example.util.Screenplay
import com.example.util.BookImporter
import com.example.util.TextTools
import com.example.util.WorldCategories
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NovelViewModel(private val repository: NovelRepository) : ViewModel() {

    val novels: StateFlow<List<Novel>> = repository.allNovels
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---- Thư viện: tìm kiếm (gõ không dấu được), lọc trạng thái / thể loại, sắp xếp, ghim ----
    private val _libraryQuery = MutableStateFlow("")
    val libraryQuery: StateFlow<String> = _libraryQuery.asStateFlow()
    private val _libraryStatus = MutableStateFlow("ALL")
    val libraryStatus: StateFlow<String> = _libraryStatus.asStateFlow()
    private val _libraryGenre = MutableStateFlow("ALL")
    val libraryGenre: StateFlow<String> = _libraryGenre.asStateFlow()
    private val _librarySort = MutableStateFlow(LibrarySort.UPDATED_DESC)
    /** Lọc theo loại dự án: ALL / FILM / TV. */
    private val _libraryKind = MutableStateFlow("ALL")
    val libraryKind: StateFlow<String> = _libraryKind.asStateFlow()
    fun setLibraryKind(k: String) { _libraryKind.value = k }
    val librarySort: StateFlow<LibrarySort> = _librarySort.asStateFlow()

    fun setLibraryQuery(q: String) { _libraryQuery.value = q }
    fun setLibraryStatus(s: String) { _libraryStatus.value = s }
    fun setLibraryGenre(g: String) { _libraryGenre.value = g }
    fun setLibrarySort(s: LibrarySort) { _librarySort.value = s }

    val libraryNovels: StateFlow<List<Novel>> = combine(
        combine(repository.allNovels, _libraryKind) { list, kind -> if (kind == "ALL") list else list.filter { it.projectKind == kind } },
        _libraryQuery, _libraryStatus, _libraryGenre, _librarySort
    ) { list, q, status, genre, sort ->
        val filtered = list.filter { n ->
            (status == "ALL" || n.status == status) &&
                (genre == "ALL" || n.genre.trim().equals(genre, ignoreCase = true)) &&
                (q.isBlank() || TextTools.matches(n.title + " " + n.author + " " + n.genre, q))
        }
        val sorted = when (sort) {
            LibrarySort.UPDATED_DESC -> filtered.sortedByDescending { it.updatedAt }
            LibrarySort.CREATED_DESC -> filtered.sortedByDescending { it.createdAt }
            LibrarySort.CREATED_ASC -> filtered.sortedBy { it.createdAt }
            LibrarySort.TITLE_AZ -> filtered.sortedBy { TextTools.fold(it.title) }
            LibrarySort.WORDS_DESC -> filtered.sortedByDescending { it.wordCount }
            LibrarySort.PROGRESS_DESC -> filtered.sortedByDescending {
                if (it.targetWordCount > 0) it.wordCount.toDouble() / it.targetWordCount else 0.0
            }
        }
        // Truyện đã ghim đứng đầu, ghim sau cùng đứng trên cùng
        sorted.filter { it.isPinned }.sortedByDescending { it.pinnedAt } + sorted.filter { !it.isPinned }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Danh sách thể loại đang có trong thư viện (để lọc). */
    val libraryGenres: StateFlow<List<String>> = repository.allNovels
        .map { list -> list.map { it.genre.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }.sortedBy { TextTools.fold(it) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun togglePin(novel: Novel) {
        viewModelScope.launch {
            // Không đổi updatedAt để ghim không làm xáo thứ tự "Mới chỉnh sửa"
            repository.updateNovel(
                novel.copy(isPinned = !novel.isPinned, pinnedAt = if (novel.isPinned) 0L else System.currentTimeMillis())
            )
        }
    }

    /** Đưa truyện lên đầu danh sách "Mới chỉnh sửa". */
    fun bringToTop(novel: Novel) {
        viewModelScope.launch { repository.updateNovel(novel.copy(updatedAt = System.currentTimeMillis())) }
    }

    fun setNovelStatus(novel: Novel, status: String) {
        viewModelScope.launch { repository.updateNovel(novel.copy(status = status, updatedAt = System.currentTimeMillis())) }
    }

    val deletedNovels: StateFlow<List<Novel>> = repository.deletedNovels
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedChapters: StateFlow<List<Chapter>> = repository.deletedChapters
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Chapter sorting and view mode states
    private val _chapterSortOption = MutableStateFlow(ChapterSortOption.ORDER_ASC)
    val chapterSortOption: StateFlow<ChapterSortOption> = _chapterSortOption.asStateFlow()

    private val _chapterViewMode = MutableStateFlow(ChapterViewMode.LIST)
    val chapterViewMode: StateFlow<ChapterViewMode> = _chapterViewMode.asStateFlow()

    fun setChapterSortOption(option: ChapterSortOption) {
        _chapterSortOption.value = option
    }

    fun setChapterViewMode(mode: ChapterViewMode) {
        _chapterViewMode.value = mode
    }

    // Active novel details
    fun getNovelFlow(novelId: Long): Flow<Novel?> = repository.getNovelFlow(novelId)

    fun getVolumes(novelId: Long): Flow<List<Volume>> = repository.getVolumes(novelId)

    fun getChapters(novelId: Long): Flow<List<Chapter>> = repository.getChapters(novelId)

    fun getCharacters(novelId: Long): Flow<List<CharacterProfile>> = repository.getCharacters(novelId)

    fun getWorldNotes(novelId: Long): Flow<List<WorldNote>> = repository.getWorldNotes(novelId)

    // Novel operations
    fun createNovel(
        title: String,
        author: String = "Tác giả",
        synopsis: String = "",
        genre: String = "Chính kịch",
        targetWordCount: Int = 20000,
        coverColorHex: String = "#8B1E1E",
        status: String = "WRITING",
        cover: CoverDesign = CoverDesign(colorHex = coverColorHex),
        projectKind: String = "FILM",
        onCreated: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val novel = Novel(
                title = title.trim(),
                author = author.trim().ifEmpty { "Tác giả" },
                synopsis = synopsis.trim(),
                genre = genre.trim().ifEmpty { "Chính kịch" },
                targetWordCount = targetWordCount,
                coverColorHex = cover.colorHex,
                status = status,
                projectKind = projectKind
            ).withCover(cover)
            val id = repository.insertNovel(novel)
            // Create default volume 1
            repository.insertVolume(
                Volume(
                    novelId = id,
                    title = "${termsOf(projectKind).Vol} 1",
                    orderIndex = 1
                )
            )
            onCreated(id)
        }
    }

    fun updateNovel(novel: Novel) {
        viewModelScope.launch {
            repository.updateNovel(novel.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    fun softDeleteNovel(novelId: Long) {
        viewModelScope.launch {
            repository.softDeleteNovel(novelId)
        }
    }

    fun restoreNovel(novelId: Long) {
        viewModelScope.launch {
            repository.restoreNovel(novelId)
        }
    }

    fun hardDeleteNovel(novelId: Long) {
        viewModelScope.launch {
            repository.hardDeleteNovel(novelId)
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repository.emptyTrash()
        }
    }

    /** Lưu đại cương toàn truyện. */
    fun updateNovelOutline(novel: Novel, outline: String) {
        viewModelScope.launch { repository.updateNovel(novel.copy(outline = outline, updatedAt = System.currentTimeMillis())) }
    }

    // ---- Nhập kịch bản từ tệp Fountain / TXT / Word ----
    fun importScript(script: Screenplay.ImportedScript, projectKind: String, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val t = termsOf(projectKind)
            val novelId = repository.insertNovel(
                Novel(
                    title = script.title.trim().ifEmpty { "Kịch bản nhập" },
                    author = script.author.trim().ifEmpty { "Tác giả" },
                    genre = "Chính kịch",
                    projectKind = projectKind
                )
            )
            var order = 1
            script.volumes.forEachIndexed { vi, v ->
                val volId = repository.insertVolume(
                    Volume(novelId = novelId, title = v.title.trim().ifEmpty { "${t.Vol} ${vi + 1}" }, orderIndex = vi + 1)
                )
                for (c in v.chapters) {
                    repository.insertChapter(
                        Chapter(
                            novelId = novelId,
                            volumeId = volId,
                            title = c.title.trim().ifEmpty { "${t.Chap} $order" },
                            content = c.content,
                            outline = c.outline,
                            orderIndex = order,
                            wordCount = TextTools.wordCount(c.content),
                            status = "DRAFT"
                        )
                    )
                    order++
                }
            }
            onCreated(novelId)
        }
    }

    /**
     * Tạo thẻ cho các nhân vật có lời thoại trong kịch bản mà chưa có thẻ.
     * [onDone] nhận số thẻ đã tạo.
     */
    fun importCharactersFromScript(novelId: Long, onDone: (Int) -> Unit) {
        viewModelScope.launch {
            val existing = repository.getCharactersDirect(novelId)
                .flatMap { TextTools.namesOf(it.name, it.aliases) }
                .map { it.uppercase() }.toSet()
            val names = repository.getChaptersDirect(novelId)
                .sortedBy { it.orderIndex }
                .flatMap { Screenplay.characterNames(it.content) }
                .distinctBy { it.uppercase() }
                .filter { it.uppercase() !in existing }
            for (n in names) {
                repository.insertCharacter(CharacterProfile(novelId = novelId, name = n.uppercase(), role = "SUPPORTING"))
            }
            onDone(names.size)
        }
    }

    // Volume operations
    fun addVolume(novelId: Long, title: String, description: String = "", orderIndex: Int) {
        viewModelScope.launch {
            val volume = Volume(
                novelId = novelId,
                title = title.trim(),
                orderIndex = orderIndex,
                description = description.trim()
            )
            repository.insertVolume(volume)
        }
    }

    fun updateVolume(volume: Volume) {
        viewModelScope.launch {
            repository.updateVolume(volume)
        }
    }

    fun deleteVolume(volume: Volume, deleteChapters: Boolean = false) {
        viewModelScope.launch {
            repository.deleteVolumeSafely(volume, deleteChapters)
        }
    }

    // Chapter operations
    fun addChapter(
        novelId: Long,
        volumeId: Long?,
        title: String,
        orderIndex: Int,
        onCreated: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val chapter = Chapter(
                novelId = novelId,
                volumeId = volumeId,
                title = title.trim().ifEmpty { "#$orderIndex" },
                orderIndex = orderIndex,
                content = "",
                status = "DRAFT"
            )
            val id = repository.insertChapter(chapter)
            onCreated(id)
        }
    }

    fun updateChapter(chapter: Chapter) {
        viewModelScope.launch {
            repository.updateChapter(chapter.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    fun softDeleteChapter(chapterId: Long, novelId: Long) {
        viewModelScope.launch {
            repository.softDeleteChapter(chapterId, novelId)
        }
    }

    fun restoreChapter(chapterId: Long, novelId: Long) {
        viewModelScope.launch {
            repository.restoreChapter(chapterId, novelId)
        }
    }

    fun hardDeleteChapter(chapterId: Long) {
        viewModelScope.launch {
            repository.hardDeleteChapter(chapterId)
        }
    }

    fun moveChapterToVolume(chapterId: Long, volumeId: Long?) {
        viewModelScope.launch {
            repository.updateChapterVolume(chapterId, volumeId)
        }
    }

    // Character operations (Add, Edit, Delete)
    fun addCharacter(
        novelId: Long,
        name: String,
        role: String,
        appearance: String,
        personality: String,
        background: String,
        notes: String,
        avatarEmoji: String,
        avatarId: String = "",
        gender: String = "",
        aliases: String = ""
    ) {
        viewModelScope.launch {
            val char = CharacterProfile(
                novelId = novelId,
                name = name.trim(),
                role = role,
                appearance = appearance.trim(),
                personality = personality.trim(),
                background = background.trim(),
                notes = notes.trim(),
                avatarEmoji = avatarEmoji,
                avatarId = avatarId,
                gender = gender,
                aliases = aliases.trim()
            )
            repository.insertCharacter(char)
        }
    }

    fun updateCharacter(character: CharacterProfile) {
        viewModelScope.launch {
            repository.updateCharacter(character.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteCharacter(character: CharacterProfile) {
        viewModelScope.launch {
            repository.deleteCharacter(character)
        }
    }

    // World note operations (Add, Edit, Delete)
    fun addWorldNote(
        novelId: Long,
        title: String,
        category: String,
        content: String,
        tags: String = ""
    ) {
        viewModelScope.launch {
            val note = WorldNote(
                novelId = novelId,
                title = title.trim(),
                category = WorldCategories.normalize(category),
                content = content.trim(),
                tags = tags.trim()
            )
            repository.insertWorldNote(note)
        }
    }

    fun updateWorldNote(note: WorldNote) {
        viewModelScope.launch {
            repository.updateWorldNote(note.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteWorldNote(note: WorldNote) {
        viewModelScope.launch {
            repository.deleteWorldNote(note)
        }
    }

    // ---- Đổi tên nhân vật / thiết lập, có thể thay cả trong nội dung truyện ----

    /**
     * Đổi tên nhân vật. [scope] = WHOLE_STORY: thay đúng nguyên từ trong mọi chương (mỗi chương bị đổi được
     * lưu bản cũ vào Lịch sử bản lưu). [includeExtras]: thay cả trong dàn ý, ghi chú, đại cương, tóm tắt,
     * mô tả quyển và các thẻ nhân vật / thiết lập khác. [onDone] nhận số chỗ đã thay trong nội dung chương.
     */
    fun renameCharacter(
        character: CharacterProfile,
        newName: String,
        scope: RenameScope,
        includeExtras: Boolean,
        onDone: (Int) -> Unit = {}
    ) {
        val old = character.name
        val new = newName.trim()
        if (new.isEmpty() || new == old) return
        viewModelScope.launch {
            var self = character.copy(name = new, updatedAt = System.currentTimeMillis())
            if (scope == RenameScope.WHOLE_STORY && includeExtras) {
                self = self.copy(
                    appearance = TextTools.replaceWholeWord(self.appearance, old, new).first,
                    personality = TextTools.replaceWholeWord(self.personality, old, new).first,
                    background = TextTools.replaceWholeWord(self.background, old, new).first,
                    notes = TextTools.replaceWholeWord(self.notes, old, new).first
                )
            }
            repository.updateCharacter(self)
            val count = if (scope == RenameScope.WHOLE_STORY)
                replaceInStory(character.novelId, old, new, includeExtras, skipCharacterId = character.id, skipWorldNoteId = null)
            else 0
            onDone(count)
        }
    }

    fun renameWorldNote(
        note: WorldNote,
        newTitle: String,
        scope: RenameScope,
        includeExtras: Boolean,
        onDone: (Int) -> Unit = {}
    ) {
        val old = note.title
        val new = newTitle.trim()
        if (new.isEmpty() || new == old) return
        viewModelScope.launch {
            var self = note.copy(title = new, updatedAt = System.currentTimeMillis())
            if (scope == RenameScope.WHOLE_STORY && includeExtras) {
                self = self.copy(content = TextTools.replaceWholeWord(self.content, old, new).first)
            }
            repository.updateWorldNote(self)
            val count = if (scope == RenameScope.WHOLE_STORY)
                replaceInStory(note.novelId, old, new, includeExtras, skipCharacterId = null, skipWorldNoteId = note.id)
            else 0
            onDone(count)
        }
    }

    private suspend fun replaceInStory(
        novelId: Long,
        old: String,
        new: String,
        includeExtras: Boolean,
        skipCharacterId: Long?,
        skipWorldNoteId: Long?
    ): Int {
        var total = 0
        val now = System.currentTimeMillis()
        for (ch in repository.getChaptersDirect(novelId)) {
            val (content, n) = TextTools.replaceWholeWord(ch.content, old, new)
            var updated = ch
            if (n > 0) {
                // Lưu bản cũ trước khi thay để có thể khôi phục trong Lịch sử bản lưu
                repository.insertSnapshot(
                    ChapterSnapshot(
                        chapterId = ch.id,
                        snapshotTitle = "Trước khi đổi tên “$old” → “$new”",
                        content = ch.content,
                        wordCount = ch.wordCount
                    )
                )
                updated = updated.copy(content = content, wordCount = TextTools.wordCount(content))
                total += n
            }
            if (includeExtras) {
                updated = updated.copy(
                    title = TextTools.replaceWholeWord(updated.title, old, new).first,
                    outline = TextTools.replaceWholeWord(updated.outline, old, new).first,
                    notes = TextTools.replaceWholeWord(updated.notes, old, new).first
                )
            }
            if (updated != ch) repository.updateChapterRaw(updated.copy(updatedAt = now))
        }
        if (includeExtras) {
            repository.getNovelById(novelId)?.let { nv ->
                val upd = nv.copy(
                    synopsis = TextTools.replaceWholeWord(nv.synopsis, old, new).first,
                    outline = TextTools.replaceWholeWord(nv.outline, old, new).first
                )
                if (upd != nv) repository.updateNovel(upd)
            }
            for (v in repository.getVolumesList(novelId)) {
                val upd = v.copy(description = TextTools.replaceWholeWord(v.description, old, new).first)
                if (upd != v) repository.updateVolume(upd)
            }
            for (c in repository.getCharactersDirect(novelId)) {
                if (c.id == skipCharacterId) continue
                val upd = c.copy(
                    appearance = TextTools.replaceWholeWord(c.appearance, old, new).first,
                    personality = TextTools.replaceWholeWord(c.personality, old, new).first,
                    background = TextTools.replaceWholeWord(c.background, old, new).first,
                    notes = TextTools.replaceWholeWord(c.notes, old, new).first
                )
                if (upd != c) repository.updateCharacter(upd)
            }
            for (w in repository.getWorldNotesDirect(novelId)) {
                if (w.id == skipWorldNoteId) continue
                val upd = w.copy(content = TextTools.replaceWholeWord(w.content, old, new).first)
                if (upd != w) repository.updateWorldNote(upd)
            }
        }
        repository.recalcWordCount(novelId)
        return total
    }

    // Helper to sort chapters
    fun sortChapters(chapters: List<Chapter>, option: ChapterSortOption): List<Chapter> {
        return when (option) {
            ChapterSortOption.ORDER_ASC -> chapters.sortedBy { it.orderIndex }
            ChapterSortOption.ORDER_DESC -> chapters.sortedByDescending { it.orderIndex }
            ChapterSortOption.UPDATED_DESC -> chapters.sortedByDescending { it.updatedAt }
            ChapterSortOption.WORDS_DESC -> chapters.sortedByDescending { it.wordCount }
            ChapterSortOption.WORDS_ASC -> chapters.sortedBy { it.wordCount }
            ChapterSortOption.TITLE_AZ -> chapters.sortedBy { it.title.lowercase() }
        }
    }
}

/** Gán thiết kế bìa vào truyện. */
fun Novel.withCover(c: CoverDesign): Novel = copy(
    coverStyle = c.style,
    coverColorHex = c.colorHex,
    coverBorder = c.border,
    coverPaper = c.paper,
    coverBorderImage = c.borderImage,
    coverPaperImage = c.paperImage,
    coverInk = c.ink
)

/** Thiết kế bìa hiện tại của truyện. */
fun Novel.coverDesign(): CoverDesign = CoverDesign(
    style = coverStyle,
    colorHex = coverColorHex,
    border = coverBorder,
    paper = coverPaper,
    borderImage = coverBorderImage,
    paperImage = coverPaperImage,
    ink = coverInk
)
