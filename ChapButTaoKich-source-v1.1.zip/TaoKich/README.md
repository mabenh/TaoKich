# Chấp Bút Tạo Kịch

Ứng dụng Android viết **kịch bản phim** của Văn Mọn, xây trên nền **Chấp Bút Kiến Văn 1.5**.

- **Phim điện ảnh / phim ngắn**: Hồi → Phân đoạn. Số cảnh đánh liên tục cả phim.
- **Phim truyền hình nhiều tập**: Mùa → Tập. Số cảnh đánh lại từ 1 ở mỗi tập.

Chi tiết tính năng: xem `PHIEN_BAN.md`. Ký app và đăng nhập Google Drive: xem `KY_APP.md`. Nguồn hình ảnh: xem `NGUON_HINH_ANH.md`.

## Build
- Mở thư mục bằng Android Studio, hoặc build trên GitHub như Kiến Văn (Gradle 9.3.1, JDK 17 trở lên).
- Mã gói: `com.vanmon.chapbut.taokich`, phiên bản 1.1 (versionCode 2).
- Unit test: `./gradlew :app:testDebugUnitTest`.
