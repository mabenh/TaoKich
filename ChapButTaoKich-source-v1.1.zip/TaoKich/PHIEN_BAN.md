# Chấp Bút Tạo Kịch 1.1

- **Logo mới**: logo V vàng ánh kim (mẫu thứ 2), dùng cho biểu tượng app (vẫn nền tím than, dải bảng phim) và logo trong app.
- **Thu gọn / mở rộng**:
  - Mỗi thẻ ở các tab Nhân vật, Bối cảnh, Đại cương có nút ⌃/⌄. Thẻ nhân vật thu gọn chỉ còn hình, tên, vai trò. Thẻ bối cảnh còn phân loại và tên. Thẻ đại cương còn dòng đầu tiên.
  - Đầu mỗi tab có nút **Thu gọn tất cả / Mở rộng tất cả**.
  - Trạng thái thu gọn giữ nguyên khi chuyển qua lại giữa các tab.
- **Mạng xã hội và bản quyền**:
  - Cuối danh sách kịch bản có 5 nút Facebook, Discord, Instagram, Threads, X của Văn Mọn, kèm dòng: “© Chấp Bút Tạo Kịch là ứng dụng được xây dựng bởi Văn Mọn. Bản quyền thuộc về Văn Mọn. Ứng dụng phát hành miễn phí cho cộng đồng biên kịch.”
  - Nút **ⓘ Giới thiệu** trên thanh tiêu đề: logo, số phiên bản, mạng xã hội, bản quyền.
- Phiên bản 1.1 (versionCode 2). Cài đè lên 1.0, giữ nguyên dữ liệu.

# Chấp Bút Tạo Kịch 1.0

App viết kịch bản phim, xây trên nền Chấp Bút Kiến Văn 1.5. Giữ lại các tính năng chung:
- Thư viện, tìm kiếm không dấu, lọc, ghim
- Tự tạo bìa
- Nhân vật có hình đại diện, thiết lập bối cảnh
- Tìm và đổi tên nhân vật / thiết lập trong toàn kịch bản
- Đại cương, dàn ý, ghi chú
- Đọc bằng giọng nói
- Soát chính tả
- Lịch sử bản lưu, thùng rác
- Sao lưu trên máy và Google Drive

## Loại dự án
Chọn khi tạo kịch bản. Sau khi tạo không đổi được loại.

| Loại | Phần lớn | Phần nhỏ | Đánh số cảnh |
|---|---|---|---|
| Phim điện ảnh / phim ngắn | Hồi | Phân đoạn | Liên tục cả phim |
| Phim truyền hình nhiều tập | Mùa | Tập | Từ 1 ở mỗi tập |

Mọi tên gọi trong app (nút, tab, hộp thoại, số đếm) tự đổi theo loại dự án.

## Khung soạn kịch bản
Kịch bản được gõ như chữ thường, app **tự nhận kiểu dòng** và trình bày ngay. Nội dung lưu vẫn là chữ thuần, theo lối Fountain.

| Kiểu dòng | Cách gõ | Hiển thị |
|---|---|---|
| Tiêu đề cảnh | `NỘI. NHÀ LAN – ĐÊM`, `NGOẠI. …`, `NỘI./NGOẠI. …` (hoặc INT./EXT.) | In đậm, có nền nhạt |
| Hành động | Câu bình thường | Sát lề |
| Nhân vật | Tên VIẾT HOA trên một dòng, sau dòng trống | Căn giữa, in đậm |
| Chỉ dẫn diễn xuất | `(lí nhí)` ngay dưới tên nhân vật | Thụt sâu, in nghiêng |
| Lời thoại | Các dòng dưới tên nhân vật | Thụt vào |
| Chuyển cảnh | `CẮT SANG:`, `HÒA SANG:`, `MỜ DẦN.` … | Căn phải |

- **Thanh kiểu dòng** ngay trên bàn phím: cho biết dòng đang gõ thuộc kiểu gì. Bấm **Cảnh / Hành động / Nhân vật / ( ) / Chuyển** để đổi dòng đó sang kiểu tương ứng; app tự viết hoa, thêm ngoặc và thêm dòng trống khi cần.
- **Gợi ý khi gõ**:
  - Dòng trống: NỘI. / NGOẠI. và tên nhân vật.
  - Đang gõ tiêu đề cảnh: địa điểm đã dùng, rồi thời điểm `– NGÀY / ĐÊM / SÁNG / CHIỀU …`.
  - Tên nhân vật lấy từ thẻ nhân vật và từ các tên đã có lời thoại.
  - Chọn tên nhân vật thì app xuống dòng để gõ thoại ngay.
- Nút **(V.O.)** để thêm phần mở rộng sau tên nhân vật.
- Menu ⋮:
  - **Danh sách cảnh**: bấm một cảnh để nhảy tới chỗ đó.
  - **Thống kê kịch bản**.
  - **Dàn ý & ghi chú**.
- Thanh tiêu đề hiện **≈ số trang** của phân đoạn / tập đang soạn (1 trang ≈ 1 phút phim).
- Cài đặt → **Chuẩn hóa trình bày kịch bản**:
  - Viết hoa tiêu đề cảnh, tên nhân vật, chuyển cảnh.
  - Thêm dòng trống giữa các khối, gộp dòng trống thừa.

## Màn chi tiết kịch bản
- **Tab Cảnh**:
  - Danh sách mọi cảnh, có đánh số và ghi nội / ngoại, thời điểm.
  - Tổng số cảnh, số trang, thời lượng ước tính.
  - Bấm vào cảnh để mở phân đoạn / tập chứa nó.
- **Thống kê** (biểu tượng biểu đồ):
  - Số trang / phút, số cảnh, số bối cảnh.
  - Nội / ngoại, ngày / đêm.
  - Lượng thoại theo từng nhân vật (số lượt, số chữ, thanh so sánh).
- **Xuất** (biểu tượng chia sẻ):
  - **PDF trình bày chuẩn**: trang bìa, khổ A4, phông đơn cách 12pt, lề trái 1.5 inch, ~55 dòng / trang, đánh số trang. Tên nhân vật, lời thoại, chỉ dẫn, chuyển cảnh đặt đúng vị trí. Không để tiêu đề cảnh nằm cuối trang. Lời thoại bị ngắt trang thì có “(CÒN NỮA)” / “TÊN (TIẾP)”. Phim truyền hình: mỗi tập sang trang mới, có tên tập.
  - **Fountain** (.fountain): mở được bằng Highland, Fade In, Beat, WriterSolo…
  - **TXT**.
- **Nhân vật → Lấy nhân vật từ kịch bản**: tạo thẻ cho mọi nhân vật có lời thoại mà chưa có thẻ.

## Nhập kịch bản
Nút **Nhập** trên thư viện.
- Tệp **Fountain / TXT**:
  - `# …` là Hồi / Mùa, `## …` là Phân đoạn / Tập.
  - Đọc được trang tiêu đề (Title, Author). Dòng `= …` đưa vào dàn ý.
  - Ký hiệu ép kiểu của Fountain được bỏ cho dễ đọc.
- Tệp **Word (.docx)**: Heading 1 = Hồi / Mùa, Heading 2 = Phân đoạn / Tập.
- Chọn loại dự án và đặt tên trước khi nhập.

## Khác với Kiến Văn
- Mã gói riêng `com.vanmon.chapbut.taokich`, nên cài song song với Kiến Văn. Cơ sở dữ liệu riêng `chapbut_taokich.db`.
- Bản sao lưu đặt tên `TaoKich_Backup_…`, không lẫn với bản sao lưu của Kiến Văn trên Google Drive.
- Biểu tượng app: logo V trên nền tím than, có dải bảng phim.
- Bỏ plugin google-services và tệp `google-services.json`, vì app không dùng Firebase. Đăng nhập Google Drive không cần đến chúng.
- Cài đặt soạn thảo bỏ “giãn đoạn văn” và “thụt lề đầu dòng” (chỉ dùng cho văn xuôi).
- Có sẵn một kịch bản mẫu “Chuyến Xe Cuối Ngày” khi cài lần đầu.

## Kiểm tra trước khi giao
- Biên dịch kiểm tra kiểu toàn bộ mã với Jetpack Compose 1.7. Thư viện Android / Room được thay bằng khai báo giả, chỉ trừ phần Google Drive cũ không sửa. Kết quả: **không lỗi**.
- Unit test (`ScreenplayTest`, `TextToolsTest`): **8/8 đạt**.
- **Chưa build thành APK và chưa chạy trên máy thật**, vì môi trường soạn mã không tải được Android SDK. Nếu GitHub báo lỗi, hãy gửi lại log.
