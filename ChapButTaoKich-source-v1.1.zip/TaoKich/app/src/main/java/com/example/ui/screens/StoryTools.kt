package com.example.ui.screens

import com.example.ui.state.terms
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.UnfoldLess
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.Chapter
import com.example.data.local.entities.Novel
import com.example.data.local.entities.Volume
import com.example.ui.state.RenameScope
import com.example.util.TextTools

// =====================================================================
// TÌM CHỖ XUẤT HIỆN của nhân vật / thiết lập trong các chương
// =====================================================================

private data class Occurrence(val chapter: Chapter, val count: Int, val excerpt: String, val matchStart: Int, val matchLen: Int)

private fun excerptOf(text: String, range: IntRange): Triple<String, Int, Int> {
    val from = (range.first - 40).coerceAtLeast(0)
    val to = (range.last + 1 + 60).coerceAtMost(text.length)
    val prefix = if (from > 0) "…" else ""
    val suffix = if (to < text.length) "…" else ""
    val body = text.substring(from, to).replace('\n', ' ')
    return Triple(prefix + body + suffix, prefix.length + (range.first - from), range.last + 1 - range.first)
}

@Composable
fun FindOccurrencesDialog(
    label: String,
    names: List<String>,
    chapters: List<Chapter>,
    volumes: List<Volume>,
    onOpenChapter: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    val volumeMap = remember(volumes) { volumes.associateBy { it.id } }
    val results = remember(names, chapters) {
        chapters.sortedBy { it.orderIndex }.mapNotNull { ch ->
            val n = TextTools.countNames(ch.content, names)
            if (n == 0) null else {
                val first = names.sortedByDescending { it.length }
                    .flatMap { TextTools.wholeWordRanges(ch.content, it) }
                    .minByOrNull { it.first }
                if (first == null) null else {
                    val (ex, s, l) = excerptOf(ch.content, first)
                    Occurrence(ch, n, ex, s, l)
                }
            }
        }
    }
    val total = results.sumOf { it.count }
    val highlight = MaterialTheme.colorScheme.primary

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tìm “$label”", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (names.size > 1) {
                    Text("Tìm cả biệt danh: ${names.drop(1).joinToString(", ")}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (results.isEmpty()) {
                    Text("Chưa xuất hiện trong kịch bản.")
                } else {
                    Text("Xuất hiện $total lần trong ${results.size} ${terms.chap}. Bấm vào ${terms.chap} để mở.", fontSize = 13.sp)
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 420.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(results, key = { it.chapter.id }) { r ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                tonalElevation = 1.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onDismiss(); onOpenChapter(r.chapter.id) }
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            r.chapter.title,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text("${r.count} lần", fontSize = 12.sp, color = highlight, fontWeight = FontWeight.Bold)
                                    }
                                    r.chapter.volumeId?.let { volumeMap[it] }?.let { v ->
                                        Text(v.title, fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, maxLines = 1)
                                    }
                                    Text(
                                        buildAnnotatedString {
                                            append(r.excerpt.substring(0, r.matchStart))
                                            withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = highlight)) {
                                                append(r.excerpt.substring(r.matchStart, r.matchStart + r.matchLen))
                                            }
                                            append(r.excerpt.substring(r.matchStart + r.matchLen))
                                        },
                                        fontSize = 12.sp,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}

// =====================================================================
// ĐỔI TÊN nhân vật / thiết lập, có thể thay cả trong nội dung truyện (hỏi trước khi thay)
// =====================================================================

@Composable
fun RenameDialog(
    title: String,
    currentName: String,
    chapters: List<Chapter>,
    onDismiss: () -> Unit,
    onConfirm: (newName: String, scope: RenameScope, includeExtras: Boolean) -> Unit
) {
    var newName by remember { mutableStateOf(currentName) }
    var scope by remember { mutableStateOf(RenameScope.WHOLE_STORY) }
    var includeExtras by remember { mutableStateOf(true) }
    var askConfirm by remember { mutableStateOf(false) }

    val counts = remember(currentName, chapters) {
        chapters.map { TextTools.countWholeWord(it.content, currentName) }
    }
    val total = counts.sum()
    val chapterHits = counts.count { it > 0 }
    val valid = newName.isNotBlank() && newName.trim() != currentName

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = currentName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Tên hiện tại") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Tên mới") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Thay tên trong nội dung kịch bản", style = MaterialTheme.typography.labelMedium)
                listOf(
                    RenameScope.CARD_ONLY to "Không thay, chỉ đổi tên trên thẻ",
                    RenameScope.WHOLE_STORY to "Toàn kịch bản ($total chỗ trong $chapterHits ${terms.chap})"
                ).forEach { (key, label) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(selected = scope == key, onClick = { scope = key })
                    ) {
                        RadioButton(selected = scope == key, onClick = { scope = key })
                        Text(label, fontSize = 13.sp)
                    }
                }
                if (scope == RenameScope.WHOLE_STORY) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { includeExtras = !includeExtras }
                    ) {
                        Checkbox(checked = includeExtras, onCheckedChange = { includeExtras = it })
                        Text(
                            "Thay cả trong dàn ý, ghi chú, đại cương, tóm tắt và các thẻ nhân vật / thiết lập khác",
                            fontSize = 12.sp
                        )
                    }
                }
                Text(
                    "Chỉ thay đúng nguyên từ (không đổi “$currentName” nằm trong từ khác). " +
                        "Mỗi ${terms.chap} bị thay đổi được lưu bản cũ trong Lịch sử bản lưu.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (scope == RenameScope.WHOLE_STORY && total > 0) askConfirm = true
                    else onConfirm(newName.trim(), scope, includeExtras)
                },
                enabled = valid
            ) { Text("Đổi tên") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )

    if (askConfirm) {
        AlertDialog(
            onDismissRequest = { askConfirm = false },
            title = { Text("Thay tên trong kịch bản", fontWeight = FontWeight.Bold) },
            text = { Text("Thay $total chỗ “$currentName” thành “${newName.trim()}” trong $chapterHits ${terms.chap}?") },
            confirmButton = {
                Button(onClick = {
                    askConfirm = false
                    onConfirm(newName.trim(), scope, includeExtras)
                }) { Text("Thay") }
            },
            dismissButton = { TextButton(onClick = { askConfirm = false }) { Text("Hủy") } }
        )
    }
}

// =====================================================================
// TAB ĐẠI CƯƠNG: toàn truyện + từng quyển
// =====================================================================

@Composable
fun OutlineTabContent(
    novel: Novel,
    volumes: List<Volume>,
    onSaveNovelOutline: (String) -> Unit,
    onSaveVolume: (Volume) -> Unit,
    collapsed: Set<String> = emptySet(),
    onToggleCollapse: (String) -> Unit = {},
    onSetAllCollapsed: (Set<String>) -> Unit = {}
) {
    var fontSize by remember { mutableFloatStateOf(14f) }
    val allKeys = listOf("novel") + volumes.map { "vol_${it.id}" }
    val allCollapsed = allKeys.all { it in collapsed }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CollapseAllChip(allCollapsed) { onSetAllCollapsed(if (allCollapsed) emptySet() else allKeys.toSet()) }
                Spacer(Modifier.weight(1f))
                Text("Cỡ chữ", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = { fontSize = (fontSize - 1f).coerceAtLeast(11f) }) { Text("A−") }
                TextButton(onClick = { fontSize = (fontSize + 1f).coerceAtMost(22f) }) { Text("A+") }
            }
        }
        item(key = "novel_outline_${novel.id}") {
            OutlineEditorCard(
                heading = "Đại cương toàn kịch bản",
                initial = novel.outline,
                placeholder = "Cốt truyện chính, tuyến nhân vật, các mốc lớn, kết thúc…",
                fontSize = fontSize,
                onSave = onSaveNovelOutline,
                collapsed = "novel" in collapsed,
                onToggleCollapse = { onToggleCollapse("novel") }
            )
        }
        items(volumes, key = { "vol_outline_${it.id}" }) { v ->
            OutlineEditorCard(
                heading = v.title,
                initial = v.description,
                placeholder = "Đại cương ${terms.vol} này: mục tiêu, xung đột chính, cao trào, kết thúc…",
                fontSize = fontSize,
                onSave = { onSaveVolume(v.copy(description = it)) },
                collapsed = "vol_${v.id}" in collapsed,
                onToggleCollapse = { onToggleCollapse("vol_${v.id}") }
            )
        }
        item { Spacer(Modifier.height(60.dp)) }
    }
}

@Composable
private fun OutlineEditorCard(
    heading: String,
    initial: String,
    placeholder: String,
    fontSize: Float,
    onSave: (String) -> Unit,
    collapsed: Boolean = false,
    onToggleCollapse: () -> Unit = {}
) {
    var text by remember(initial) { mutableStateOf(initial) }
    val dirty = text != initial
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(heading, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (dirty && !collapsed) {
                    TextButton(onClick = { text = initial }) { Text("Hoàn tác") }
                    Button(onClick = { onSave(text) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Lưu") }
                }
                CollapseToggle(collapsed, onToggleCollapse)
            }
            if (collapsed) {
                // Thu gọn: chỉ hiện dòng đầu (chưa lưu thì có dấu •)
                Text(
                    (if (dirty) "• " else "") + text.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().ifEmpty { "(trống)" },
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text(placeholder, fontSize = fontSize.sp) },
                textStyle = LocalTextStyle.current.copy(fontSize = fontSize.sp, lineHeight = (fontSize * 1.5f).sp),
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}


// =====================================================================
// THU GỌN / MỞ RỘNG thẻ (nhân vật, bối cảnh, đại cương)
// =====================================================================

/** Nút thu gọn / mở rộng một thẻ. */
@Composable
fun CollapseToggle(collapsed: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    IconButton(onClick = onClick, modifier = modifier.size(32.dp)) {
        Icon(
            if (collapsed) Icons.Default.ExpandMore else Icons.Default.ExpandLess,
            contentDescription = if (collapsed) "Mở rộng" else "Thu gọn",
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** Nút "Thu gọn tất cả / Mở rộng tất cả" ở đầu danh sách. */
@Composable
fun CollapseAllChip(allCollapsed: Boolean, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(if (allCollapsed) "Mở rộng tất cả" else "Thu gọn tất cả", fontSize = 12.sp) },
        leadingIcon = {
            Icon(
                if (allCollapsed) Icons.Default.UnfoldMore else Icons.Default.UnfoldLess,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
            )
        }
    )
}
