package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.R

/** Liên kết mạng xã hội của Văn Mọn (giống Chấp Bút bản Windows). */
data class SocialLink(val name: String, val icon: Int, val url: String)

object VanMon {
    val LINKS = listOf(
        SocialLink("Facebook", R.drawable.ic_social_facebook, "https://www.facebook.com/groups/987405947760311"),
        SocialLink("Discord", R.drawable.ic_social_discord, "https://discord.gg/zKd8JcyxC"),
        SocialLink("Instagram", R.drawable.ic_social_instagram, "https://www.instagram.com/nha_vanmon/"),
        SocialLink("Threads", R.drawable.ic_social_threads, "https://www.threads.com/@nha_vanmon"),
        SocialLink("X", R.drawable.ic_social_x, "https://x.com/tapchiruacon")
    )

    const val COPYRIGHT =
        "© Chấp Bút Tạo Kịch là ứng dụng được xây dựng bởi Văn Mọn. Bản quyền thuộc về Văn Mọn. " +
            "Ứng dụng phát hành miễn phí cho cộng đồng biên kịch."
}

/** Hàng nút mạng xã hội, mở bằng trình duyệt / ứng dụng tương ứng. */
@Composable
fun SocialLinksRow(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        VanMon.LINKS.forEach { link ->
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.secondaryContainer)
                    .clickable {
                        try {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(link.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {
                            android.widget.Toast.makeText(context, link.url, android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                    .testTag("social_${link.name.lowercase()}"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(link.icon),
                    contentDescription = "Văn Mọn trên ${link.name}",
                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

/** Chân trang: mạng xã hội + dòng bản quyền. */
@Composable
fun AboutFooter(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        HorizontalDivider(modifier = Modifier.fillMaxWidth(0.5f))
        SocialLinksRow()
        Text(
            VanMon.COPYRIGHT,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }
}

/** Hộp thoại "Giới thiệu": logo, phiên bản, mạng xã hội, bản quyền. */
@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Image(painterResource(R.drawable.logo_v), contentDescription = null, modifier = Modifier.size(96.dp))
                Text("Chấp Bút Tạo Kịch", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text(
                    "Phiên bản ${BuildConfig.VERSION_NAME} · Công cụ viết kịch bản phim điện ảnh và truyền hình",
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                SocialLinksRow(Modifier.fillMaxWidth())
                Text(VanMon.COPYRIGHT, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}
