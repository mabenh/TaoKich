package com.example.ui.screens

import com.example.ui.state.terms
import com.example.ui.state.LocalTerms
import com.example.ui.state.termsOf
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.local.entities.*
import com.example.ui.components.AvatarPicker
import com.example.ui.components.BookCover
import com.example.ui.components.CharacterAvatar
import com.example.ui.components.CoverPicker
import com.example.ui.state.ChapterSortOption
import com.example.ui.state.ChapterViewMode
import com.example.ui.state.NovelStatus
import com.example.util.TextTools
import com.example.util.Screenplay
import com.example.util.ScriptExport
import kotlinx.coroutines.launch
import com.example.util.WorldCategories
import com.example.viewmodel.BackupViewModel
import com.example.viewmodel.NovelViewModel
import com.example.viewmodel.coverDesign
import com.example.viewmodel.withCover
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovelDetailScreen(
    novelId: Long,
    novelViewModel: NovelViewModel,
    backupViewModel: BackupViewModel,
    onBack: () -> Unit,
    onOpenChapter: (Long) -> Unit
) {
    val context = LocalContext.current
    // remember(novelId): trước đây mỗi lần recompose lại tạo Flow mới -> collectAsState huỷ & đăng ký
    // lại liên tục, màn hình nháy vòng "đang tải" và truy vấn DB lặp vô tận.
    val novelFlow = remember(novelId) { novelViewModel.getNovelFlow(novelId) }
    val volumesFlow = remember(novelId) { novelViewModel.getVolumes(novelId) }
    val chaptersFlow = remember(novelId) { novelViewModel.getChapters(novelId) }
    val charactersFlow = remember(novelId) { novelViewModel.getCharacters(novelId) }
    val worldNotesFlow = remember(novelId) { novelViewModel.getWorldNotes(novelId) }
    val novel by novelFlow.collectAsState(initial = null)
    val volumes by volumesFlow.collectAsState(initial = emptyList())
    val rawChapters by chaptersFlow.collectAsState(initial = emptyList())
    val characters by charactersFlow.collectAsState(initial = emptyList())
    val worldNotes by worldNotesFlow.collectAsState(initial = emptyList())

    val sortOption by novelViewModel.chapterSortOption.collectAsState()
    val viewMode by novelViewModel.chapterViewMode.collectAsState()

    // Dialog state
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Chapters, 1: Characters, 2: World-Building, 3: Info
    var showAddChapterDialog by remember { mutableStateOf(false) }
    var targetVolumeForNewChapter by remember { mutableStateOf<Long?>(null) }
    var showAddVolumeDialog by remember { mutableStateOf(false) }

    // Character dialogs
    var showAddCharDialog by remember { mutableStateOf(false) }
    var editingCharacter by remember { mutableStateOf<CharacterProfile?>(null) }

    // World note dialogs
    var showAddNoteDialog by remember { mutableStateOf(false) }
    var editingWorldNote by remember { mutableStateOf<WorldNote?>(null) }

    // Chapter edit / move
    var movingChapter by remember { mutableStateOf<Chapter?>(null) }
    var editingNovelInfo by remember { mutableStateOf(false) }
    var confirmDeleteNovel by remember { mutableStateOf(false) }

    // Tìm chỗ xuất hiện / đổi tên (bản 1.5)
    var findTarget by remember { mutableStateOf<Pair<String, List<String>>?>(null) }
    var showExportMenu by remember { mutableStateOf(false) }
    var collapsedChars by remember(novelId) { mutableStateOf(setOf<Long>()) }
    var collapsedNotes by remember(novelId) { mutableStateOf(setOf<Long>()) }
    var collapsedOutlines by remember(novelId) { mutableStateOf(setOf<String>()) }
    var showScriptStats by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var renamingCharacter by remember { mutableStateOf<CharacterProfile?>(null) }
    var renamingWorldNote by remember { mutableStateOf<WorldNote?>(null) }

    // Quản lý quyển: đổi tên / xóa
    var editingVolume by remember { mutableStateOf<Volume?>(null) }
    var deletingVolume by remember { mutableStateOf<Volume?>(null) }
    var showVolumeManager by remember { mutableStateOf(false) }

    val sortedChapters = remember(rawChapters, sortOption) {
        novelViewModel.sortChapters(rawChapters, sortOption)
    }

    if (novel == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val currentNovel = novel!!

    CompositionLocalProvider(LocalTerms provides termsOf(currentNovel.projectKind)) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = currentNovel.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${currentNovel.genre} • ${currentNovel.wordCount} từ",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("btn_back_novel_detail")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                    }
                },
                actions = {
                    // Thống kê cả kịch bản
                    IconButton(onClick = { showScriptStats = true }, modifier = Modifier.testTag("btn_script_stats")) {
                        Icon(Icons.Default.BarChart, contentDescription = "Thống kê kịch bản")
                    }
                    // Xuất: PDF trình bày chuẩn / Fountain / TXT
                    Box {
                        IconButton(onClick = { showExportMenu = true }, modifier = Modifier.testTag("btn_export_novel")) {
                            Icon(Icons.Default.Share, contentDescription = "Xuất kịch bản")
                        }
                        DropdownMenu(expanded = showExportMenu, onDismissRequest = { showExportMenu = false }) {
                            fun share(file: java.io.File, mime: String, label: String) {
                                try {
                                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = mime
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        putExtra(Intent.EXTRA_SUBJECT, currentNovel.title)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, label))
                                } catch (_: Exception) {
                                    Toast.makeText(context, "Đã xuất tệp: ${file.name}", Toast.LENGTH_SHORT).show()
                                }
                            }
                            DropdownMenuItem(
                                text = { Text("Xuất PDF (trình bày chuẩn)") },
                                leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null) },
                                onClick = {
                                    showExportMenu = false
                                    exporting = true
                                    scope.launch {
                                        val f = try {
                                            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                                ScriptExport.exportPdf(context, currentNovel, volumes, rawChapters)
                                            }
                                        } catch (e: Exception) {
                                            android.util.Log.e("NovelDetail", "PDF export failed", e)
                                            null
                                        }
                                        exporting = false
                                        if (f != null) share(f, "application/pdf", "Chia sẻ kịch bản PDF")
                                        else Toast.makeText(context, "Không xuất được PDF", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Xuất Fountain (.fountain)") },
                                leadingIcon = { Icon(Icons.Default.Description, contentDescription = null) },
                                onClick = {
                                    showExportMenu = false
                                    val f = ScriptExport.exportFountain(context, currentNovel, volumes, rawChapters)
                                    share(f, "text/plain", "Chia sẻ kịch bản Fountain")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Xuất TXT") },
                                leadingIcon = { Icon(Icons.Default.TextSnippet, contentDescription = null) },
                                onClick = {
                                    showExportMenu = false
                                    share(backupViewModel.exportToTxt(currentNovel, rawChapters), "text/plain", "Chia sẻ kịch bản TXT")
                                }
                            )
                        }
                    }
                    IconButton(
                        onClick = { editingNovelInfo = true }
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Sửa thông tin kịch bản")
                    }
                    IconButton(
                        onClick = { showVolumeManager = true },
                        modifier = Modifier.testTag("btn_manage_volumes")
                    ) {
                        Icon(Icons.Default.LibraryBooks, contentDescription = "Quản lý ${terms.vol}")
                    }
                    // Trước đây app KHÔNG có nút xóa tác phẩm nào (softDeleteNovel không được gọi ở đâu)
                    IconButton(
                        onClick = { confirmDeleteNovel = true },
                        modifier = Modifier.testTag("btn_delete_novel")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Xóa kịch bản")
                    }
                }
            )
        },
        floatingActionButton = {
            when (selectedTab) {
                0 -> {
                    ExtendedFloatingActionButton(
                        onClick = {
                            targetVolumeForNewChapter = volumes.firstOrNull()?.id
                            showAddChapterDialog = true
                        },
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        text = { Text("Thêm ${terms.chapName}", fontWeight = FontWeight.Bold) },
                        containerColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.testTag("fab_add_chapter")
                    )
                }
                1 -> {
                    ExtendedFloatingActionButton(
                        onClick = { showAddCharDialog = true },
                        icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                        text = { Text("Thêm Nhân Vật", fontWeight = FontWeight.Bold) },
                        containerColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.testTag("fab_add_character")
                    )
                }
                2 -> {
                    ExtendedFloatingActionButton(
                        onClick = { showAddNoteDialog = true },
                        icon = { Icon(Icons.Default.PostAdd, contentDescription = null) },
                        text = { Text("Thêm Bối Cảnh", fontWeight = FontWeight.Bold) },
                        containerColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.testTag("fab_add_world_note")
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Tabs
            ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 8.dp) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("${terms.chapName} (${rawChapters.size})", fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Nhân vật (${characters.size})", fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Bối cảnh (${worldNotes.size})", fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Đại cương", fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.Notes, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_outline")
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("Cảnh", fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_scenes")
                )
            }

            when (selectedTab) {
                0 -> {
                    ChaptersTabContent(
                        novel = currentNovel,
                        volumes = volumes,
                        chapters = sortedChapters,
                        allChaptersRaw = rawChapters,
                        sortOption = sortOption,
                        viewMode = viewMode,
                        onSortChange = { novelViewModel.setChapterSortOption(it) },
                        onViewModeChange = { novelViewModel.setChapterViewMode(it) },
                        onOpenChapter = onOpenChapter,
                        onAddChapter = { volumeId ->
                            targetVolumeForNewChapter = volumeId
                            showAddChapterDialog = true
                        },
                        onAddVolume = { showAddVolumeDialog = true },
                        onMoveChapter = { movingChapter = it },
                        onDeleteChapter = { novelViewModel.softDeleteChapter(it.id, currentNovel.id) },
                        onEditVolume = { editingVolume = it },
                        onDeleteVolume = { deletingVolume = it }
                    )
                }
                1 -> {
                    CharactersTabContent(
                        characters = characters,
                        chapters = rawChapters,
                        onEdit = { editingCharacter = it },
                        onAdd = { showAddCharDialog = true },
                        onFind = { c -> findTarget = c.name to TextTools.namesOf(c.name, c.aliases) },
                        onRename = { renamingCharacter = it },
                        collapsed = collapsedChars,
                        onToggleCollapse = { id -> collapsedChars = if (id in collapsedChars) collapsedChars - id else collapsedChars + id },
                        onSetAllCollapsed = { collapsedChars = it },
                        onImportFromScript = {
                            novelViewModel.importCharactersFromScript(currentNovel.id) { n ->
                                Toast.makeText(
                                    context,
                                    if (n > 0) "Đã thêm $n nhân vật từ kịch bản" else "Không có nhân vật mới (mọi nhân vật có thoại đều đã có thẻ)",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    )
                }
                2 -> {
                    WorldNotesTabContent(
                        notes = worldNotes,
                        chapters = rawChapters,
                        onEdit = { editingWorldNote = it },
                        onAdd = { showAddNoteDialog = true },
                        onFind = { w -> findTarget = w.title to listOf(w.title) },
                        onRename = { renamingWorldNote = it },
                        collapsed = collapsedNotes,
                        onToggleCollapse = { id -> collapsedNotes = if (id in collapsedNotes) collapsedNotes - id else collapsedNotes + id },
                        onSetAllCollapsed = { collapsedNotes = it }
                    )
                }
                3 -> {
                    OutlineTabContent(
                        novel = currentNovel,
                        volumes = volumes,
                        onSaveNovelOutline = { text ->
                            novelViewModel.updateNovelOutline(currentNovel, text)
                            Toast.makeText(context, "Đã lưu đại cương", Toast.LENGTH_SHORT).show()
                        },
                        onSaveVolume = { v ->
                            novelViewModel.updateVolume(v)
                            Toast.makeText(context, "Đã lưu đại cương ${v.title}", Toast.LENGTH_SHORT).show()
                        },
                        collapsed = collapsedOutlines,
                        onToggleCollapse = { k -> collapsedOutlines = if (k in collapsedOutlines) collapsedOutlines - k else collapsedOutlines + k },
                        onSetAllCollapsed = { collapsedOutlines = it }
                    )
                }
                4 -> {
                    ScenesTabContent(
                        projectKind = currentNovel.projectKind,
                        volumes = volumes,
                        chapters = rawChapters,
                        onOpenChapter = onOpenChapter,
                        onOpenStats = { showScriptStats = true }
                    )
                }
            }
        }
    }

    // --- Dialogs ---

    if (showAddChapterDialog) {
        // Dùng số thứ tự lớn nhất + 1 (trước đây dùng số lượng chương + 1 nên bị trùng số sau khi xóa chương)
        val nextIndex = (rawChapters.maxOfOrNull { it.orderIndex } ?: 0) + 1
        AddChapterDialog(
            nextOrderIndex = nextIndex,
            volumes = volumes,
            initialVolumeId = targetVolumeForNewChapter,
            onDismiss = { showAddChapterDialog = false },
            onConfirm = { title, orderIndex, volId ->
                // Đóng hộp thoại ngay để tránh bấm 2 lần tạo 2 chương trùng
                showAddChapterDialog = false
                novelViewModel.addChapter(
                    novelId = novelId,
                    volumeId = volId,
                    title = title,
                    orderIndex = orderIndex
                ) { newChId ->
                    onOpenChapter(newChId)
                }
            }
        )
    }

    if (showAddVolumeDialog) {
        AddVolumeDialog(
            nextOrderIndex = (volumes.maxOfOrNull { it.orderIndex } ?: 0) + 1,
            onDismiss = { showAddVolumeDialog = false },
            onConfirm = { title, desc, order ->
                novelViewModel.addVolume(novelId, title, desc, order)
                showAddVolumeDialog = false
            }
        )
    }

    // Character Add & Edit Dialogs
    if (showAddCharDialog) {
        EditCharacterDialog(
            character = null,
            onDismiss = { showAddCharDialog = false },
            onSave = { name, role, appearance, personality, bg, notes, extra ->
                novelViewModel.addCharacter(
                    novelId = novelId,
                    name = name,
                    role = role,
                    appearance = appearance,
                    personality = personality,
                    background = bg,
                    notes = notes,
                    avatarEmoji = "👤",
                    avatarId = extra.avatarId,
                    gender = extra.gender,
                    aliases = extra.aliases
                )
                showAddCharDialog = false
            },
            onDelete = null
        )
    }

    if (editingCharacter != null) {
        EditCharacterDialog(
            character = editingCharacter,
            onDismiss = { editingCharacter = null },
            onSave = { _, role, appearance, personality, bg, notes, extra ->
                // Tên đổi bằng nút "Đổi tên" trên thẻ (có thể thay cả trong truyện)
                val updated = editingCharacter!!.copy(
                    role = role,
                    appearance = appearance,
                    personality = personality,
                    background = bg,
                    notes = notes,
                    avatarId = extra.avatarId,
                    gender = extra.gender,
                    aliases = extra.aliases
                )
                novelViewModel.updateCharacter(updated)
                editingCharacter = null
            },
            onDelete = {
                novelViewModel.deleteCharacter(editingCharacter!!)
                editingCharacter = null
            }
        )
    }

    // World Note Add & Edit Dialogs
    if (showAddNoteDialog) {
        EditWorldNoteDialog(
            worldNote = null,
            onDismiss = { showAddNoteDialog = false },
            onSave = { title, category, content, tags ->
                novelViewModel.addWorldNote(
                    novelId = novelId,
                    title = title,
                    category = category,
                    content = content,
                    tags = tags
                )
                showAddNoteDialog = false
            },
            onDelete = null
        )
    }

    if (editingWorldNote != null) {
        EditWorldNoteDialog(
            worldNote = editingWorldNote,
            onDismiss = { editingWorldNote = null },
            onSave = { _, category, content, tags ->
                val updated = editingWorldNote!!.copy(
                    category = category,
                    content = content,
                    tags = tags
                )
                novelViewModel.updateWorldNote(updated)
                editingWorldNote = null
            },
            onDelete = {
                novelViewModel.deleteWorldNote(editingWorldNote!!)
                editingWorldNote = null
            }
        )
    }

    if (showScriptStats) {
        val st = remember(rawChapters, volumes) { Screenplay.stats(ScriptExport.fullText(volumes, rawChapters)) }
        ScriptStatsDialog(title = "Thống kê cả kịch bản", stats = st, onDismiss = { showScriptStats = false })
    }

    if (exporting) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text("Đang tạo PDF…") },
            text = { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
        )
    }

    findTarget?.let { (label, names) ->
        FindOccurrencesDialog(
            label = label,
            names = names,
            chapters = rawChapters,
            volumes = volumes,
            onOpenChapter = onOpenChapter,
            onDismiss = { findTarget = null }
        )
    }

    renamingCharacter?.let { ch ->
        RenameDialog(
            title = "Đổi tên nhân vật",
            currentName = ch.name,
            chapters = rawChapters,
            onDismiss = { renamingCharacter = null },
            onConfirm = { newName, scope, extras ->
                renamingCharacter = null
                novelViewModel.renameCharacter(ch, newName, scope, extras) { n ->
                    Toast.makeText(context, if (n > 0) "Đã đổi tên và thay $n chỗ trong kịch bản" else "Đã đổi tên", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    renamingWorldNote?.let { w ->
        RenameDialog(
            title = "Đổi tên thiết lập",
            currentName = w.title,
            chapters = rawChapters,
            onDismiss = { renamingWorldNote = null },
            onConfirm = { newName, scope, extras ->
                renamingWorldNote = null
                novelViewModel.renameWorldNote(w, newName, scope, extras) { n ->
                    Toast.makeText(context, if (n > 0) "Đã đổi tên và thay $n chỗ trong kịch bản" else "Đã đổi tên", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Move Chapter Dialog
    if (movingChapter != null) {
        MoveChapterDialog(
            chapter = movingChapter!!,
            volumes = volumes,
            onDismiss = { movingChapter = null },
            onConfirm = { newVolId ->
                novelViewModel.moveChapterToVolume(movingChapter!!.id, newVolId)
                movingChapter = null
            }
        )
    }

    if (showVolumeManager) {
        VolumeManagerDialog(
            volumes = volumes,
            chapters = rawChapters,
            onDismiss = { showVolumeManager = false },
            onAdd = {
                showVolumeManager = false
                showAddVolumeDialog = true
            },
            onEdit = { editingVolume = it },
            onDelete = { deletingVolume = it }
        )
    }

    editingVolume?.let { vol ->
        EditVolumeDialog(
            volume = vol,
            onDismiss = { editingVolume = null },
            onConfirm = { updated ->
                novelViewModel.updateVolume(updated)
                editingVolume = null
            }
        )
    }

    deletingVolume?.let { vol ->
        DeleteVolumeDialog(
            volume = vol,
            chapterCount = rawChapters.count { it.volumeId == vol.id },
            onDismiss = { deletingVolume = null },
            onConfirm = { deleteChapters ->
                novelViewModel.deleteVolume(vol, deleteChapters)
                deletingVolume = null
            }
        )
    }

    if (confirmDeleteNovel) {
        AlertDialog(
            onDismissRequest = { confirmDeleteNovel = false },
            title = { Text("Xóa Kịch Bản", fontWeight = FontWeight.Bold) },
            text = { Text("Chuyển '${currentNovel.title}' vào thùng rác? Bạn có thể khôi phục lại từ Thùng Rác ở màn hình chính.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirmDeleteNovel = false
                        novelViewModel.softDeleteNovel(currentNovel.id)
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Xóa") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeleteNovel = false }) { Text("Hủy") }
            }
        )
    }

    // Edit Novel Info Dialog
    if (editingNovelInfo) {
        EditNovelInfoDialog(
            novel = currentNovel,
            onDismiss = { editingNovelInfo = false },
            onConfirm = { updated ->
                novelViewModel.updateNovel(updated)
                editingNovelInfo = false
            }
        )
    }
    }
}

// ----------------------------------------------------
// CHAPTERS TAB: Toolbar (Sort & View Mode), List View & Column View
// ----------------------------------------------------

@Composable
fun ChaptersTabContent(
    novel: Novel,
    volumes: List<Volume>,
    chapters: List<Chapter>,
    allChaptersRaw: List<Chapter>,
    sortOption: ChapterSortOption,
    viewMode: ChapterViewMode,
    onSortChange: (ChapterSortOption) -> Unit,
    onViewModeChange: (ChapterViewMode) -> Unit,
    onOpenChapter: (Long) -> Unit,
    onAddChapter: (Long?) -> Unit,
    onAddVolume: () -> Unit,
    onMoveChapter: (Chapter) -> Unit,
    onDeleteChapter: (Chapter) -> Unit,
    onEditVolume: (Volume) -> Unit = {},
    onDeleteVolume: (Volume) -> Unit = {}
) {
    var showSortMenu by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Toolbar: Sort & View Mode switcher
        Surface(
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Sort Dropdown (weight để nút sắp xếp không đẩy nút chế độ xem ra khỏi màn hình nhỏ)
                Box(modifier = Modifier.weight(1f, fill = false).padding(end = 8.dp)) {
                    OutlinedButton(
                        onClick = { showSortMenu = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp).testTag("btn_chapter_sort")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sort,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = sortOption.title,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        ChapterSortOption.values().forEach { option ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = option.title,
                                        fontWeight = if (option == sortOption) FontWeight.Bold else FontWeight.Normal,
                                        color = if (option == sortOption) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                onClick = {
                                    onSortChange(option)
                                    showSortMenu = false
                                },
                                leadingIcon = {
                                    if (option == sortOption) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            )
                        }
                    }
                }

                // View Mode Switcher: Liệt kê (List) vs Cột theo quyển (By Volume)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SingleChoiceSegmentedButton(
                        selected = viewMode == ChapterViewMode.LIST,
                        onClick = { onViewModeChange(ChapterViewMode.LIST) },
                        icon = Icons.Default.FormatListNumbered,
                        label = "Liệt kê",
                        testTag = "btn_mode_list"
                    )
                    SingleChoiceSegmentedButton(
                        selected = viewMode == ChapterViewMode.BY_VOLUME,
                        onClick = { onViewModeChange(ChapterViewMode.BY_VOLUME) },
                        icon = Icons.Default.ViewColumn,
                        label = "Cột ${terms.vol}",
                        testTag = "btn_mode_volume"
                    )
                }
            }
        }

        // Content: List or Column
        // Ở chế độ "Cột quyển" vẫn hiển thị các cột dù chưa có chương, để còn bấm "Thêm Quyển Mới"
        if (chapters.isEmpty() && viewMode == ChapterViewMode.LIST) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.NoteAdd,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Chưa có ${terms.chap} nào",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Hãy thêm ${terms.chap} đầu tiên để bắt đầu sáng tác!",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { onAddChapter(volumes.firstOrNull()?.id) }) {
                        Text("Tạo ${terms.chapName} Mới")
                    }
                }
            }
        } else {
            when (viewMode) {
                ChapterViewMode.LIST -> {
                    ChapterListView(
                        chapters = chapters,
                        volumes = volumes,
                        onOpenChapter = onOpenChapter,
                        onMoveChapter = onMoveChapter,
                        onDeleteChapter = onDeleteChapter
                    )
                }
                ChapterViewMode.BY_VOLUME -> {
                    ChapterVolumeColumnView(
                        volumes = volumes,
                        allChapters = allChaptersRaw,
                        sortOption = sortOption,
                        onOpenChapter = onOpenChapter,
                        onAddChapterToVolume = onAddChapter,
                        onAddVolume = onAddVolume,
                        onMoveChapter = onMoveChapter,
                        onDeleteChapter = onDeleteChapter,
                        onEditVolume = onEditVolume,
                        onDeleteVolume = onDeleteVolume
                    )
                }
            }
        }
    }
}

@Composable
fun SingleChoiceSegmentedButton(
    selected: Boolean,
    onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ----------------------------------------------------
// 1. DẠNG LIỆT KÊ (LIST VIEW)
// ----------------------------------------------------

@Composable
fun ChapterListView(
    chapters: List<Chapter>,
    volumes: List<Volume>,
    onOpenChapter: (Long) -> Unit,
    onMoveChapter: (Chapter) -> Unit,
    onDeleteChapter: (Chapter) -> Unit
) {
    val volumeMap = remember(volumes) { volumes.associateBy { it.id } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(chapters, key = { it.id }) { chapter ->
            val vol = chapter.volumeId?.let { volumeMap[it] }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenChapter(chapter.id) }
                    .testTag("chapter_item_${chapter.id}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Chapter number badge
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${chapter.orderIndex}",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = chapter.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(3.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (vol != null) {
                                Text(
                                    text = vol.title,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.secondary,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 120.dp)
                                )
                                Text(
                                    text = " • ",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "${chapter.wordCount} từ",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = " • ",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            StatusBadge(status = chapter.status)
                        }
                    }

                    // Chapter action menu
                    var showItemMenu by remember { mutableStateOf(false) }
                    Box {
                        IconButton(
                            onClick = { showItemMenu = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Thao tác ${terms.chap}",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        DropdownMenu(
                            expanded = showItemMenu,
                            onDismissRequest = { showItemMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Chuyển ${terms.vol}") },
                                onClick = {
                                    showItemMenu = false
                                    onMoveChapter(chapter)
                                },
                                leadingIcon = { Icon(Icons.Default.DriveFileMove, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Xóa vào thùng rác", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showItemMenu = false
                                    onDeleteChapter(chapter)
                                },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                            )
                        }
                    }
                }
            }
        }
        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}

// ----------------------------------------------------
// 2. DẠNG CỘT CHIA THEO QUYỂN (VOLUME COLUMN VIEW)
// ----------------------------------------------------

@Composable
fun ChapterVolumeColumnView(
    volumes: List<Volume>,
    allChapters: List<Chapter>,
    sortOption: ChapterSortOption,
    onOpenChapter: (Long) -> Unit,
    onAddChapterToVolume: (Long?) -> Unit,
    onAddVolume: () -> Unit,
    onMoveChapter: (Chapter) -> Unit,
    onDeleteChapter: (Chapter) -> Unit,
    onEditVolume: (Volume) -> Unit = {},
    onDeleteVolume: (Volume) -> Unit = {}
) {
    // Group chapters by volumeId
    val chaptersByVolume = remember(allChapters, volumes) {
        val map = mutableMapOf<Long?, MutableList<Chapter>>()
        allChapters.forEach { ch ->
            map.getOrPut(ch.volumeId) { mutableListOf() }.add(ch)
        }
        map
    }

    // Unassigned chapters (volumeId == null or not matching any existing volume)
    val knownVolumeIds = remember(volumes) { volumes.map { it.id }.toSet() }
    val unassignedChapters = remember(allChapters, knownVolumeIds) {
        allChapters.filter { it.volumeId == null || !knownVolumeIds.contains(it.volumeId) }
    }

    LazyRow(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 10.dp),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Render each Volume as a distinct Column Card
        items(volumes, key = { it.id }) { volume ->
            val volChapters = (chaptersByVolume[volume.id] ?: emptyList()).let { list ->
                when (sortOption) {
                    ChapterSortOption.ORDER_ASC -> list.sortedBy { it.orderIndex }
                    ChapterSortOption.ORDER_DESC -> list.sortedByDescending { it.orderIndex }
                    ChapterSortOption.UPDATED_DESC -> list.sortedByDescending { it.updatedAt }
                    ChapterSortOption.WORDS_DESC -> list.sortedByDescending { it.wordCount }
                    ChapterSortOption.WORDS_ASC -> list.sortedBy { it.wordCount }
                    ChapterSortOption.TITLE_AZ -> list.sortedBy { it.title.lowercase() }
                }
            }
            val totalWordsInVolume = volChapters.sumOf { it.wordCount }

            VolumeColumnCard(
                volume = volume,
                chapters = volChapters,
                totalWords = totalWordsInVolume,
                onOpenChapter = onOpenChapter,
                onAddChapter = { onAddChapterToVolume(volume.id) },
                onMoveChapter = onMoveChapter,
                onDeleteChapter = onDeleteChapter,
                onEditVolume = { onEditVolume(volume) },
                onDeleteVolume = { onDeleteVolume(volume) }
            )
        }

        // If there are unassigned chapters, render an Unassigned Column
        if (unassignedChapters.isNotEmpty() || volumes.isEmpty()) {
            item(key = "unassigned_column") {
                val sortedUnassigned = when (sortOption) {
                    ChapterSortOption.ORDER_ASC -> unassignedChapters.sortedBy { it.orderIndex }
                    ChapterSortOption.ORDER_DESC -> unassignedChapters.sortedByDescending { it.orderIndex }
                    ChapterSortOption.UPDATED_DESC -> unassignedChapters.sortedByDescending { it.updatedAt }
                    ChapterSortOption.WORDS_DESC -> unassignedChapters.sortedByDescending { it.wordCount }
                    ChapterSortOption.WORDS_ASC -> unassignedChapters.sortedBy { it.wordCount }
                    ChapterSortOption.TITLE_AZ -> unassignedChapters.sortedBy { it.title.lowercase() }
                }
                VolumeColumnCard(
                    volume = Volume(id = -1, novelId = -1, title = "Chưa phân ${terms.vol}", description = "Các ${terms.chap} rời chưa gán vào ${terms.vol} cụ thể"),
                    chapters = sortedUnassigned,
                    totalWords = sortedUnassigned.sumOf { it.wordCount },
                    onOpenChapter = onOpenChapter,
                    onAddChapter = { onAddChapterToVolume(null) },
                    onMoveChapter = onMoveChapter,
                    onDeleteChapter = onDeleteChapter,
                    isUnassigned = true
                )
            }
        }

        // Add Volume Column Action
        item(key = "add_volume_column") {
            Card(
                modifier = Modifier
                    .width(180.dp)
                    .fillMaxHeight()
                    .clickable(onClick = onAddVolume)
                    .testTag("btn_add_volume_column"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.LibraryAdd,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "+ Thêm ${terms.volName} Mới",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Phân chia kết cấu kịch bản",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VolumeColumnCard(
    volume: Volume,
    chapters: List<Chapter>,
    totalWords: Int,
    onOpenChapter: (Long) -> Unit,
    onAddChapter: () -> Unit,
    onMoveChapter: (Chapter) -> Unit,
    onDeleteChapter: (Chapter) -> Unit,
    isUnassigned: Boolean = false,
    onEditVolume: (() -> Unit)? = null,
    onDeleteVolume: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .fillMaxHeight(),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnassigned)
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            else
                MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Volume Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = volume.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${chapters.size} ${terms.chap} • ${totalWords} từ",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onAddChapter,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddCircleOutline,
                        contentDescription = "Thêm ${terms.chap} vào ${terms.vol}",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                if (!isUnassigned && (onEditVolume != null || onDeleteVolume != null)) {
                    var showVolumeMenu by remember { mutableStateOf(false) }
                    Box {
                        IconButton(
                            onClick = { showVolumeMenu = true },
                            modifier = Modifier.size(32.dp).testTag("btn_volume_menu_${volume.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Thao tác ${terms.vol}",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        DropdownMenu(
                            expanded = showVolumeMenu,
                            onDismissRequest = { showVolumeMenu = false }
                        ) {
                            if (onEditVolume != null) {
                                DropdownMenuItem(
                                    text = { Text("Đổi tên / sửa ${terms.vol}") },
                                    onClick = {
                                        showVolumeMenu = false
                                        onEditVolume()
                                    },
                                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                                )
                            }
                            if (onDeleteVolume != null) {
                                DropdownMenuItem(
                                    text = { Text("Xóa ${terms.vol}", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showVolumeMenu = false
                                        onDeleteVolume()
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            if (volume.description.isNotEmpty()) {
                Text(
                    text = volume.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

            // Scrollable list of chapters inside this column
            if (chapters.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Chưa có ${terms.chap} nào trong ${terms.vol} này",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(chapters, key = { it.id }) { chapter ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenChapter(chapter.id) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${chapter.orderIndex}.",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = chapter.title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${chapter.wordCount} từ",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = " • ",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        StatusBadge(status = chapter.status)
                                    }
                                }

                                var showSubMenu by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(
                                        onClick = { showSubMenu = true },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MoreVert,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showSubMenu,
                                        onDismissRequest = { showSubMenu = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("Chuyển ${terms.vol}") },
                                            onClick = {
                                                showSubMenu = false
                                                onMoveChapter(chapter)
                                            },
                                            leadingIcon = { Icon(Icons.Default.DriveFileMove, contentDescription = null) }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Xóa vào thùng rác", color = MaterialTheme.colorScheme.error) },
                                            onClick = {
                                                showSubMenu = false
                                                onDeleteChapter(chapter)
                                            },
                                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val (label, color) = when (status) {
        "COMPLETED" -> "Hoàn thành" to Color(0xFF2E7D32)
        "REVISING" -> "Cần sửa" to Color(0xFFF57C00)
        else -> "Bản nháp" to Color(0xFF757575)
    }
    Text(
        text = label,
        fontSize = 10.sp,
        fontWeight = FontWeight.SemiBold,
        color = color
    )
}

// ----------------------------------------------------
// CHARACTERS TAB: List, Cards with EDIT buttons
// ----------------------------------------------------

@Composable
fun CharactersTabContent(
    characters: List<CharacterProfile>,
    chapters: List<Chapter> = emptyList(),
    onEdit: (CharacterProfile) -> Unit,
    onAdd: () -> Unit,
    onFind: (CharacterProfile) -> Unit = {},
    onRename: (CharacterProfile) -> Unit = {},
    onImportFromScript: () -> Unit = {},
    collapsed: Set<Long> = emptySet(),
    onToggleCollapse: (Long) -> Unit = {},
    onSetAllCollapsed: (Set<Long>) -> Unit = {}
) {
    if (characters.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.PersonOutline,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Chưa có hồ sơ nhân vật",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Lưu giữ chân dung, tính cách và bối cảnh của các nhân vật",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onAdd, modifier = Modifier.testTag("btn_empty_add_character")) {
                    Text("Thêm Nhân Vật Đầu Tiên")
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(onClick = onImportFromScript) {
                    Text("Lấy nhân vật từ kịch bản")
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    val allCollapsed = characters.all { it.id in collapsed }
                    CollapseAllChip(allCollapsed) {
                        onSetAllCollapsed(if (allCollapsed) emptySet() else characters.map { it.id }.toSet())
                    }
                    AssistChip(
                        onClick = onImportFromScript,
                        label = { Text("Lấy nhân vật từ kịch bản", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.GroupAdd, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("btn_import_characters")
                    )
                }
            }
            items(characters, key = { it.id }) { character ->
                val appearances = remember(character.name, character.aliases, chapters) {
                    val names = TextTools.namesOf(character.name, character.aliases)
                    chapters.sumOf { TextTools.countNames(it.content, names) }
                }
                CharacterCard(
                    character = character,
                    appearances = appearances,
                    onEdit = { onEdit(character) },
                    onFind = { onFind(character) },
                    onRename = { onRename(character) },
                    collapsed = character.id in collapsed,
                    onToggleCollapse = { onToggleCollapse(character.id) }
                )
            }
            item {
                Spacer(modifier = Modifier.height(70.dp))
            }
        }
    }
}

@Composable
fun CharacterCard(
    character: CharacterProfile,
    appearances: Int = -1,
    onEdit: () -> Unit,
    onFind: () -> Unit = {},
    onRename: () -> Unit = {},
    collapsed: Boolean = false,
    onToggleCollapse: () -> Unit = {}
) {
    val roleBadge = when (character.role) {
        "PROTAGONIST" -> "Nhân vật chính" to MaterialTheme.colorScheme.primary
        "ANTAGONIST" -> "Phản diện" to MaterialTheme.colorScheme.error
        "SUPPORTING" -> "Nhân vật phụ" to MaterialTheme.colorScheme.secondary
        else -> "Khác" to MaterialTheme.colorScheme.outline
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("character_card_${character.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CharacterAvatar(character = character, size = if (collapsed) 40.dp else 52.dp, ring = roleBadge.second)

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = character.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (character.aliases.isNotBlank()) {
                        Text(
                            text = "Biệt danh: ${character.aliases}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = roleBadge.second.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = roleBadge.first,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = roleBadge.second,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        if (appearances >= 0) {
                            Text(
                                text = "  Xuất hiện $appearances lần",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                CollapseToggle(collapsed, onToggleCollapse, Modifier.testTag("btn_collapse_character_${character.id}"))
            }

            if (!collapsed) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 6.dp)) {
                AssistChip(
                    onClick = onFind,
                    label = { Text("Tìm", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("btn_find_character_${character.id}")
                )
                AssistChip(
                    onClick = onRename,
                    label = { Text("Đổi tên", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("btn_rename_character_${character.id}")
                )
                AssistChip(
                    onClick = onEdit,
                    label = { Text("Sửa", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("btn_edit_character_${character.id}")
                )
            }

            if (character.appearance.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• Ngoại hình: ${character.appearance}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (character.personality.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• Tính cách: ${character.personality}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (character.background.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• Thân thế: ${character.background}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (character.notes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• Ghi chú: ${character.notes}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
            }
        }
    }
}

// ----------------------------------------------------
// WORLD-BUILDING TAB: List, Cards with EDIT buttons
// ----------------------------------------------------

@Composable
fun WorldNotesTabContent(
    notes: List<WorldNote>,
    chapters: List<Chapter> = emptyList(),
    onEdit: (WorldNote) -> Unit,
    onAdd: () -> Unit,
    onFind: (WorldNote) -> Unit = {},
    onRename: (WorldNote) -> Unit = {},
    collapsed: Set<Long> = emptySet(),
    onToggleCollapse: (Long) -> Unit = {},
    onSetAllCollapsed: (Set<Long>) -> Unit = {}
) {
    if (notes.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Landscape,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Chưa có thiết lập bối cảnh",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Xây dựng bản đồ, địa danh, hệ thống phép thuật, võ học, thế lực...",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onAdd, modifier = Modifier.testTag("btn_empty_add_note")) {
                    Text("Thêm Thiết Lập Bối Cảnh")
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                val allCollapsed = notes.all { it.id in collapsed }
                CollapseAllChip(allCollapsed) {
                    onSetAllCollapsed(if (allCollapsed) emptySet() else notes.map { it.id }.toSet())
                }
            }
            items(notes, key = { it.id }) { note ->
                val appearances = remember(note.title, chapters) {
                    chapters.sumOf { TextTools.countWholeWord(it.content, note.title) }
                }
                WorldNoteCard(
                    note = note,
                    appearances = appearances,
                    onEdit = { onEdit(note) },
                    onFind = { onFind(note) },
                    onRename = { onRename(note) },
                    collapsed = note.id in collapsed,
                    onToggleCollapse = { onToggleCollapse(note.id) }
                )
            }
            item {
                Spacer(modifier = Modifier.height(70.dp))
            }
        }
    }
}

@Composable
fun WorldNoteCard(
    note: WorldNote,
    appearances: Int = -1,
    onEdit: () -> Unit,
    onFind: () -> Unit = {},
    onRename: () -> Unit = {},
    collapsed: Boolean = false,
    onToggleCollapse: () -> Unit = {}
) {
    val categoryLabel = WorldCategories.label(WorldCategories.normalize(note.category))
    val categoryColor = when (WorldCategories.normalize(note.category)) {
        "LOCATION" -> Color(0xFF1E88E5)
        "FACTION" -> Color(0xFFD81B60)
        "CLASS" -> Color(0xFF6D4C41)
        "MAGIC_POWER" -> Color(0xFF8E24AA)
        "TALENT" -> Color(0xFF00897B)
        "ITEM" -> Color(0xFFFB8C00)
        else -> Color(0xFF757575)
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("world_note_card_${note.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = categoryColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = categoryLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = categoryColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                note.tags.split(',').map { it.trim() }.filter { it.isNotEmpty() }.forEach { tag ->
                    Text(
                        text = "  #$tag",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                if (appearances >= 0) {
                    Text(
                        text = "Xuất hiện $appearances lần",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                CollapseToggle(collapsed, onToggleCollapse)
            }

            Spacer(modifier = Modifier.height(if (collapsed) 2.dp else 6.dp))

            Text(
                text = note.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (!collapsed) {
            if (note.content.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = note.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 6.dp)) {
                AssistChip(
                    onClick = onFind,
                    label = { Text("Tìm", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                AssistChip(
                    onClick = onRename,
                    label = { Text("Đổi tên", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                AssistChip(
                    onClick = onEdit,
                    label = { Text("Sửa", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("btn_edit_world_note_${note.id}")
                )
            }
            }
        }
    }
}

// ----------------------------------------------------
// EDIT CHARACTER DIALOG (For both Add & Edit)
// ----------------------------------------------------

/** Trường bổ sung của nhân vật (bản 1.5). */
data class CharacterExtra(val avatarId: String, val gender: String, val aliases: String)

@Composable
fun EditCharacterDialog(
    character: CharacterProfile?,
    onDismiss: () -> Unit,
    onSave: (name: String, role: String, appearance: String, personality: String, bg: String, notes: String, extra: CharacterExtra) -> Unit,
    onDelete: (() -> Unit)?
) {
    val isEditing = character != null
    var name by remember { mutableStateOf(character?.name ?: "") }
    var role by remember { mutableStateOf(character?.role ?: "PROTAGONIST") }
    var appearance by remember { mutableStateOf(character?.appearance ?: "") }
    var personality by remember { mutableStateOf(character?.personality ?: "") }
    var background by remember { mutableStateOf(character?.background ?: "") }
    var notes by remember { mutableStateOf(character?.notes ?: "") }
    var avatarId by remember { mutableStateOf(character?.avatarId ?: "") }
    var gender by remember { mutableStateOf(character?.gender ?: "") }
    var aliases by remember { mutableStateOf(character?.aliases ?: "") }
    val roles = listOf(
        "PROTAGONIST" to "Nhân vật chính",
        "SUPPORTING" to "Nhân vật phụ",
        "ANTAGONIST" to "Phản diện",
        "OTHER" to "Khác"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Chỉnh Sửa Nhân Vật" else "Thêm Hồ Sơ Nhân Vật",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Hình đại diện:", style = MaterialTheme.typography.labelSmall)
                    AvatarPicker(selectedId = avatarId, gender = gender, onSelect = { avatarId = it })
                }

                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Tên nhân vật *") },
                        singleLine = true,
                        // Khi sửa: đổi tên bằng nút "Đổi tên" trên thẻ (có thể thay cả trong truyện)
                        enabled = !isEditing,
                        supportingText = if (isEditing) {
                            @Composable { Text("Đổi tên bằng nút “Đổi tên” trên thẻ.", fontSize = 11.sp) }
                        } else null,
                        modifier = Modifier.fillMaxWidth().testTag("input_char_name")
                    )
                }

                item {
                    OutlinedTextField(
                        value = aliases,
                        onValueChange = { aliases = it },
                        label = { Text("Biệt danh / tên gọi khác (cách nhau dấu phẩy)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Text("Giới tính:", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("M" to "Nam", "F" to "Nữ", "" to "Khác / chưa rõ").forEach { (k, label) ->
                            FilterChip(selected = gender == k, onClick = { gender = k }, label = { Text(label, fontSize = 12.sp) })
                        }
                    }
                }

                item {
                    Text("Vai trò trong kịch bản:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        roles.forEach { (key, label) ->
                            FilterChip(
                                selected = role == key,
                                onClick = { role = key },
                                label = { Text(label, fontSize = 12.sp) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = appearance,
                        onValueChange = { appearance = it },
                        label = { Text("Ngoại hình") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = personality,
                        onValueChange = { personality = it },
                        label = { Text("Tính cách") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = background,
                        onValueChange = { background = it },
                        label = { Text("Thân thế / Xuất thân") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Ghi chú khác / Bí mật") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name, role, appearance, personality, background, notes, CharacterExtra(avatarId, gender, aliases))
                    }
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("btn_save_character")
            ) {
                Text(if (isEditing) "Lưu Thay Đổi" else "Thêm")
            }
        },
        dismissButton = {
            Row {
                if (isEditing && onDelete != null) {
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Xóa")
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("Hủy")
                }
            }
        }
    )
}

// ----------------------------------------------------
// EDIT WORLD NOTE DIALOG (For both Add & Edit)
// ----------------------------------------------------

@Composable
fun EditWorldNoteDialog(
    worldNote: WorldNote?,
    onDismiss: () -> Unit,
    onSave: (title: String, category: String, content: String, tags: String) -> Unit,
    onDelete: (() -> Unit)?
) {
    val isEditing = worldNote != null
    var title by remember { mutableStateOf(worldNote?.title ?: "") }
    var category by remember { mutableStateOf(WorldCategories.normalize(worldNote?.category ?: "LOCATION")) }
    var content by remember { mutableStateOf(worldNote?.content ?: "") }
    var tags by remember { mutableStateOf(worldNote?.tags ?: "") }

    val categories = WorldCategories.ALL

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Chỉnh Sửa Bối Cảnh" else "Thêm Thiết Lập Bối Cảnh",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tiêu đề / Tên thiết lập *") },
                    singleLine = true,
                    enabled = !isEditing,
                    supportingText = if (isEditing) {
                        @Composable { Text("Đổi tên bằng nút “Đổi tên” trên thẻ.", fontSize = 11.sp) }
                    } else null,
                    modifier = Modifier.fillMaxWidth().testTag("input_world_note_title")
                )

                Text("Phân loại:", style = MaterialTheme.typography.labelSmall)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { (catKey, catLabel) ->
                        FilterChip(
                            selected = category == catKey,
                            onClick = { category = catKey },
                            label = { Text(catLabel, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Nội dung chi tiết thiết lập") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tags,
                    onValueChange = { tags = it },
                    label = { Text("Nhãn (cách nhau dấu phẩy)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(title, category, content, tags)
                    }
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.testTag("btn_save_world_note")
            ) {
                Text(if (isEditing) "Lưu Thay Đổi" else "Thêm")
            }
        },
        dismissButton = {
            Row {
                if (isEditing && onDelete != null) {
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Xóa")
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("Hủy")
                }
            }
        }
    )
}

// ----------------------------------------------------
// OTHER UTILITY DIALOGS
// ----------------------------------------------------

@Composable
fun AddChapterDialog(
    nextOrderIndex: Int,
    volumes: List<Volume>,
    initialVolumeId: Long?,
    onDismiss: () -> Unit,
    onConfirm: (title: String, orderIndex: Int, volumeId: Long?) -> Unit
) {
    val t = terms
    var title by remember { mutableStateOf("${t.chapName} $nextOrderIndex: ") }
    var selectedVolumeId by remember { mutableStateOf(initialVolumeId) }
    var orderIndexStr by remember { mutableStateOf("$nextOrderIndex") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Thêm ${terms.chapName} Mới", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tên ${terms.chap} *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_new_chapter_title")
                )

                OutlinedTextField(
                    value = orderIndexStr,
                    onValueChange = { orderIndexStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Số thứ tự ${terms.chap}") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (volumes.isNotEmpty()) {
                    Text("Thuộc ${terms.vol}:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedVolumeId == null,
                            onClick = { selectedVolumeId = null },
                            label = { Text("Chưa phân ${terms.vol}") }
                        )
                        volumes.forEach { vol ->
                            FilterChip(
                                selected = selectedVolumeId == vol.id,
                                onClick = { selectedVolumeId = vol.id },
                                label = { Text(vol.title) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val order = orderIndexStr.toIntOrNull() ?: nextOrderIndex
                        onConfirm(title, order, selectedVolumeId)
                    }
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.testTag("btn_confirm_add_chapter")
            ) {
                Text("Tạo & Soạn Thảo")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}

@Composable
fun AddVolumeDialog(
    nextOrderIndex: Int,
    onDismiss: () -> Unit,
    onConfirm: (title: String, desc: String, order: Int) -> Unit
) {
    val t = terms
    var title by remember { mutableStateOf("${t.volName} $nextOrderIndex: ") }
    var description by remember { mutableStateOf("") }
    var orderStr by remember { mutableStateOf("$nextOrderIndex") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tạo ${terms.volName} Mới", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tên ${terms.vol} *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_volume_title")
                )
                OutlinedTextField(
                    value = orderStr,
                    onValueChange = { orderStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Thứ tự ${terms.vol}") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Mô tả / Tóm tắt nội dung ${terms.vol}") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val order = orderStr.toIntOrNull() ?: nextOrderIndex
                        onConfirm(title, description, order)
                    }
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.testTag("btn_confirm_add_volume")
            ) {
                Text("Tạo ${terms.volName}")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}

@Composable
fun MoveChapterDialog(
    chapter: Chapter,
    volumes: List<Volume>,
    onDismiss: () -> Unit,
    onConfirm: (volumeId: Long?) -> Unit
) {
    var selectedVolumeId by remember { mutableStateOf(chapter.volumeId) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chuyển ${terms.volName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Chọn ${terms.vol} cho '${chapter.title}':",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedVolumeId = null }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedVolumeId == null,
                        onClick = { selectedVolumeId = null }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ngoài ${terms.vol} (Chưa phân ${terms.vol})")
                }

                volumes.forEach { vol ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedVolumeId = vol.id }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedVolumeId == vol.id,
                            onClick = { selectedVolumeId = vol.id }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(vol.title)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(selectedVolumeId) }) {
                Text("Xác nhận")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}

@Composable
fun EditNovelInfoDialog(
    novel: Novel,
    onDismiss: () -> Unit,
    onConfirm: (Novel) -> Unit
) {
    var title by remember { mutableStateOf(novel.title) }
    var author by remember { mutableStateOf(novel.author) }
    var genre by remember { mutableStateOf(novel.genre) }
    var synopsis by remember { mutableStateOf(novel.synopsis) }
    var targetWordsStr by remember { mutableStateOf("${novel.targetWordCount}") }
    var status by remember { mutableStateOf(novel.status) }
    var cover by remember { mutableStateOf(novel.coverDesign()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sửa Thông Tin Kịch Bản", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tên kịch bản *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = author,
                    onValueChange = { author = it },
                    label = { Text("Tác giả") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = genre,
                    onValueChange = { genre = it },
                    label = { Text("Thể loại") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = targetWordsStr,
                    onValueChange = { targetWordsStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Mục tiêu số từ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = synopsis,
                    onValueChange = { synopsis = it },
                    label = { Text("Tóm tắt") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Trạng thái:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    NovelStatus.ALL.forEach { (key, label) ->
                        FilterChip(selected = status == key, onClick = { status = key }, label = { Text(label, fontSize = 12.sp) })
                    }
                }
                CoverPicker(title = title, author = author, design = cover, onChange = { cover = it })
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val target = targetWordsStr.toIntOrNull() ?: novel.targetWordCount
                        onConfirm(
                            novel.copy(
                                title = title.trim(),
                                author = author.trim(),
                                genre = genre.trim(),
                                synopsis = synopsis.trim(),
                                targetWordCount = target,
                                status = status
                            ).withCover(cover)
                        )
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Lưu")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}


// ----------------------------------------------------
// QUẢN LÝ QUYỂN: danh sách, đổi tên, xóa
// ----------------------------------------------------

@Composable
fun VolumeManagerDialog(
    volumes: List<Volume>,
    chapters: List<Chapter>,
    onDismiss: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (Volume) -> Unit,
    onDelete: (Volume) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Quản Lý ${terms.volName}", fontWeight = FontWeight.Bold) },
        text = {
            if (volumes.isEmpty()) {
                Text(
                    "Kịch bản chưa có ${terms.vol} nào.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(volumes, key = { it.id }) { vol ->
                        val count = chapters.count { it.volumeId == vol.id }
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = vol.title,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Thứ tự ${vol.orderIndex} • $count ${terms.chap}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { onEdit(vol) }, modifier = Modifier.size(36.dp)) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = "Đổi tên ${terms.vol}",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                IconButton(onClick = { onDelete(vol) }, modifier = Modifier.size(36.dp)) {
                                    Icon(
                                        Icons.Default.DeleteOutline,
                                        contentDescription = "Xóa ${terms.vol}",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Đóng") }
        },
        dismissButton = {
            TextButton(onClick = onAdd) { Text("+ Thêm ${terms.vol}") }
        }
    )
}

@Composable
fun EditVolumeDialog(
    volume: Volume,
    onDismiss: () -> Unit,
    onConfirm: (Volume) -> Unit
) {
    var title by remember(volume.id) { mutableStateOf(volume.title) }
    var description by remember(volume.id) { mutableStateOf(volume.description) }
    var orderStr by remember(volume.id) { mutableStateOf("${volume.orderIndex}") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sửa ${terms.volName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tên ${terms.vol} *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_edit_volume_title")
                )
                OutlinedTextField(
                    value = orderStr,
                    onValueChange = { orderStr = it.filter { ch -> ch.isDigit() }.take(6) },
                    label = { Text("Thứ tự ${terms.vol}") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Mô tả / Tóm tắt nội dung ${terms.vol}") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        volume.copy(
                            title = title.trim(),
                            description = description.trim(),
                            orderIndex = orderStr.toIntOrNull() ?: volume.orderIndex
                        )
                    )
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.testTag("btn_confirm_edit_volume")
            ) { Text("Lưu") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}

@Composable
fun DeleteVolumeDialog(
    volume: Volume,
    chapterCount: Int,
    onDismiss: () -> Unit,
    onConfirm: (deleteChapters: Boolean) -> Unit
) {
    var deleteChapters by remember(volume.id) { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Xóa ${terms.volName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Xóa '${volume.title}'?")
                if (chapterCount > 0) {
                    Text(
                        "${terms.volName} này có $chapterCount ${terms.chap}. Bạn muốn xử lý các ${terms.chap} thế nào?",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { deleteChapters = false },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = !deleteChapters, onClick = { deleteChapters = false })
                        Text("Giữ ${terms.chap}, chuyển sang \"Chưa phân ${terms.vol}\"", fontSize = 13.sp)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { deleteChapters = true },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = deleteChapters, onClick = { deleteChapters = true })
                        Text(
                            "Chuyển cả các ${terms.chap} vào thùng rác",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(deleteChapters && chapterCount > 0) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.testTag("btn_confirm_delete_volume")
            ) { Text("Xóa ${terms.vol}") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}


// ----------------------------------------------------
// TAB CẢNH: danh sách cảnh có đánh số (điện ảnh: liên tục; truyền hình: đánh lại từ 1 mỗi tập)
// ----------------------------------------------------

@Composable
fun ScenesTabContent(
    projectKind: String,
    volumes: List<Volume>,
    chapters: List<Chapter>,
    onOpenChapter: (Long) -> Unit,
    onOpenStats: () -> Unit
) {
    val volOrder = remember(volumes) { volumes.associate { it.id to it.orderIndex } }
    val sorted = remember(chapters, volOrder) {
        chapters.sortedWith(compareBy({ volOrder[it.volumeId] ?: Int.MAX_VALUE }, { it.orderIndex }))
    }
    val perChapter = remember(sorted) { sorted.map { it to Screenplay.scenes(it.content) } }
    val totalPages = remember(sorted) { sorted.sumOf { Screenplay.estimatePages(it.content) } }
    val totalScenes = perChapter.sumOf { it.second.size }
    val isTv = projectKind == "TV"

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("$totalScenes cảnh · ≈ ${formatPages(totalPages)} trang", fontWeight = FontWeight.Bold)
                        Text("Thời lượng ≈ ${formatMinutes(totalPages)} (1 trang ≈ 1 phút)", fontSize = 12.sp)
                    }
                    TextButton(onClick = onOpenStats) { Text("Thống kê") }
                }
            }
        }
        var running = 0
        perChapter.forEach { (ch, scenes) ->
            val start = if (isTv) 0 else running
            running += scenes.size
            item(key = "ch_${ch.id}") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenChapter(ch.id) }
                        .padding(top = 10.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(ch.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${scenes.size} cảnh · ≈ ${formatPages(Screenplay.estimatePages(ch.content))} tr", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (scenes.isEmpty()) {
                item(key = "empty_${ch.id}") {
                    Text("Chưa có cảnh", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 36.dp))
                }
            }
            scenes.forEachIndexed { i, sc ->
                item(key = "sc_${ch.id}_$i") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenChapter(ch.id) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${start + i + 1}", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.width(36.dp))
                        Column(Modifier.weight(1f)) {
                            Text(sc.heading.uppercase(), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val meta = listOf(sc.interior, sc.time).filter { it.isNotEmpty() }.joinToString(" · ")
                            if (meta.isNotEmpty()) Text(meta, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}
