package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entities.Chapter
import com.example.ui.state.ChapterSortOption
import com.example.util.VietnameseSpellChecker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Chấp Bút Kiến Văn", appName)
    }

    @Test
    fun `test vietnamese spell check detects common typos`() {
        val text = "Tôi thik đọc tiểu thuyết này và thấy rất zui."
        val issues = VietnameseSpellChecker.check(text)
        assertTrue("Should detect typos", issues.isNotEmpty())
        assertTrue("Should detect thik", issues.any { it.originalWord == "thik" && it.suggestedWord == "thích" })
        assertTrue("Should detect zui", issues.any { it.originalWord == "zui" && it.suggestedWord == "vui" })
    }

    @Test
    fun `test chapter sorting by words and order`() {
        val ch1 = Chapter(id = 1, novelId = 1, title = "Chương 1", orderIndex = 1, wordCount = 500)
        val ch2 = Chapter(id = 2, novelId = 1, title = "Chương 2", orderIndex = 2, wordCount = 1200)
        val ch3 = Chapter(id = 3, novelId = 1, title = "Chương 3", orderIndex = 3, wordCount = 300)
        val list = listOf(ch2, ch1, ch3)

        val sortedByOrder = list.sortedBy { it.orderIndex }
        assertEquals("Chương 1", sortedByOrder[0].title)
        assertEquals("Chương 2", sortedByOrder[1].title)
        assertEquals("Chương 3", sortedByOrder[2].title)

        val sortedByWordsDesc = list.sortedByDescending { it.wordCount }
        assertEquals("Chương 2", sortedByWordsDesc[0].title)
        assertEquals("Chương 1", sortedByWordsDesc[1].title)
        assertEquals("Chương 3", sortedByWordsDesc[2].title)
    }
}
